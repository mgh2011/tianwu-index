#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级邮件安全防御系统 v5.1.0
Enterprise Email Security Defense System

功能模块：
1. 威胁检测引擎 - 多维度威胁分析
2. 恶意链接检测 - URL安全验证
3. 钓鱼邮件识别 - 多特征检测
4. 附件安全扫描 - 文件类型与内容检查
5. 行为分析引擎 - 异常行为检测
6. 安全审计日志 - 操作记录与追溯
7. 应急响应模块 - 自动化响应机制

运行模式：本地运行，无外部网络请求
"""

import re
import json
import hashlib
import datetime
import mimetypes
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import math


# ==================== 数据结构定义 ====================

class ThreatLevel(Enum):
    """威胁等级"""
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ThreatType(Enum):
    """威胁类型"""
    PHISHING = "phishing"              # 钓鱼邮件
    MALWARE = "malware"                # 恶意软件
    SPAM = "spam"                      # 垃圾邮件
    SCAM = "scam"                      # 诈骗邮件
    SPOOFING = "spoofing"              # 伪造邮件
    BEC = "bec"                        # 商务邮件诈骗
    MALICIOUS_LINK = "malicious_link"  # 恶意链接
    SUSPICIOUS_ATTACHMENT = "suspicious_attachment"  # 可疑附件


@dataclass
class ThreatIndicator:
    """威胁指标"""
    threat_type: ThreatType
    level: ThreatLevel
    confidence: float  # 0.0-1.0
    description: str
    evidence: List[str] = field(default_factory=list)
    remediation: str = ""


@dataclass
class SecurityScanResult:
    """安全扫描结果"""
    is_safe: bool
    threat_level: ThreatLevel
    threats: List[ThreatIndicator]
    risk_score: float  # 0-100
    recommendations: List[str]
    scan_details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditLog:
    """审计日志条目"""
    timestamp: str
    action: str
    user: str
    resource: str
    result: str
    details: Dict[str, Any] = field(default_factory=dict)


# ==================== 1. 威胁检测引擎 ====================

class ThreatDetectionEngine:
    """
    威胁检测引擎
    多维度分析邮件威胁，包括内容分析、模式匹配、行为识别
    """
    
    def __init__(self):
        # 钓鱼关键词库（扩展版）
        self.phishing_keywords = {
            'urgent_action': [
                '紧急', '立即', '马上', 'urgent', 'immediately',
                '24小时内', '限时', '即将过期', '账户冻结', '最后期限'
            ],
            'financial_lure': [
                '中奖', '奖金', '退款', 'inheritance', 'lottery',
                '转账', '汇款', '优惠', '返现', '投资回报',
                # 新增中奖类关键词
                '恭喜', '现金大奖', '免费领取', '获奖通知', '大奖',
                '被选中', '幸运用户', '领取奖金', '奖品',
                # 新增金融诈骗类关键词
                '月收益', '高回报', '稳赚不赔', '高收益理财',
                '内幕消息', '投资良机', '快速致富', '日赚',
                '保本收益', '无风险投资', '财富自由'
            ],
            'credential_request': [
                '密码', '账号', '验证', 'password', 'verify',
                '确认身份', '更新信息', '安全验证', '登录确认',
                # 新增凭证类关键词
                '银行卡号', '身份证号', '短信验证码', '支付密码'
            ],
            'threat_pressure': [
                '法律诉讼', '警方', '税务', '法院', '逮捕',
                '冻结账户', '信用记录', '征信', '强制执行'
            ],
            # 新增类别：诈骗诱导
            'scam_inducement': [
                '点击链接', '领取奖励', '确认收货', '查看详情',
                '验证账户', '激活账户', '解冻资金', '补全信息'
            ],
            # 新增类别：垃圾邮件
            'spam_indicators': [
                '退订', ' unsubscribe', '广告', '推广', '促销',
                '限时优惠', '特价', '折扣', '优惠券', '秒杀'
            ]
        }
        
        # 系统通知白名单（避免误报）
        self.system_notification_whitelist = [
            # 常见系统发件人域名
            'noreply@', 'no-reply@', 'notification@', 'alert@',
            'system@', 'admin@', 'support@', 'service@',
            # 常见系统发件人域名
            '@github.com', '@gitlab.com', '@stackoverflow.com',
            '@amazon.com', '@aliyun.com', '@tencent.com',
            '@microsoft.com', '@google.com', '@apple.com',
            # 企业内部系统
            '@company.com', '@internal', '@corp.'
        ]
        
        # 诈骗模式
        self.scam_patterns = [
            r'我是.*王子.*需要.*转账',
            r'您已中奖.*请.*领奖',
            r'账户异常.*请.*验证',
            r'系统升级.*请.*确认',
            r'您的.*已过期.*点击.*续期',
            r'恭喜您.*被选中.*领取'
        ]
        
        # 可疑域名后缀
        self.suspicious_tlds = ['.xyz', '.top', '.club', '.work', '.click', '.link']
        
        # 发件人信誉数据库（本地）
        self.sender_reputation = defaultdict(lambda: {'score': 50, 'history': []})
    
    def analyze_email(self, email: Dict[str, Any]) -> SecurityScanResult:
        """
        综合分析邮件威胁
        
        Args:
            email: 邮件数据，包含 from, to, subject, body, headers 等字段
        
        Returns:
            SecurityScanResult: 安全扫描结果
        """
        threats = []
        risk_score = 0.0
        
        # 1. 内容威胁检测
        content_threats = self._analyze_content(email)
        threats.extend(content_threats)
        
        # 2. 发件人分析
        sender_threats = self._analyze_sender(email)
        threats.extend(sender_threats)
        
        # 3. 链接检测
        link_threats = self._analyze_links(email)
        threats.extend(link_threats)
        
        # 4. 附件检测
        attachment_threats = self._analyze_attachments(email)
        threats.extend(attachment_threats)
        
        # 5. 行为模式检测
        behavior_threats = self._analyze_behavior(email)
        threats.extend(behavior_threats)
        
        # 计算风险评分
        risk_score = self._calculate_risk_score(threats)
        
        # 确定威胁等级
        threat_level = self._determine_threat_level(risk_score)
        
        # 生成建议
        recommendations = self._generate_recommendations(threats)
        
        return SecurityScanResult(
            is_safe=(threat_level == ThreatLevel.SAFE),
            threat_level=threat_level,
            threats=threats,
            risk_score=risk_score,
            recommendations=recommendations,
            scan_details={
                'threat_count': len(threats),
                'high_risk_count': len([t for t in threats if t.level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL]]),
                'scan_time': datetime.datetime.now().isoformat()
            }
        )
    
    def _analyze_content(self, email: Dict[str, Any]) -> List[ThreatIndicator]:
        """内容威胁分析"""
        threats = []
        subject = email.get('subject', '')
        body = email.get('body', '')
        sender = email.get('from', '')
        full_text = f"{subject} {body}".lower()
        
        # 白名单检查：系统通知类邮件降低敏感度
        is_system_notification = any(
            whitelist in sender.lower() for whitelist in self.system_notification_whitelist
        )
        
        # 检查钓鱼关键词
        keyword_hits = defaultdict(list)
        for category, keywords in self.phishing_keywords.items():
            for keyword in keywords:
                if keyword.lower() in full_text:
                    keyword_hits[category].append(keyword)
        
        if keyword_hits:
            # 白名单邮件：仅当同时命中多个高风险类别时才报警
            if is_system_notification:
                high_risk_categories = ['urgent_action', 'credential_request']
                hit_count = sum(1 for cat in high_risk_categories if cat in keyword_hits)
                if hit_count < 2:
                    # 单一类别命中，视为安全
                    return threats
            
            # 根据命中的关键词类别计算威胁等级
            high_risk_categories = ['urgent_action', 'credential_request']
            hit_high_risk = any(cat in keyword_hits for cat in high_risk_categories)
            
            level = ThreatLevel.HIGH if hit_high_risk else ThreatLevel.MEDIUM
            
            threats.append(ThreatIndicator(
                threat_type=ThreatType.PHISHING,
                level=level,
                confidence=0.7 if hit_high_risk else 0.5,
                description=f"检测到钓鱼关键词：{dict(keyword_hits)}",
                evidence=list(keyword_hits.keys()),
                remediation="请谨慎对待此邮件，不要点击任何链接或提供敏感信息"
            ))
        
        # 检查诈骗模式
        for pattern in self.scam_patterns:
            if re.search(pattern, full_text, re.IGNORECASE):
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SCAM,
                    level=ThreatLevel.HIGH,
                    confidence=0.85,
                    description=f"匹配诈骗模式：{pattern}",
                    evidence=[pattern],
                    remediation="此邮件疑似诈骗邮件，建议直接删除"
                ))
        
        return threats
    
    def _analyze_sender(self, email: Dict[str, Any]) -> List[ThreatIndicator]:
        """发件人分析"""
        threats = []
        sender = email.get('from', '')
        
        # 检查发件人域名
        if '@' in sender:
            domain = sender.split('@')[1]
            
            # 检查可疑TLD
            for tld in self.suspicious_tlds:
                if domain.endswith(tld):
                    threats.append(ThreatIndicator(
                        threat_type=ThreatType.SPOOFING,
                        level=ThreatLevel.MEDIUM,
                        confidence=0.6,
                        description=f"发件人使用可疑域名后缀：{tld}",
                        evidence=[domain],
                        remediation="建议验证发件人身份真实性"
                    ))
            
            # 检查发件人信誉
            reputation = self.sender_reputation[sender]
            if reputation['score'] < 30:
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SPAM,
                    level=ThreatLevel.LOW,
                    confidence=0.5,
                    description=f"发件人信誉评分过低：{reputation['score']}",
                    evidence=[f"信誉分数: {reputation['score']}"],
                    remediation="此发件人历史记录较差，建议谨慎处理"
                ))
        
        # 检查显示名称与邮箱是否匹配
        display_name = email.get('from_name', '')
        if display_name:
            # 常见的伪造模式：显示名称是知名公司，但邮箱不是
            trusted_domains = {
                'paypal': 'paypal.com',
                'amazon': 'amazon.com',
                'apple': 'apple.com',
                'microsoft': 'microsoft.com',
                'google': 'google.com',
                'alibaba': 'alibaba.com',
                'taobao': 'taobao.com',
                'jd': 'jd.com'
            }
            
            for brand, real_domain in trusted_domains.items():
                if brand in display_name.lower() and sender:
                    sender_domain = sender.split('@')[1] if '@' in sender else ''
                    if real_domain not in sender_domain:
                        threats.append(ThreatIndicator(
                            threat_type=ThreatType.SPOOFING,
                            level=ThreatLevel.HIGH,
                            confidence=0.9,
                            description=f"发件人显示名称与邮箱域名不匹配，疑似伪造",
                            evidence=[f"显示名称: {display_name}", f"邮箱: {sender}"],
                            remediation="此邮件极可能为伪造邮件，请勿信任"
                        ))
        
        return threats
    
    def _analyze_links(self, email: Dict[str, Any]) -> List[ThreatIndicator]:
        """链接分析"""
        threats = []
        body = email.get('body', '')
        
        # 提取URL
        url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
        urls = re.findall(url_pattern, body)
        
        for url in urls:
            # 检查可疑URL特征
            suspicious_features = []
            
            # 1. IP地址作为域名
            if re.match(r'https?://\d+\.\d+\.\d+\.\d+', url):
                suspicious_features.append("使用IP地址作为域名")
            
            # 2. URL过短服务
            shorteners = ['bit.ly', 'tinyurl', 'goo.gl', 't.co', 'ow.ly']
            for shortener in shorteners:
                if shortener in url:
                    suspicious_features.append(f"使用短链接服务：{shortener}")
            
            # 3. 可疑TLD
            for tld in self.suspicious_tlds:
                if tld in url:
                    suspicious_features.append(f"可疑域名后缀：{tld}")
            
            # 4. 混淆字符（@符号）
            if '@' in url and 'mailto:' not in url:
                suspicious_features.append("URL包含@符号，可能存在混淆")
            
            # 5. 子域名过多
            domain_part = url.split('/')[2] if '/' in url[8:] else url[8:]
            if domain_part.count('.') > 3:
                suspicious_features.append("子域名层级过深")
            
            if suspicious_features:
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.MALICIOUS_LINK,
                    level=ThreatLevel.HIGH if len(suspicious_features) > 2 else ThreatLevel.MEDIUM,
                    confidence=0.7,
                    description=f"检测到可疑链接：{url}",
                    evidence=suspicious_features,
                    remediation="不要点击此链接，建议手动输入官方网站地址"
                ))
        
        return threats
    
    def _analyze_attachments(self, email: Dict[str, Any]) -> List[ThreatIndicator]:
        """附件分析"""
        threats = []
        attachments = email.get('attachments', [])
        
        # 高风险文件扩展名
        dangerous_extensions = [
            '.exe', '.scr', '.bat', '.cmd', '.com', '.pif', '.vbs', '.js',
            '.jar', '.msi', '.dll', '.reg', '.ps1', '.sh', '.deb', '.rpm'
        ]
        
        # 双重扩展名模式
        double_extension_pattern = r'\.\w+\.\w+$'
        
        for attachment in attachments:
            filename = attachment.get('filename', '') if isinstance(attachment, dict) else str(attachment)
            ext = '.' + filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            
            # 检查危险扩展名
            if ext in dangerous_extensions:
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                    level=ThreatLevel.CRITICAL,
                    confidence=0.95,
                    description=f"附件包含可执行文件：{filename}",
                    evidence=[f"文件扩展名: {ext}"],
                    remediation="此附件极可能包含恶意软件，请勿打开"
                ))
            
            # 检查双重扩展名
            if re.search(double_extension_pattern, filename):
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                    level=ThreatLevel.HIGH,
                    confidence=0.85,
                    description=f"附件使用双重扩展名：{filename}",
                    evidence=[f"文件名: {filename}"],
                    remediation="此文件名疑似伪装，请谨慎处理"
                ))
            
            # 检查加密压缩文件
            if ext in ['.zip', '.rar', '.7z'] and attachment.get('encrypted', False):
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                    level=ThreatLevel.MEDIUM,
                    confidence=0.6,
                    description=f"附件为加密压缩文件：{filename}",
                    evidence=["加密压缩文件"],
                    remediation="加密附件无法扫描，请确认来源后再打开"
                ))
        
        return threats
    
    def _analyze_behavior(self, email: Dict[str, Any]) -> List[ThreatIndicator]:
        """行为模式分析"""
        threats = []
        
        # 检查邮件头信息
        headers = email.get('headers', {})
        
        # 1. 检查SPF/DKIM/DMARC
        spf = headers.get('Received-SPF', '')
        if 'fail' in spf.lower():
            threats.append(ThreatIndicator(
                threat_type=ThreatType.SPOOFING,
                level=ThreatLevel.HIGH,
                confidence=0.85,
                description="SPF验证失败，发件人可能被伪造",
                evidence=[f"SPF结果: {spf}"],
                remediation="此邮件发件人验证失败，建议不要信任"
            ))
        
        # 2. 检查邮件路由异常
        received = headers.get('Received', [])
        if isinstance(received, list) and len(received) > 5:
            threats.append(ThreatIndicator(
                threat_type=ThreatType.SPOOFING,
                level=ThreatLevel.MEDIUM,
                confidence=0.5,
                description=f"邮件经过过多服务器中转：{len(received)}次",
                evidence=[f"中转次数: {len(received)}"],
                remediation="邮件路由异常，可能是转发或伪造"
            ))
        
        # 3. 检查时间异常
        date_str = headers.get('Date', '')
        if date_str:
            # 这里可以添加时间解析和异常检测逻辑
            pass
        
        return threats
    
    def _calculate_risk_score(self, threats: List[ThreatIndicator]) -> float:
        """计算风险评分 (0-100)"""
        if not threats:
            return 0.0
        
        # 不同威胁等级的权重
        weights = {
            ThreatLevel.LOW: 10,
            ThreatLevel.MEDIUM: 25,
            ThreatLevel.HIGH: 50,
            ThreatLevel.CRITICAL: 80
        }
        
        # 计算加权分数
        total_score = sum(
            weights.get(t.level, 0) * t.confidence
            for t in threats
        )
        
        # 归一化到0-100
        max_possible = len(threats) * 80
        risk_score = min(100, (total_score / max_possible) * 100) if max_possible > 0 else 0
        
        return round(risk_score, 2)
    
    def _determine_threat_level(self, risk_score: float) -> ThreatLevel:
        """确定威胁等级"""
        if risk_score >= 70:
            return ThreatLevel.CRITICAL
        elif risk_score >= 50:
            return ThreatLevel.HIGH
        elif risk_score >= 30:
            return ThreatLevel.MEDIUM
        elif risk_score >= 10:
            return ThreatLevel.LOW
        return ThreatLevel.SAFE
    
    def _generate_recommendations(self, threats: List[ThreatIndicator]) -> List[str]:
        """生成安全建议"""
        recommendations = []
        
        if not threats:
            return ["邮件安全检测通过"]
        
        # 收集所有威胁的处理建议
        seen_remediations = set()
        for threat in threats:
            if threat.remediation and threat.remediation not in seen_remediations:
                recommendations.append(threat.remediation)
                seen_remediations.add(threat.remediation)
        
        # 添加通用建议
        high_risk = any(t.level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL] for t in threats)
        if high_risk:
            recommendations.insert(0, "⚠️ 此邮件存在高风险威胁，建议立即删除或隔离")
        
        return recommendations[:5]  # 限制最多5条建议
    
    def update_sender_reputation(self, sender: str, is_malicious: bool):
        """更新发件人信誉"""
        if is_malicious:
            self.sender_reputation[sender]['score'] = max(0, 
                self.sender_reputation[sender]['score'] - 20)
        else:
            self.sender_reputation[sender]['score'] = min(100, 
                self.sender_reputation[sender]['score'] + 5)
        
        self.sender_reputation[sender]['history'].append({
            'timestamp': datetime.datetime.now().isoformat(),
            'is_malicious': is_malicious
        })


# ==================== 2. 恶意链接检测 ====================

class MaliciousLinkDetector:
    """
    恶意链接检测器
    本地URL特征分析，无需外部网络请求
    """
    
    def __init__(self):
        # 已知恶意域名特征库（本地）
        self.malicious_patterns = [
            r'paypal.*\.(?!com)',  # 伪造PayPal域名
            r'amazon.*\.(?!com)',   # 伪造Amazon域名
            r'apple.*\.(?!com)',    # 伪造Apple域名
            r'banking.*secure',     # 银行钓鱼
            r'verify.*account',     # 账号验证钓鱼
            r'secure.*login',       # 登录钓鱼
        ]
        
        # URL混淆技术特征
        self.obfuscation_patterns = {
            'hex_encoding': r'%[0-9A-Fa-f]{2}',
            'unicode_escape': r'\\u[0-9A-Fa-f]{4}',
            'ip_address': r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',
            'data_uri': r'data:',
            'redirect_param': r'[?&](redirect|url|next|target)=',
        }
    
    def check_url(self, url: str) -> Tuple[bool, List[str], str]:
        """
        检查URL安全性
        
        Args:
            url: 待检查的URL
        
        Returns:
            (is_safe, threats, analysis)
        """
        threats = []
        
        # 1. 检查恶意模式
        for pattern in self.malicious_patterns:
            if re.search(pattern, url, re.IGNORECASE):
                threats.append(f"匹配恶意域名模式: {pattern}")
        
        # 2. 检查混淆技术
        for tech_name, pattern in self.obfuscation_patterns.items():
            if re.search(pattern, url, re.IGNORECASE):
                threats.append(f"检测到{tech_name}混淆技术")
        
        # 3. 检查HTTPS
        if not url.startswith('https://'):
            threats.append("URL未使用HTTPS加密")
        
        # 4. 检查可疑参数
        suspicious_params = ['cmd', 'exec', 'system', 'password', 'token']
        for param in suspicious_params:
            if re.search(rf'[?&]{param}=', url, re.IGNORECASE):
                threats.append(f"URL包含可疑参数: {param}")
        
        # 生成分析报告
        analysis = self._generate_url_analysis(url, threats)
        
        is_safe = len(threats) == 0
        return is_safe, threats, analysis
    
    def _generate_url_analysis(self, url: str, threats: List[str]) -> str:
        """生成URL分析报告"""
        if not threats:
            return "URL安全检测通过，未发现明显威胁特征"
        
        return f"URL: {url}\n威胁: {len(threats)}项\n详情: {'; '.join(threats)}"


# ==================== 3. 钓鱼邮件识别 ====================

class PhishingDetector:
    """
    钓鱼邮件识别器
    多特征融合检测，本地运行
    """
    
    def __init__(self):
        # 社交工程学特征（扩展到8类）
        self.social_engineering_features = {
            # 原有类别
            'urgency_words': ['紧急', '立即', '马上', 'urgent', 'immediately', '限时', '最后机会', '即将过期'],
            'authority_words': ['银行', '警察', '政府', '法院', 'tax', 'police', '官方', '系统', 'security'],
            'fear_words': ['冻结', '封号', '处罚', 'suspend', 'penalty', '风险', '异常', '警告', 'danger'],
            'greed_words': ['中奖', '优惠', '免费', 'winner', 'free', '折扣', '返现', '红包', 'bonus'],
            # 新增类别
            'curiosity_words': ['秘密', '震惊', '不看后悔', 'secret', 'exclusive', '内幕', '揭秘'],
            'social_proof': ['您的好友', '大家都在', '已有人', 'popular', 'trending', '热门'],
            'scarcity_words': ['仅剩', '最后', '限量', 'limited', 'only', '售罄', '名额有限'],
            'emotional_words': ['亲', '亲爱的', 'dear', '遗憾', '抱歉', '恭喜', '遗憾通知'],
            # 新增：中奖诈骗专用
            'lottery_scam': ['恭喜', '现金大奖', '免费领取', '获奖通知', '被选中', '幸运用户', '领取奖金', '奖品', '大奖'],
            # 新增：金融诈骗专用
            'financial_fraud': ['月收益', '高回报', '稳赚不赔', '高收益理财', '内幕消息', '投资良机', '快速致富', '日赚', '保本收益', '无风险投资']
        }
        
        # 钓鱼页面特征（邮件内容中）
        self.phishing_page_indicators = [
            '请输入密码', 'please enter password',
            '验证您的身份', 'verify your identity',
            '更新支付信息', 'update payment',
            '确认您的账户', 'confirm your account',
        ]
        
        # 常见钓鱼模板特征（扩展到15+场景）
        self.phishing_templates = {
            # 原有模板
            'account_suspension': {
                'subject_pattern': r'(账户|account).*(暂停|suspend|锁定|冻结|异常)',
                'body_pattern': r'(验证|verify|确认).*(身份|identity|信息|账户)',
                'weight': 0.85
            },
            'payment_request': {
                'subject_pattern': r'(发票|invoice|付款|payment|账单)',
                'body_pattern': r'(点击|click).*(支付|pay|下载|download|查看)',
                'weight': 0.75
            },
            'lottery_scam': {
                'subject_pattern': r'(恭喜|congratulations).*(中奖|winner|获奖)',
                'body_pattern': r'(领取|claim).*(奖金|prize|奖品)',
                'weight': 0.95
            },
            # 新增模板 - 订单相关
            'order_exception': {
                'subject_pattern': r'(订单|order).*(异常|问题|失败|取消|退款)',
                'body_pattern': r'(点击|click).*(确认|confirm|处理|verify).*(订单|order)',
                'weight': 0.8
            },
            'delivery_notice': {
                'subject_pattern': r'(快递|delivery|包裹|package|物流).*(通知|notice|到达)',
                'body_pattern': r'(点击|click).*(取件|pickup|查看详情|track|确认收货)',
                'weight': 0.75
            },
            # 新增模板 - 账户安全
            'password_reset': {
                'subject_pattern': r'(密码|password).*(重置|reset|修改|change|过期)',
                'body_pattern': r'(点击|click).*(重置|reset|修改|change).*(密码|password)',
                'weight': 0.85
            },
            'login_alert': {
                'subject_pattern': r'(登录|login|登录异常|unusual activity)',
                'body_pattern': r'(验证|verify|确认|confirm).*(登录|login|身份)',
                'weight': 0.8
            },
            # 新增模板 - 政府机构
            'tax_notice': {
                'subject_pattern': r'(税务|tax|税务局|irs).*(通知|notice|退税|refund)',
                'body_pattern': r'(点击|click).*(申报|file|验证|verify|领取)',
                'weight': 0.9
            },
            'legal_notice': {
                'subject_pattern': r'(法律|legal|法院|court|传票|summons)',
                'body_pattern': r'(点击|click).*(查看|view|处理|respond|下载)',
                'weight': 0.85
            },
            # 新增模板 - 银行金融
            'bank_alert': {
                'subject_pattern': r'(银行|bank).*(通知|alert|警告|warning|安全)',
                'body_pattern': r'(点击|click).*(验证|verify|确认|confirm).*(账户|account)',
                'weight': 0.9
            },
            'credit_card': {
                'subject_pattern': r'(信用卡|credit card).*(账单|statement|消费|charge)',
                'body_pattern': r'(点击|click).*(查看|view|确认|confirm|支付)',
                'weight': 0.85
            },
            # 新增模板 - 企业伪装
            'hr_notification': {
                'subject_pattern': r'(人事|hr|人力资源).*(通知|notice|公告)',
                'body_pattern': r'(点击|click).*(查看|view|下载|download|确认)',
                'weight': 0.7
            },
            'it_support': {
                'subject_pattern': r'(IT|技术支持|support).*(通知|notice|系统|system)',
                'body_pattern': r'(点击|click).*(升级|upgrade|更新|update|验证)',
                'weight': 0.75
            },
            # 新增模板 - 社交诱导
            'social_proof': {
                'subject_pattern': r'(您的好友|your friend|有人).*(查看|viewed|访问|visited)',
                'body_pattern': r'(点击|click).*(查看|view|了解|see)',
                'weight': 0.6
            },
            'curiosity_bait': {
                'subject_pattern': r'(秘密|secret|震惊|shocking|不看后悔|must see)',
                'body_pattern': r'(点击|click).*(查看|view|了解|see|揭秘)',
                'weight': 0.65
            }
        }
    
    def detect(self, email: Dict[str, Any]) -> Tuple[bool, float, List[str]]:
        """
        检测钓鱼邮件
        
        Args:
            email: 邮件数据
        
        Returns:
            (is_phishing, confidence, evidence)
        """
        evidence = []
        phishing_score = 0.0
        
        subject = email.get('subject', '')
        body = email.get('body', '')
        full_text = f"{subject} {body}"
        
        # 1. 检查社交工程学特征
        for feature_type, keywords in self.social_engineering_features.items():
            matches = [kw for kw in keywords if kw.lower() in full_text.lower()]
            if len(matches) >= 2:  # 多个特征同时出现
                phishing_score += 0.2
                evidence.append(f"发现{feature_type}特征: {matches}")
        
        # 2. 检查钓鱼页面指标
        for indicator in self.phishing_page_indicators:
            if indicator.lower() in full_text.lower():
                phishing_score += 0.15
                evidence.append(f"发现钓鱼页面指标: {indicator}")
        
        # 3. 匹配钓鱼模板
        for template_name, template in self.phishing_templates.items():
            subject_match = re.search(template['subject_pattern'], subject, re.IGNORECASE)
            body_match = re.search(template['body_pattern'], body, re.IGNORECASE)
            
            if subject_match and body_match:
                phishing_score += template['weight'] * 0.3
                evidence.append(f"匹配钓鱼模板: {template_name}")
        
        # 判断是否为钓鱼邮件
        is_phishing = phishing_score >= 0.5
        confidence = min(1.0, phishing_score)
        
        return is_phishing, confidence, evidence


# ==================== 4. 附件安全扫描 ====================

class AttachmentScanner:
    """
    附件安全扫描器
    本地文件分析，不依赖云服务
    """
    
    def __init__(self):
        # 文件类型风险等级
        self.file_type_risk = {
            # 高风险
            '.exe': 'critical', '.scr': 'critical', '.bat': 'critical',
            '.cmd': 'critical', '.com': 'critical', '.pif': 'critical',
            '.vbs': 'critical', '.js': 'critical', '.jar': 'high',
            
            # 中风险
            '.doc': 'medium', '.xls': 'medium', '.ppt': 'medium',
            '.docm': 'high', '.xlsm': 'high', '.pptm': 'high',  # 带宏
            
            # 低风险
            '.pdf': 'low', '.txt': 'safe', '.jpg': 'safe',
            '.png': 'safe', '.gif': 'safe'
        }
        
        # 可疑文件名模式
        self.suspicious_patterns = [
            r'password.*\.(zip|rar|7z)',  # 密码保护的压缩文件
            r'.*\.(exe|scr)\.zip',        # 压缩包中的可执行文件
            r'document.*\.exe',           # 伪装成文档的可执行文件
        ]
    
    def scan(self, attachment: Dict[str, Any]) -> SecurityScanResult:
        """
        扫描附件安全性
        
        Args:
            attachment: 附件信息，包含filename, size, content等
        
        Returns:
            SecurityScanResult: 扫描结果
        """
        threats = []
        filename = attachment.get('filename', '')
        size = attachment.get('size', 0)
        content = attachment.get('content', b'')
        
        # 1. 检查文件扩展名
        ext = '.' + filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
        risk_level = self.file_type_risk.get(ext, 'medium')
        
        if risk_level in ['critical', 'high']:
            threats.append(ThreatIndicator(
                threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                level=ThreatLevel[risk_level.upper()],
                confidence=0.9,
                description=f"高风险文件类型: {ext}",
                evidence=[f"扩展名: {ext}", f"风险等级: {risk_level}"],
                remediation=f"建议不要打开.{ext}文件，除非您完全信任来源"
            ))
        
        # 2. 检查文件名模式
        for pattern in self.suspicious_patterns:
            if re.search(pattern, filename, re.IGNORECASE):
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                    level=ThreatLevel.HIGH,
                    confidence=0.85,
                    description="可疑文件名模式",
                    evidence=[f"文件名: {filename}", f"匹配模式: {pattern}"],
                    remediation="此文件名具有可疑特征，建议谨慎处理"
                ))
        
        # 3. 检查文件大小异常
        if size > 50 * 1024 * 1024:  # 50MB
            threats.append(ThreatIndicator(
                threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                level=ThreatLevel.MEDIUM,
                confidence=0.5,
                description=f"附件体积过大: {size / (1024*1024):.2f}MB",
                evidence=[f"文件大小: {size} bytes"],
                remediation="大文件可能包含隐藏内容，建议确认后打开"
            ))
        
        # 4. 检查文件内容特征（如果有内容）
        if content:
            content_threats = self._analyze_content(content, ext)
            threats.extend(content_threats)
        
        # 计算风险评分
        risk_score = self._calculate_risk_score(threats)
        threat_level = self._determine_threat_level(risk_score)
        
        return SecurityScanResult(
            is_safe=(threat_level == ThreatLevel.SAFE),
            threat_level=threat_level,
            threats=threats,
            risk_score=risk_score,
            recommendations=[t.remediation for t in threats if t.remediation][:3],
            scan_details={'filename': filename, 'size': size, 'ext': ext}
        )
    
    def _analyze_content(self, content: bytes, ext: str) -> List[ThreatIndicator]:
        """分析文件内容特征"""
        threats = []
        
        # 检查文件魔数（文件头）
        magic_numbers = {
            b'MZ': 'executable',      # Windows可执行文件
            b'\x7fELF': 'executable', # Linux可执行文件
            b'PK\x03\x04': 'archive', # ZIP文件
            b'%PDF': 'pdf',
        }
        
        for magic, file_type in magic_numbers.items():
            if content.startswith(magic):
                if file_type == 'executable' and ext not in ['.exe', '.dll']:
                    threats.append(ThreatIndicator(
                        threat_type=ThreatType.MALWARE,
                        level=ThreatLevel.CRITICAL,
                        confidence=0.95,
                        description="文件内容与扩展名不匹配，疑似伪装",
                        evidence=[f"实际类型: {file_type}", f"声称扩展名: {ext}"],
                        remediation="此文件极可能为恶意软件，请勿打开"
                    ))
        
        # 检查可疑字符串
        suspicious_strings = [
            b'powershell', b'cmd.exe', b'wscript', b'eval(',
            b'exec(', b'system(', b'shell', b'backdoor'
        ]
        
        content_lower = content.lower()[:10000]  # 只检查前10KB
        found_strings = [s.decode('utf-8', errors='ignore') for s in suspicious_strings if s in content_lower]
        
        if found_strings:
            threats.append(ThreatIndicator(
                threat_type=ThreatType.MALWARE,
                level=ThreatLevel.HIGH,
                confidence=0.8,
                description=f"检测到可疑字符串: {found_strings}",
                evidence=found_strings,
                remediation="文件包含潜在恶意代码特征，建议隔离检查"
            ))
        
        return threats
    
    def _calculate_risk_score(self, threats: List[ThreatIndicator]) -> float:
        """计算风险评分"""
        if not threats:
            return 0.0
        
        weights = {
            ThreatLevel.LOW: 15,
            ThreatLevel.MEDIUM: 35,
            ThreatLevel.HIGH: 65,
            ThreatLevel.CRITICAL: 95
        }
        
        max_score = max(weights.get(t.level, 0) * t.confidence for t in threats)
        return min(100, max_score)
    
    def _determine_threat_level(self, risk_score: float) -> ThreatLevel:
        """确定威胁等级"""
        if risk_score >= 80:
            return ThreatLevel.CRITICAL
        elif risk_score >= 60:
            return ThreatLevel.HIGH
        elif risk_score >= 35:
            return ThreatLevel.MEDIUM
        elif risk_score > 0:
            return ThreatLevel.LOW
        return ThreatLevel.SAFE


# ==================== 5. 行为分析引擎 ====================

class BehaviorAnalyzer:
    """
    行为分析引擎
    基于历史行为模式检测异常
    """
    
    def __init__(self):
        # 用户行为基线（示例数据）
        self.user_baseline = {
            'avg_emails_per_day': 50,
            'avg_attachment_size': 2 * 1024 * 1024,  # 2MB
            'common_senders': ['colleague@company.com', 'hr@company.com'],
            'common_time_range': (9, 18),  # 9:00-18:00
        }
        
        # 异常行为阈值
        self.thresholds = {
            'email_volume_multiplier': 5,  # 邮件量超过平均值5倍
            'unusual_time_range': [(0, 6), (22, 24)],  # 异常时间段
            'large_attachment_threshold': 20 * 1024 * 1024,  # 20MB
        }
        
        # 行为历史记录
        self.behavior_history = defaultdict(list)
    
    def analyze(self, email: Dict[str, Any], user_id: str) -> List[ThreatIndicator]:
        """
        分析邮件行为异常
        
        Args:
            email: 邮件数据
            user_id: 用户ID
        
        Returns:
            威胁指标列表
        """
        threats = []
        
        # 1. 检查发送时间
        send_time = email.get('timestamp', '')
        if send_time:
            try:
                hour = int(send_time.split('T')[1].split(':')[0])
                for start, end in self.thresholds['unusual_time_range']:
                    if start <= hour < end:
                        threats.append(ThreatIndicator(
                            threat_type=ThreatType.SPOOFING,
                            level=ThreatLevel.LOW,
                            confidence=0.4,
                            description=f"邮件发送时间异常: {hour}:00",
                            evidence=[f"发送时间: {send_time}"],
                            remediation="邮件在非常规时间发送，建议确认发件人"
                        ))
            except:
                pass
        
        # 2. 检查发件人是否为常见联系人
        sender = email.get('from', '')
        if sender and sender not in self.user_baseline['common_senders']:
            threats.append(ThreatIndicator(
                threat_type=ThreatType.SPOOFING,
                level=ThreatLevel.LOW,
                confidence=0.3,
                description="发件人不在常见联系人列表中",
                evidence=[f"发件人: {sender}"],
                remediation="这是新发件人，请确认其真实性"
            ))
        
        # 3. 检查附件大小
        attachments = email.get('attachments', [])
        for attachment in attachments:
            size = attachment.get('size', 0) if isinstance(attachment, dict) else 0
            if size > self.thresholds['large_attachment_threshold']:
                threats.append(ThreatIndicator(
                    threat_type=ThreatType.SUSPICIOUS_ATTACHMENT,
                    level=ThreatLevel.MEDIUM,
                    confidence=0.5,
                    description=f"附件体积异常大: {size / (1024*1024):.2f}MB",
                    evidence=[f"附件大小: {size} bytes"],
                    remediation="异常大的附件可能存在问题，建议确认后下载"
                ))
        
        # 4. 更新行为历史
        self.behavior_history[user_id].append({
            'timestamp': send_time,
            'sender': sender,
            'has_attachment': len(attachments) > 0
        })
        
        # 保持历史记录在合理范围
        if len(self.behavior_history[user_id]) > 1000:
            self.behavior_history[user_id] = self.behavior_history[user_id][-500:]
        
        return threats
    
    def detect_anomaly(self, user_id: str, time_window_hours: int = 24) -> List[Dict]:
        """
        检测时间窗口内的行为异常
        
        Args:
            user_id: 用户ID
            time_window_hours: 时间窗口（小时）
        
        Returns:
            异常事件列表
        """
        anomalies = []
        history = self.behavior_history.get(user_id, [])
        
        # 统计邮件量
        email_count = len(history)
        if email_count > self.user_baseline['avg_emails_per_day'] * self.thresholds['email_volume_multiplier']:
            anomalies.append({
                'type': 'volume_anomaly',
                'severity': 'high',
                'description': f"邮件量异常: {email_count}封，超过平均值{self.thresholds['email_volume_multiplier']}倍",
                'recommendation': '可能存在账号被盗或垃圾邮件攻击'
            })
        
        return anomalies


# ==================== 6. 安全审计日志 ====================

class SecurityAuditLogger:
    """
    安全审计日志记录器
    记录所有安全相关操作，支持追溯
    """
    
    def __init__(self, log_file: str = "security_audit.log"):
        self.log_file = log_file
        self.logs: List[AuditLog] = []
    
    def log(self, action: str, user: str, resource: str, result: str, details: Dict = None):
        """
        记录审计日志
        
        Args:
            action: 操作类型
            user: 操作用户
            resource: 操作资源
            result: 操作结果
            details: 详细信息
        """
        log_entry = AuditLog(
            timestamp=datetime.datetime.now().isoformat(),
            action=action,
            user=user,
            resource=resource,
            result=result,
            details=details or {}
        )
        
        self.logs.append(log_entry)
        
        # 保存到文件
        self._save_log(log_entry)
    
    def _save_log(self, log: AuditLog):
        """保存日志到文件"""
        log_str = f"[{log.timestamp}] [{log.action}] user={log.user} resource={log.resource} result={log.result}"
        if log.details:
            log_str += f" details={json.dumps(log.details)}"
        log_str += "\n"
        
        # 这里实际应该写入文件，沙箱环境下先存储在内存
        # with open(self.log_file, 'a', encoding='utf-8') as f:
        #     f.write(log_str)
    
    def query_logs(self, start_time: str = None, end_time: str = None, 
                   action: str = None, user: str = None) -> List[AuditLog]:
        """
        查询审计日志
        
        Args:
            start_time: 开始时间
            end_time: 结束时间
            action: 操作类型
            user: 用户
        
        Returns:
            符合条件的日志列表
        """
        filtered = self.logs
        
        if action:
            filtered = [log for log in filtered if log.action == action]
        
        if user:
            filtered = [log for log in filtered if log.user == user]
        
        if start_time:
            filtered = [log for log in filtered if log.timestamp >= start_time]
        
        if end_time:
            filtered = [log for log in filtered if log.timestamp <= end_time]
        
        return filtered
    
    def export_logs(self, format: str = 'json') -> str:
        """
        导出审计日志
        
        Args:
            format: 导出格式 (json/csv)
        
        Returns:
            导出的日志内容
        """
        if format == 'json':
            return json.dumps([{
                'timestamp': log.timestamp,
                'action': log.action,
                'user': log.user,
                'resource': log.resource,
                'result': log.result,
                'details': log.details
            } for log in self.logs], indent=2, ensure_ascii=False)
        
        elif format == 'csv':
            lines = ['timestamp,action,user,resource,result']
            for log in self.logs:
                lines.append(f'{log.timestamp},{log.action},{log.user},{log.resource},{log.result}')
            return '\n'.join(lines)
        
        return ""


# ==================== 7. 应急响应模块 ====================

class IncidentResponseHandler:
    """
    应急响应处理器
    自动化响应安全事件
    """
    
    def __init__(self, audit_logger: SecurityAuditLogger):
        self.audit_logger = audit_logger
        
        # 响应策略配置
        self.response_policies = {
            ThreatLevel.CRITICAL: {
                'actions': ['quarantine', 'alert_admin', 'block_sender'],
                'notify': True,
                'auto_resolve': False
            },
            ThreatLevel.HIGH: {
                'actions': ['quarantine', 'alert_user'],
                'notify': True,
                'auto_resolve': False
            },
            ThreatLevel.MEDIUM: {
                'actions': ['mark_suspicious', 'alert_user'],
                'notify': False,
                'auto_resolve': True
            },
            ThreatLevel.LOW: {
                'actions': ['add_tag'],
                'notify': False,
                'auto_resolve': True
            }
        }
        
        # 处理的事件记录
        self.incidents: List[Dict] = []
    
    def handle(self, scan_result: SecurityScanResult, email: Dict[str, Any], 
               user_id: str = "system") -> Dict[str, Any]:
        """
        处理安全事件
        
        Args:
            scan_result: 安全扫描结果
            email: 邮件数据
            user_id: 用户ID
        
        Returns:
            处理结果
        """
        policy = self.response_policies.get(scan_result.threat_level, {})
        actions_taken = []
        
        # 执行响应动作
        for action in policy.get('actions', []):
            result = self._execute_action(action, email, scan_result)
            actions_taken.append({
                'action': action,
                'result': result,
                'timestamp': datetime.datetime.now().isoformat()
            })
        
        # 记录审计日志
        self.audit_logger.log(
            action='incident_response',
            user=user_id,
            resource=email.get('id', 'unknown'),
            result='handled',
            details={
                'threat_level': scan_result.threat_level.value,
                'risk_score': scan_result.risk_score,
                'actions_taken': [a['action'] for a in actions_taken]
            }
        )
        
        # 记录事件
        incident = {
            'id': hashlib.md5(f"{email.get('id', '')}{datetime.datetime.now().isoformat()}".encode()).hexdigest()[:12],
            'timestamp': datetime.datetime.now().isoformat(),
            'threat_level': scan_result.threat_level.value,
            'risk_score': scan_result.risk_score,
            'email_id': email.get('id', 'unknown'),
            'sender': email.get('from', 'unknown'),
            'actions_taken': actions_taken,
            'resolved': policy.get('auto_resolve', False)
        }
        self.incidents.append(incident)
        
        return {
            'incident_id': incident['id'],
            'threat_level': scan_result.threat_level.value,
            'actions_taken': actions_taken,
            'notification_sent': policy.get('notify', False),
            'auto_resolved': policy.get('auto_resolve', False)
        }
    
    def _execute_action(self, action: str, email: Dict[str, Any], 
                        scan_result: SecurityScanResult) -> str:
        """
        执行响应动作
        
        Args:
            action: 动作类型
            email: 邮件数据
            scan_result: 扫描结果
        
        Returns:
            执行结果
        """
        action_handlers = {
            'quarantine': self._quarantine_email,
            'alert_admin': self._alert_admin,
            'alert_user': self._alert_user,
            'block_sender': self._block_sender,
            'mark_suspicious': self._mark_suspicious,
            'add_tag': self._add_tag
        }
        
        handler = action_handlers.get(action)
        if handler:
            return handler(email, scan_result)
        
        return f"Unknown action: {action}"
    
    def _quarantine_email(self, email: Dict[str, Any], scan_result: SecurityScanResult) -> str:
        """隔离邮件"""
        email_id = email.get('id', 'unknown')
        # 实际实现中会将邮件移动到隔离区
        return f"Email {email_id} has been quarantined"
    
    def _alert_admin(self, email: Dict[str, Any], scan_result: SecurityScanResult) -> str:
        """通知管理员"""
        # 实际实现中会发送通知给管理员
        return f"Admin alerted about threat level {scan_result.threat_level.value}"
    
    def _alert_user(self, email: Dict[str, Any], scan_result: SecurityScanResult) -> str:
        """通知用户"""
        # 实际实现中会发送通知给用户
        return f"User alerted about suspicious email"
    
    def _block_sender(self, email: Dict[str, Any], scan_result: SecurityScanResult) -> str:
        """封锁发件人"""
        sender = email.get('from', 'unknown')
        # 实际实现中会将发件人加入黑名单
        return f"Sender {sender} has been blocked"
    
    def _mark_suspicious(self, email: Dict[str, Any], scan_result: SecurityScanResult) -> str:
        """标记为可疑"""
        email_id = email.get('id', 'unknown')
        return f"Email {email_id} marked as suspicious"
    
    def _add_tag(self, email: Dict[str, Any], scan_result: SecurityScanResult) -> str:
        """添加标签"""
        email_id = email.get('id', 'unknown')
        tag = f"security:{scan_result.threat_level.value}"
        return f"Tag '{tag}' added to email {email_id}"
    
    def get_incident_stats(self, days: int = 7) -> Dict[str, Any]:
        """
        获取事件统计
        
        Args:
            days: 统计天数
        
        Returns:
            统计结果
        """
        cutoff = (datetime.datetime.now() - datetime.timedelta(days=days)).isoformat()
        recent_incidents = [i for i in self.incidents if i['timestamp'] >= cutoff]
        
        # 按威胁等级统计
        level_counts = defaultdict(int)
        for incident in recent_incidents:
            level_counts[incident['threat_level']] += 1
        
        return {
            'total_incidents': len(recent_incidents),
            'by_level': dict(level_counts),
            'resolved_count': len([i for i in recent_incidents if i['resolved']]),
            'top_senders': self._get_top_threat_senders(recent_incidents)
        }
    
    def _get_top_threat_senders(self, incidents: List[Dict]) -> List[Dict]:
        """获取威胁最多的发件人"""
        sender_counts = defaultdict(int)
        for incident in incidents:
            sender_counts[incident.get('sender', 'unknown')] += 1
        
        return sorted(
            [{'sender': k, 'count': v} for k, v in sender_counts.items()],
            key=lambda x: x['count'],
            reverse=True
        )[:10]


# ==================== 垃圾邮件检测器 ====================

class SpamDetector:
    """
    垃圾邮件检测器
    本地特征分析，支持多种垃圾邮件类型
    """
    
    def __init__(self):
        # 垃圾邮件特征库
        self.spam_indicators = {
            # 广告推销类
            'advertising': [
                '退订', 'unsubscribe', '广告', '推广', '促销',
                '限时优惠', '特价', '折扣', '优惠券', '秒杀',
                '新品上市', '热销', '爆款', '抢购', '清仓'
            ],
            # 药品类
            'pharmaceutical': [
                '壮阳', '减肥', '增高', '保健品', '药品',
                '处方药', '伟哥', 'viagra', 'cialis',
                '瘦身', '美白', '祛斑', '治疗', '疗效'
            ],
            # 金融诈骗类
            'financial_scam': [
                '贷款', '信用卡套现', '代开发票', '办证',
                '股票内幕', '投资理财', '私募基金', '外汇',
                '期货', '原油', '贵金属投资', 'p2p理财',
                '月收益', '高回报', '稳赚不赔', '保本收益'
            ],
            # 博彩类
            'gambling': [
                '博彩', '赌博', '赌场', '彩票预测',
                '六合彩', '澳门', '威尼斯人', '百家乐'
            ],
            # 伪造类
            'fake_services': [
                '代写论文', '代考', '办证', '刻章',
                '发票', '签证', '学历', '文凭'
            ]
        }
        
        # 垃圾邮件发件人特征
        self.spam_sender_patterns = [
            r'noreply.*@.*\.(xyz|top|click)',
            r'marketing@',
            r'promo@',
            r'newsletter@',
            r'[\d]{5,}@'  # 纯数字邮箱
        ]
        
        # 垃圾邮件主题特征
        self.spam_subject_patterns = [
            r'^[\[\(].*[\]\)].*优惠',
            r'^Re:.*\(广告\)',
            r'【.*】.*特惠',
            r'★.*★',
            r'☆.*☆'
        ]
    
    def detect(self, email: Dict[str, Any]) -> Tuple[bool, float, List[str]]:
        """
        检测垃圾邮件
        
        Args:
            email: 邮件数据
        
        Returns:
            (is_spam, confidence, evidence)
        """
        evidence = []
        spam_score = 0.0
        
        sender = email.get('from', '').lower()
        subject = email.get('subject', '')
        body = email.get('body', '')
        full_text = f"{subject} {body}".lower()
        
        # 1. 检查发件人特征
        for pattern in self.spam_sender_patterns:
            if re.search(pattern, sender, re.IGNORECASE):
                spam_score += 0.2
                evidence.append(f"发件人匹配垃圾邮件特征: {pattern}")
        
        # 2. 检查主题特征
        for pattern in self.spam_subject_patterns:
            if re.search(pattern, subject, re.IGNORECASE):
                spam_score += 0.15
                evidence.append(f"主题匹配垃圾邮件特征")
        
        # 3. 检查内容特征
        for category, keywords in self.spam_indicators.items():
            matches = [kw for kw in keywords if kw.lower() in full_text]
            if len(matches) >= 2:  # 多个关键词同时出现
                spam_score += 0.25
                evidence.append(f"检测到{category}类关键词: {matches[:3]}")
            elif len(matches) == 1:
                spam_score += 0.1
        
        # 4. 检查垃圾邮件通用特征
        if '退订' in full_text or 'unsubscribe' in full_text:
            spam_score += 0.15
            evidence.append("包含退订链接")
        
        # 判断是否为垃圾邮件
        is_spam = spam_score >= 0.4
        confidence = min(1.0, spam_score)
        
        return is_spam, confidence, evidence


# ==================== 统一安全防御系统 ====================

class EmailSecurityDefenseSystem:
    """
    企业级邮件安全防御系统
    整合所有安全模块的统一接口
    """
    
    def __init__(self):
        # 初始化各模块
        self.threat_engine = ThreatDetectionEngine()
        self.link_detector = MaliciousLinkDetector()
        self.phishing_detector = PhishingDetector()
        self.attachment_scanner = AttachmentScanner()
        self.behavior_analyzer = BehaviorAnalyzer()
        self.audit_logger = SecurityAuditLogger()
        self.incident_handler = IncidentResponseHandler(self.audit_logger)
        self.spam_detector = SpamDetector()  # 新增垃圾邮件检测器
    
    def scan_email(self, email: Dict[str, Any], user_id: str = "system") -> Dict[str, Any]:
        """
        综合扫描邮件
        
        Args:
            email: 邮件数据
            user_id: 用户ID
        
        Returns:
            完整的扫描和响应结果
        """
        # 1. 威胁检测
        threat_result = self.threat_engine.analyze_email(email)
        
        # 2. 钓鱼检测
        is_phishing, phishing_confidence, phishing_evidence = self.phishing_detector.detect(email)
        if is_phishing:
            threat_result.threats.append(ThreatIndicator(
                threat_type=ThreatType.PHISHING,
                level=ThreatLevel.HIGH if phishing_confidence > 0.7 else ThreatLevel.MEDIUM,
                confidence=phishing_confidence,
                description="钓鱼邮件检测",
                evidence=phishing_evidence,
                remediation="此邮件疑似钓鱼邮件，请勿点击任何链接"
            ))
        
        # 3. 垃圾邮件检测
        is_spam, spam_confidence, spam_evidence = self.spam_detector.detect(email)
        if is_spam:
            threat_result.threats.append(ThreatIndicator(
                threat_type=ThreatType.SPAM,
                level=ThreatLevel.MEDIUM if spam_confidence > 0.6 else ThreatLevel.LOW,
                confidence=spam_confidence,
                description="垃圾邮件检测",
                evidence=spam_evidence,
                remediation="此邮件疑似垃圾邮件，建议直接删除"
            ))
        
        # 4. 行为分析
        behavior_threats = self.behavior_analyzer.analyze(email, user_id)
        threat_result.threats.extend(behavior_threats)
        
        # 5. 应急响应
        response_result = self.incident_handler.handle(threat_result, email, user_id)
        
        # 6. 记录审计日志
        self.audit_logger.log(
            action='email_scan',
            user=user_id,
            resource=email.get('id', 'unknown'),
            result='completed',
            details={
                'threat_level': threat_result.threat_level.value,
                'risk_score': threat_result.risk_score,
                'threat_count': len(threat_result.threats)
            }
        )
        
        return {
            'scan_result': {
                'is_safe': threat_result.is_safe,
                'threat_level': threat_result.threat_level.value,
                'risk_score': threat_result.risk_score,
                'threats': [
                    {
                        'type': t.threat_type.value,
                        'level': t.level.value,
                        'confidence': t.confidence,
                        'description': t.description,
                        'evidence': t.evidence,
                        'remediation': t.remediation
                    }
                    for t in threat_result.threats
                ],
                'recommendations': threat_result.recommendations
            },
            'response': response_result,
            'timestamp': datetime.datetime.now().isoformat()
        }
    
    def get_security_report(self, days: int = 7) -> Dict[str, Any]:
        """
        获取安全报告
        
        Args:
            days: 报告周期（天）
        
        Returns:
            安全报告
        """
        incident_stats = self.incident_handler.get_incident_stats(days)
        
        return {
            'report_period': f'{days} days',
            'total_incidents': incident_stats['total_incidents'],
            'incidents_by_level': incident_stats['by_level'],
            'resolved_count': incident_stats['resolved_count'],
            'top_threat_senders': incident_stats['top_senders'],
            'generated_at': datetime.datetime.now().isoformat()
        }


# ==================== 使用示例 ====================

if __name__ == '__main__':
    # 创建安全防御系统
    security_system = EmailSecurityDefenseSystem()
    
    # 示例邮件数据
    test_email = {
        'id': 'msg_001',
        'from': 'attacker@malicious.xyz',
        'from_name': 'PayPal Security',
        'to': 'victim@company.com',
        'subject': '紧急：您的账户已被冻结',
        'body': '''
        尊敬的用户：
        
        您的PayPal账户存在异常活动，已被暂时冻结。
        请立即点击以下链接验证您的身份：
        http://192.168.1.100/paypal/verify
        
        如在24小时内未验证，账户将被永久关闭。
        
        PayPal安全团队
        ''',
        'attachments': [
            {'filename': 'invoice.exe', 'size': 5242880}
        ],
        'headers': {
            'Received-SPF': 'fail (domain of malicious.xyz does not designate 192.168.1.100 as permitted sender)'
        }
    }
    
    # 扫描邮件
    result = security_system.scan_email(test_email, user_id='user_123')
    
    # 打印结果
    print("=" * 60)
    print("邮件安全扫描结果")
    print("=" * 60)
    print(f"安全状态: {'安全' if result['scan_result']['is_safe'] else '存在威胁'}")
    print(f"威胁等级: {result['scan_result']['threat_level']}")
    print(f"风险评分: {result['scan_result']['risk_score']}/100")
    print(f"\n检测到的威胁 ({len(result['scan_result']['threats'])}个):")
    
    for i, threat in enumerate(result['scan_result']['threats'], 1):
        print(f"\n  [{i}] {threat['type'].upper()}")
        print(f"      等级: {threat['level']}")
        print(f"      置信度: {threat['confidence']*100:.1f}%")
        print(f"      描述: {threat['description']}")
        print(f"      建议: {threat['remediation']}")
    
    print(f"\n响应动作:")
    for action in result['response']['actions_taken']:
        print(f"  - {action['action']}: {action['result']}")
    
    print(f"\n建议:")
    for rec in result['scan_result']['recommendations']:
        print(f"  • {rec}")
    
    print("\n" + "=" * 60)
