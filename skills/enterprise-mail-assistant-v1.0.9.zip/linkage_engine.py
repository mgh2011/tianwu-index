#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级智能邮件助手 - 联动引擎模块
Enterprise Intelligent Mail Assistant - Linkage Engine Module

功能说明：
提供安全联动、数据联动、事件联动和决策联动四大核心联动器，
实现与企业级综合安全引擎、综合兼容联动引擎和邮件安全守门员的无缝集成。

符合法规：网络安全法、数据隐私保护法、个人信息保护法
本地运行：无外部网络请求，所有操作均在本地执行
"""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import queue
import hashlib


# 配置日志
logger = logging.getLogger(__name__)


class LinkageStatus(Enum):
    """联动状态枚举"""
    IDLE = "idle"                    # 空闲
    CONNECTING = "connecting"        # 连接中
    CONNECTED = "connected"          # 已连接
    ACTIVE = "active"                # 活跃
    SUSPENDED = "suspended"          # 暂停
    ERROR = "error"                  # 错误
    DISCONNECTED = "disconnected"    # 断开连接


class EventPriority(Enum):
    """事件优先级枚举"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4
    EMERGENCY = 5


class DataFormat(Enum):
    """数据格式枚举"""
    JSON = "json"
    XML = "xml"
    YAML = "yaml"
    BINARY = "binary"


@dataclass
class LinkageConfig:
    """联动配置数据结构"""
    enabled: bool = True
    auto_reconnect: bool = True
    max_retry_attempts: int = 3
    retry_interval_seconds: int = 5
    timeout_seconds: int = 30
    batch_size: int = 100
    compression_enabled: bool = True
    encryption_enabled: bool = True


@dataclass
class SecurityEvent:
    """安全事件数据结构"""
    event_id: str
    event_type: str
    severity: EventPriority
    source_system: str
    target_system: Optional[str]
    timestamp: str
    description: str
    raw_data: Dict[str, Any] = field(default_factory=dict)
    processed: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataPackage:
    """数据包结构"""
    package_id: str
    source: str
    destination: str
    data_type: str
    format: DataFormat
    content: Union[Dict, str, bytes]
    timestamp: str
    checksum: str = ""
    encrypted: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.checksum and self.content:
            self.checksum = self._calculate_checksum()
    
    def _calculate_checksum(self) -> str:
        """计算校验和"""
        if isinstance(self.content, dict):
            content_str = json.dumps(self.content, sort_keys=True)
        elif isinstance(self.content, bytes):
            content_str = self.content.decode('utf-8', errors='ignore')
        else:
            content_str = str(self.content)
        
        return hashlib.sha256(content_str.encode()).hexdigest()[:16]
    
    def verify(self) -> bool:
        """验证数据包完整性"""
        return self.checksum == self._calculate_checksum()


@dataclass
class DecisionRequest:
    """决策请求数据结构"""
    request_id: str
    decision_type: str
    context: Dict[str, Any]
    available_actions: List[str]
    priority: EventPriority = EventPriority.NORMAL
    timeout_seconds: int = 30
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DecisionResponse:
    """决策响应数据结构"""
    request_id: str
    decision: str
    action_taken: str
    confidence: float  # 0.0 - 1.0
    reasoning: str
    execution_time_ms: float
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class EventSubscription:
    """事件订阅数据结构"""
    subscription_id: str
    event_types: Set[str]
    callback: Callable[[SecurityEvent], None]
    filter_criteria: Optional[Dict[str, Any]] = None
    priority: EventPriority = EventPriority.NORMAL
    active: bool = True


class EventBus:
    """事件总线 - 发布订阅模式实现"""
    
    def __init__(self):
        self._subscribers: Dict[str, List[EventSubscription]] = defaultdict(list)
        self._lock = threading.RLock()
        self._event_queue: queue.PriorityQueue = queue.PriorityQueue()
        self._running = False
        self._processor_thread: Optional[threading.Thread] = None
    
    def subscribe(
        self,
        event_types: List[str],
        callback: Callable[[SecurityEvent], None],
        filter_criteria: Optional[Dict[str, Any]] = None,
        priority: EventPriority = EventPriority.NORMAL
    ) -> str:
        """订阅事件"""
        with self._lock:
            subscription_id = str(uuid.uuid4())
            
            subscription = EventSubscription(
                subscription_id=subscription_id,
                event_types=set(event_types),
                callback=callback,
                filter_criteria=filter_criteria,
                priority=priority
            )
            
            for event_type in event_types:
                self._subscribers[event_type].append(subscription)
            
            logger.info(f"已订阅事件类型: {event_types}, 订阅ID: {subscription_id}")
            return subscription_id
    
    def unsubscribe(self, subscription_id: str) -> bool:
        """取消订阅"""
        with self._lock:
            for event_type, subscriptions in self._subscribers.items():
                self._subscribers[event_type] = [
                    sub for sub in subscriptions
                    if sub.subscription_id != subscription_id
                ]
            logger.info(f"已取消订阅: {subscription_id}")
            return True
    
    def publish(self, event: SecurityEvent) -> int:
        """发布事件"""
        with self._lock:
            subscriber_count = 0
            
            for subscription in self._subscribers.get(event.event_type, []):
                if not subscription.active:
                    continue
                
                if self._matches_filter(event, subscription.filter_criteria):
                    try:
                        # 根据优先级调整处理顺序
                        self._event_queue.put((
                            -subscription.priority.value,
                            time.time(),
                            subscription.callback,
                            event
                        ))
                        subscriber_count += 1
                    except Exception as e:
                        logger.error(f"事件发布失败: {e}")
            
            return subscriber_count
    
    def _matches_filter(
        self,
        event: SecurityEvent,
        filter_criteria: Optional[Dict[str, Any]]
    ) -> bool:
        """检查事件是否匹配过滤条件"""
        if not filter_criteria:
            return True
        
        for key, value in filter_criteria.items():
            event_value = event.metadata.get(key) or event.raw_data.get(key)
            if event_value != value:
                return False
        
        return True
    
    def start_processing(self):
        """启动事件处理"""
        if self._running:
            return
        
        self._running = True
        self._processor_thread = threading.Thread(target=self._process_events)
        self._processor_thread.daemon = True
        self._processor_thread.start()
        logger.info("事件总线处理已启动")
    
    def stop_processing(self):
        """停止事件处理"""
        self._running = False
        if self._processor_thread:
            self._processor_thread.join(timeout=5)
        logger.info("事件总线处理已停止")
    
    def _process_events(self):
        """事件处理循环"""
        while self._running:
            try:
                priority, timestamp, callback, event = self._event_queue.get(timeout=1)
                callback(event)
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"事件处理错误: {e}")


class SecurityLinkageHandler:
    """安全联动处理器"""
    
    def __init__(self, config: LinkageConfig):
        self.config = config
        self._status = LinkageStatus.IDLE
        self._linked_systems: Dict[str, Dict[str, Any]] = {}
        self._security_rules: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._event_bus = EventBus()
        
        # 初始化默认安全规则
        self._initialize_default_rules()
    
    def _initialize_default_rules(self):
        """初始化默认安全规则"""
        self._security_rules = {
            "phishing_detected": {
                "action": "quarantine",
                "notify": ["security_team", "admin"],
                "severity": EventPriority.HIGH
            },
            "malware_detected": {
                "action": "block_and_notify",
                "notify": ["security_team", "admin", "executive"],
                "severity": EventPriority.CRITICAL
            },
            "spam_detected": {
                "action": "filter",
                "notify": ["user"],
                "severity": EventPriority.LOW
            },
            "suspicious_activity": {
                "action": "alert",
                "notify": ["security_team"],
                "severity": EventPriority.HIGH
            },
            "data_leak_suspected": {
                "action": "block_and_archive",
                "notify": ["security_team", "dpo"],
                "severity": EventPriority.EMERGENCY
            }
        }
    
    @property
    def status(self) -> LinkageStatus:
        """获取联动状态"""
        return self._status
    
    def connect(self, system_id: str, system_info: Dict[str, Any]) -> bool:
        """连接安全系统"""
        with self._lock:
            if self._status == LinkageStatus.CONNECTED:
                logger.warning("已经处于连接状态")
                return True
            
            try:
                self._linked_systems[system_id] = {
                    **system_info,
                    "connected_at": datetime.now(timezone.utc).isoformat()
                }
                self._status = LinkageStatus.CONNECTED
                logger.info(f"已连接到安全系统: {system_id}")
                return True
            except Exception as e:
                self._status = LinkageStatus.ERROR
                logger.error(f"连接安全系统失败: {e}")
                return False
    
    def disconnect(self, system_id: str) -> bool:
        """断开安全系统连接"""
        with self._lock:
            if system_id in self._linked_systems:
                del self._linked_systems[system_id]
                logger.info(f"已断开安全系统: {system_id}")
            
            if not self._linked_systems:
                self._status = LinkageStatus.DISCONNECTED
            
            return True
    
    def register_security_rule(
        self,
        rule_name: str,
        action: str,
        notify: List[str],
        severity: EventPriority
    ):
        """注册安全规则"""
        with self._lock:
            self._security_rules[rule_name] = {
                "action": action,
                "notify": notify,
                "severity": severity
            }
            logger.info(f"已注册安全规则: {rule_name}")
    
    def handle_security_event(self, event: SecurityEvent) -> Dict[str, Any]:
        """处理安全事件"""
        with self._lock:
            # 查找匹配的规则
            rule = self._security_rules.get(event.event_type, {})
            
            result = {
                "event_id": event.event_id,
                "processed": True,
                "action_taken": rule.get("action", "unknown"),
                "notifications_sent": rule.get("notify", []),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            
            # 发布事件到事件总线
            subscriber_count = self._event_bus.publish(event)
            result["subscriber_count"] = subscriber_count
            
            logger.info(f"处理安全事件: {event.event_type}, 动作: {result['action_taken']}")
            
            return result
    
    def sync_security_policy(self, policy_data: Dict[str, Any]) -> bool:
        """同步安全策略"""
        with self._lock:
            try:
                # 更新本地规则
                for rule_name, rule_config in policy_data.get("rules", {}).items():
                    self._security_rules[rule_name] = rule_config
                
                logger.info(f"已同步安全策略，共 {len(policy_data.get('rules', {}))} 条规则")
                return True
            except Exception as e:
                logger.error(f"同步安全策略失败: {e}")
                return False
    
    def get_security_status(self) -> Dict[str, Any]:
        """获取安全状态"""
        with self._lock:
            return {
                "status": self._status.value,
                "linked_systems_count": len(self._linked_systems),
                "linked_systems": list(self._linked_systems.keys()),
                "active_rules_count": len(self._security_rules),
                "event_bus_active": self._event_bus._running if hasattr(self._event_bus, '_running') else False
            }


class DataLinkageHandler:
    """数据联动处理器"""
    
    def __init__(self, config: LinkageConfig):
        self.config = config
        self._data_mappings: Dict[str, Dict[str, str]] = {}
        self._transformation_rules: Dict[str, Callable] = {}
        self._data_buffers: Dict[str, List[DataPackage]] = defaultdict(list)
        self._lock = threading.RLock()
        
        # 初始化默认数据映射
        self._initialize_default_mappings()
    
    def _initialize_default_mappings(self):
        """初始化默认数据映射"""
        self._data_mappings = {
            "mail_to_security": {
                "sender": "source_address",
                "recipient": "target_address",
                "subject": "mail_subject",
                "timestamp": "event_time",
                "attachments": "file_list"
            },
            "security_to_mail": {
                "threat_level": "priority",
                "threat_type": "category",
                "affected_ips": "involved_addresses"
            }
        }
    
    def register_data_mapping(
        self,
        mapping_name: str,
        field_mappings: Dict[str, str]
    ):
        """注册数据映射"""
        with self._lock:
            self._data_mappings[mapping_name] = field_mappings
            logger.info(f"已注册数据映射: {mapping_name}")
    
    def transform_data(
        self,
        source_data: Dict[str, Any],
        mapping_name: str
    ) -> Optional[Dict[str, Any]]:
        """转换数据格式"""
        with self._lock:
            mapping = self._data_mappings.get(mapping_name)
            if not mapping:
                logger.warning(f"未找到数据映射: {mapping_name}")
                return None
            
            transformed = {}
            for source_field, target_field in mapping.items():
                if source_field in source_data:
                    transformed[target_field] = source_data[source_field]
            
            return transformed
    
    def buffer_data(self, data: DataPackage):
        """缓冲数据"""
        with self._lock:
            buffer_key = f"{data.source}:{data.destination}"
            self._data_buffers[buffer_key].append(data)
            
            # 如果缓冲区超过限制，执行批量处理
            if len(self._data_buffers[buffer_key]) >= self.config.batch_size:
                self._flush_buffer(buffer_key)
    
    def _flush_buffer(self, buffer_key: str):
        """刷新缓冲区"""
        if self._data_buffers[buffer_key]:
            logger.info(f"刷新数据缓冲区: {buffer_key}, 数量: {len(self._data_buffers[buffer_key])}")
            # 在实际实现中，这里会触发批量数据传输
            self._data_buffers[buffer_key] = []
    
    def transfer_data(
        self,
        source: str,
        destination: str,
        data: Union[Dict, str, bytes],
        data_type: str = "generic"
    ) -> Optional[DataPackage]:
        """传输数据"""
        with self._lock:
            package = DataPackage(
                package_id=str(uuid.uuid4()),
                source=source,
                destination=destination,
                data_type=data_type,
                format=DataFormat.JSON if isinstance(data, dict) else DataFormat.BINARY,
                content=data,
                timestamp=datetime.now(timezone.utc).isoformat(),
                encrypted=self.config.encryption_enabled
            )
            
            # 验证数据包
            if not package.verify():
                logger.error(f"数据包校验失败: {package.package_id}")
                return None
            
            logger.info(f"数据传输: {source} -> {destination}, 包ID: {package.package_id}")
            return package
    
    def get_buffer_status(self) -> Dict[str, int]:
        """获取缓冲区状态"""
        with self._lock:
            return {
                key: len(buffers)
                for key, buffers in self._data_buffers.items()
            }


class EventLinkageHandler:
    """事件联动处理器"""
    
    def __init__(self, config: LinkageConfig):
        self.config = config
        self._event_correlators: Dict[str, Callable] = {}
        self._event_history: List[SecurityEvent] = []
        self._event_patterns: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        
        # 初始化默认事件关联器
        self._initialize_default_correlators()
    
    def _initialize_default_correlators(self):
        """初始化默认事件关联器"""
        self._event_patterns = {
            "multi_source_attack": {
                "min_events": 3,
                "time_window_seconds": 60,
                "severity_escalation": True
            },
            "brute_force": {
                "min_events": 5,
                "time_window_seconds": 300,
                "severity_escalation": True
            }
        }
    
    def subscribe_to_event(
        self,
        event_type: str,
        callback: Callable[[SecurityEvent], None]
    ) -> str:
        """订阅事件"""
        with self._lock:
            event_bus = EventBus()
            return event_bus.subscribe([event_type], callback)
    
    def correlate_events(
        self,
        events: List[SecurityEvent],
        pattern_name: str
    ) -> Optional[Dict[str, Any]]:
        """关联事件"""
        with self._lock:
            pattern = self._event_patterns.get(pattern_name)
            if not pattern:
                return None
            
            # 按时间排序
            sorted_events = sorted(events, key=lambda e: e.timestamp)
            
            # 检查是否符合模式
            if len(events) >= pattern["min_events"]:
                return {
                    "pattern_matched": True,
                    "pattern_name": pattern_name,
                    "events_count": len(events),
                    "time_span_seconds": (
                        datetime.fromisoformat(sorted_events[-1].timestamp) -
                        datetime.fromisoformat(sorted_events[0].timestamp)
                    ).total_seconds(),
                    "severity_escalation": pattern["severity_escalation"],
                    "correlated_events": [e.event_id for e in events]
                }
            
            return {"pattern_matched": False}
    
    def record_event(self, event: SecurityEvent):
        """记录事件"""
        with self._lock:
            self._event_history.append(event)
            
            # 限制历史记录大小
            if len(self._event_history) > 10000:
                self._event_history = self._event_history[-5000:]
    
    def get_event_history(
        self,
        event_type: Optional[str] = None,
        limit: int = 100
    ) -> List[SecurityEvent]:
        """获取事件历史"""
        with self._lock:
            if event_type:
                filtered = [e for e in self._event_history if e.event_type == event_type]
                return filtered[-limit:]
            return self._event_history[-limit:]


class DecisionLinkageHandler:
    """决策联动处理器"""
    
    def __init__(self, config: LinkageConfig):
        self.config = config
        self._decision_rules: Dict[str, Dict[str, Any]] = {}
        self._decision_history: List[DecisionResponse] = []
        self._ai_models: Dict[str, Any] = {}
        self._lock = threading.RLock()
        
        # 初始化默认决策规则
        self._initialize_default_rules()
    
    def _initialize_default_rules(self):
        """初始化默认决策规则"""
        self._decision_rules = {
            "auto_approve_safe": {
                "condition": {"threat_score": {"max": 0.2}},
                "action": "approve",
                "confidence_threshold": 0.9
            },
            "auto_reject_malicious": {
                "condition": {"threat_score": {"min": 0.8}, "threat_type": "malware"},
                "action": "reject",
                "confidence_threshold": 0.95
            },
            "manual_review": {
                "condition": {"threat_score": {"min": 0.3, "max": 0.7}},
                "action": "manual_review",
                "confidence_threshold": 0.5
            }
        }
    
    def register_decision_rule(
        self,
        rule_name: str,
        condition: Dict[str, Any],
        action: str,
        confidence_threshold: float = 0.8
    ):
        """注册决策规则"""
        with self._lock:
            self._decision_rules[rule_name] = {
                "condition": condition,
                "action": action,
                "confidence_threshold": confidence_threshold
            }
            logger.info(f"已注册决策规则: {rule_name}")
    
    def make_decision(self, request: DecisionRequest) -> DecisionResponse:
        """做出决策"""
        start_time = time.time()
        
        with self._lock:
            # 查找匹配的规则
            matched_rule = None
            for rule_name, rule in self._decision_rules.items():
                if self._evaluate_condition(request.context, rule["condition"]):
                    matched_rule = rule
                    matched_rule["rule_name"] = rule_name
                    break
            
            # 生成决策
            if matched_rule:
                decision = matched_rule["action"]
                reasoning = f"匹配规则: {matched_rule.get('rule_name', 'unknown')}"
                confidence = matched_rule["confidence_threshold"]
            else:
                decision = "unknown"
                reasoning = "未匹配任何规则，需要人工决策"
                confidence = 0.0
            
            execution_time = (time.time() - start_time) * 1000
            
            response = DecisionResponse(
                request_id=request.request_id,
                decision=decision,
                action_taken=decision,
                confidence=confidence,
                reasoning=reasoning,
                execution_time_ms=execution_time
            )
            
            # 记录决策
            self._decision_history.append(response)
            
            logger.info(f"决策完成: {request.request_id}, 决策: {decision}, 置信度: {confidence:.2f}")
            
            return response
    
    def _evaluate_condition(
        self,
        context: Dict[str, Any],
        condition: Dict[str, Any]
    ) -> bool:
        """评估条件"""
        for key, expected in condition.items():
            actual = context.get(key)
            
            if isinstance(expected, dict):
                # 处理范围条件
                if "min" in expected and actual < expected["min"]:
                    return False
                if "max" in expected and actual > expected["max"]:
                    return False
                if "eq" in expected and actual != expected["eq"]:
                    return False
            elif actual != expected:
                return False
        
        return True
    
    def get_decision_history(
        self,
        decision_type: Optional[str] = None,
        limit: int = 100
    ) -> List[DecisionResponse]:
        """获取决策历史"""
        with self._lock:
            if decision_type:
                filtered = [
                    d for d in self._decision_history
                    if d.decision == decision_type
                ]
                return filtered[-limit:]
            return self._decision_history[-limit:]


class LinkageEngine:
    """
    联动引擎主类
    整合安全、数据、事件和决策四大联动器
    """
    
    def __init__(self, config: Optional[LinkageConfig] = None):
        self.config = config or LinkageConfig()
        
        # 初始化各联动器
        self.security_handler = SecurityLinkageHandler(self.config)
        self.data_handler = DataLinkageHandler(self.config)
        self.event_handler = EventLinkageHandler(self.config)
        self.decision_handler = DecisionLinkageHandler(self.config)
        
        self._lock = threading.RLock()
        self._running = False
        self._start_time: Optional[datetime] = None
    
    def start(self):
        """启动联动引擎"""
        with self._lock:
            if self._running:
                logger.warning("联动引擎已在运行中")
                return
            
            self._running = True
            self._start_time = datetime.now(timezone.utc)
            logger.info("联动引擎已启动")
    
    def stop(self):
        """停止联动引擎"""
        with self._lock:
            self._running = False
            logger.info("联动引擎已停止")
    
    @property
    def is_running(self) -> bool:
        """检查是否运行中"""
        return self._running
    
    def get_status(self) -> Dict[str, Any]:
        """获取引擎状态"""
        with self._lock:
            return {
                "running": self._running,
                "uptime_seconds": (
                    (datetime.now(timezone.utc) - self._start_time).total_seconds()
                    if self._start_time else 0
                ),
                "security": self.security_handler.get_security_status(),
                "data_buffers": self.data_handler.get_buffer_status(),
                "event_history_count": len(self.event_handler.get_event_history()),
                "decision_history_count": len(self.decision_handler.get_decision_history())
            }
    
    def process_security_event(
        self,
        event_type: str,
        severity: EventPriority,
        source: str,
        description: str,
        raw_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """处理安全事件"""
        event = SecurityEvent(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            severity=severity,
            source_system=source,
            target_system=None,
            timestamp=datetime.now(timezone.utc).isoformat(),
            description=description,
            raw_data=raw_data or {}
        )
        
        # 记录事件
        self.event_handler.record_event(event)
        
        # 处理安全事件
        result = self.security_handler.handle_security_event(event)
        
        # 如果需要决策
        if severity.value >= EventPriority.HIGH.value:
            decision_request = DecisionRequest(
                request_id=str(uuid.uuid4()),
                decision_type="security_event",
                context={
                    "event_type": event_type,
                    "severity": severity.value,
                    "threat_score": 0.8 if severity == EventPriority.CRITICAL else 0.5
                },
                available_actions=["approve", "block", "quarantine", "alert"],
                priority=severity
            )
            
            decision = self.decision_handler.make_decision(decision_request)
            result["decision"] = asdict(decision)
        
        return result
    
    def transfer_data_between_systems(
        self,
        source: str,
        destination: str,
        data: Dict[str, Any],
        data_type: str = "generic"
    ) -> Optional[str]:
        """在系统间传输数据"""
        # 转换数据格式
        mapping_name = f"{source}_to_{destination}"
        transformed = self.data_handler.transform_data(data, mapping_name)
        
        if not transformed:
            transformed = data
        
        # 传输数据
        package = self.data_handler.transfer_data(
            source=source,
            destination=destination,
            data=transformed,
            data_type=data_type
        )
        
        return package.package_id if package else None
    
    def register_linkage_callback(
        self,
        event_type: str,
        callback: Callable[[SecurityEvent], None]
    ):
        """注册联动回调"""
        self.event_handler.subscribe_to_event(event_type, callback)
    
    def sync_policy(self, policy_data: Dict[str, Any]) -> bool:
        """同步策略"""
        # 同步安全策略
        if "security_rules" in policy_data:
            for rule_name, rule_config in policy_data["security_rules"].items():
                self.security_handler.register_security_rule(
                    rule_name,
                    rule_config.get("action", "unknown"),
                    rule_config.get("notify", []),
                    EventPriority(rule_config.get("severity", 2))
                )
        
        # 同步决策规则
        if "decision_rules" in policy_data:
            for rule_name, rule_config in policy_data["decision_rules"].items():
                self.decision_handler.register_decision_rule(
                    rule_name,
                    rule_config.get("condition", {}),
                    rule_config.get("action", "unknown"),
                    rule_config.get("confidence_threshold", 0.8)
                )
        
        logger.info("策略同步完成")
        return True
    
    def generate_linkage_report(self) -> Dict[str, Any]:
        """生成联动报告"""
        with self._lock:
            return {
                "report_type": "linkage_engine_report",
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "engine_status": self.get_status(),
                "security_rules_count": len(self.security_handler._security_rules),
                "data_mappings_count": len(self.data_handler._data_mappings),
                "event_patterns_count": len(self.event_handler._event_patterns),
                "decision_rules_count": len(self.decision_handler._decision_rules),
                "total_events_processed": len(self.event_handler.get_event_history()),
                "total_decisions_made": len(self.decision_handler.get_decision_history())
            }


# 辅助函数：asdict for dataclass
def asdict(obj):
    """将 dataclass 对象转换为字典"""
    if hasattr(obj, '__dataclass_fields__'):
        return {
            k: asdict(v) if hasattr(v, '__dataclass_fields__') else v
            for k, v in obj.__dict__.items()
            if not k.startswith('_')
        }
    return obj


# 全局联动引擎实例
_linkage_engine_instance: Optional[LinkageEngine] = None


def get_linkage_engine(config: Optional[LinkageConfig] = None) -> LinkageEngine:
    """获取全局联动引擎实例"""
    global _linkage_engine_instance
    if _linkage_engine_instance is None:
        _linkage_engine_instance = LinkageEngine(config)
    return _linkage_engine_instance


# 合规声明
__compliance_info__ = {
    "module": "linkage_engine",
    "version": "3.0.0",
    "data_processing": "本地处理，无外部网络请求",
    "security_compliance": [
        "网络安全法第二十一条：采取数据分类、重要数据备份和加密等措施",
        "数据安全法第二十七条：开展数据处理活动应当依照法律、法规的规定",
        "个人信息保护法第五十一条：采取加密、去标识化等安全技术措施"
    ],
    "audit_info": {
        "log_retention_days": 180,
        "audit_level": "full",
        "encryption_required": True,
        "pii_protection": True
    }
}


if __name__ == "__main__":
    # 示例用法
    engine = get_linkage_engine()
    engine.start()
    
    # 处理安全事件
    result = engine.process_security_event(
        event_type="phishing_detected",
        severity=EventPriority.HIGH,
        source="mail_gateway",
        description="检测到钓鱼邮件",
        raw_data={"sender": "phisher@example.com", "subject": "假邮件"}
    )
    
    print(f"事件处理结果: {result}")
    print(f"执行决策: {result.get('decision', {})}")
    
    # 传输数据
    package_id = engine.transfer_data_between_systems(
        source="mail_assistant",
        destination="security_engine",
        data={"user_id": "12345", "action": "login"},
        data_type="user_action"
    )
    
    print(f"数据包ID: {package_id}")
    
    # 获取状态
    status = engine.get_status()
    print(f"引擎状态: {status}")
    
    engine.stop()
