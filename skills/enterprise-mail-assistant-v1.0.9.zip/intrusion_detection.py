#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级入侵检测系统 (IDS) v5.1.0
包含：入侵检测引擎、告警管理、威胁分析
"""

import json
import hashlib
import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import re


class AlertSeverity(Enum):
    """告警严重程度"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class AlertStatus(Enum):
    """告警状态"""
    NEW = "new"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    FALSE_POSITIVE = "false_positive"
    IGNORED = "ignored"


class AttackType(Enum):
    """攻击类型"""
    BRUTE_FORCE = "brute_force"
    SQL_INJECTION = "sql_injection"
    XSS = "xss"
    PATH_TRAVERSAL = "path_traversal"
    COMMAND_INJECTION = "command_injection"
    DDoS = "ddos"
    PORT_SCAN = "port_scan"
    MALWARE = "malware"
    PHISHING = "phishing"
    DATA_EXFILTRATION = "data_exfiltration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    LATERAL_MOVEMENT = "lateral_movement"


@dataclass
class IDSAlert:
    """IDS告警"""
    alert_id: str
    timestamp: str
    severity: AlertSeverity
    attack_type: AttackType
    source_ip: str
    destination_ip: str
    source_port: int
    destination_port: int
    protocol: str
    description: str
    rule_id: str
    status: AlertStatus = AlertStatus.NEW
    assigned_to: Optional[str] = None
    notes: List[str] = field(default_factory=list)
    raw_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DetectionRule:
    """检测规则"""
    rule_id: str
    name: str
    category: AttackType
    severity: AlertSeverity
    pattern: str  # 正则表达式或特征
    description: str
    false_positive_rate: float
    enabled: bool = True


@dataclass
class TrafficStats:
    """流量统计"""
    timestamp: str
    total_packets: int
    total_bytes: int
    connections: int
    unique_sources: int
    unique_destinations: int
    top_sources: List[Tuple[str, int]]
    top_destinations: List[Tuple[str, int]]
    protocol_distribution: Dict[str, int]


class IntrusionDetectionEngine:
    """入侵检测引擎"""
    
    def __init__(self):
        self.detection_rules: Dict[str, DetectionRule] = {}
        self.alerts: List[IDSAlert] = []
        self.traffic_history: List[TrafficStats] = []
        self.baseline: Dict[str, Any] = {}
        
        # 统计
        self.stats = {
            'total_packets_analyzed': 0,
            'total_alerts': 0,
            'by_severity': defaultdict(int),
            'by_attack_type': defaultdict(int)
        }
        
        # 初始化检测规则
        self._init_detection_rules()
        
        # 初始化基线
        self._init_baseline()
    
    def _init_detection_rules(self):
        """初始化检测规则"""
        rules = [
            # SQL注入检测
            DetectionRule(
                rule_id="IDS-001",
                name="SQL注入攻击检测",
                category=AttackType.SQL_INJECTION,
                severity=AlertSeverity.HIGH,
                pattern=r"(?i)(union\s+select|select\s+.*\s+from|insert\s+into|delete\s+from|drop\s+table|exec\s*\(|xp_cmdshell)",
                description="检测到SQL注入攻击特征",
                false_positive_rate=0.05
            ),
            
            # XSS攻击检测
            DetectionRule(
                rule_id="IDS-002",
                name="XSS攻击检测",
                category=AttackType.XSS,
                severity=AlertSeverity.HIGH,
                pattern=r"(?i)(<script|javascript:|onerror\s*=|onload\s*=|<img\s+.*src\s*=|<iframe)",
                description="检测到XSS攻击特征",
                false_positive_rate=0.08
            ),
            
            # 路径遍历检测
            DetectionRule(
                rule_id="IDS-003",
                name="路径遍历攻击检测",
                category=AttackType.PATH_TRAVERSAL,
                severity=AlertSeverity.MEDIUM,
                pattern=r"(\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e\/)",
                description="检测到路径遍历攻击特征",
                false_positive_rate=0.03
            ),
            
            # 命令注入检测
            DetectionRule(
                rule_id="IDS-004",
                name="命令注入攻击检测",
                category=AttackType.COMMAND_INJECTION,
                severity=AlertSeverity.CRITICAL,
                pattern=r"(;|\||`|\$\(|\$\{)\s*(ls|cat|rm|wget|curl|bash|sh|cmd|powershell)",
                description="检测到命令注入攻击特征",
                false_positive_rate=0.02
            ),
            
            # 暴力破解检测
            DetectionRule(
                rule_id="IDS-005",
                name="SSH暴力破解检测",
                category=AttackType.BRUTE_FORCE,
                severity=AlertSeverity.HIGH,
                pattern=r"ssh.*failed|authentication failure",
                description="检测到SSH暴力破解尝试",
                false_positive_rate=0.01
            ),
            
            # 端口扫描检测
            DetectionRule(
                rule_id="IDS-006",
                name="端口扫描检测",
                category=AttackType.PORT_SCAN,
                severity=AlertSeverity.MEDIUM,
                pattern=r"",  # 通过行为分析检测
                description="检测到端口扫描行为",
                false_positive_rate=0.1
            ),
            
            # 数据外泄检测
            DetectionRule(
                rule_id="IDS-007",
                name="可疑数据传输检测",
                category=AttackType.DATA_EXFILTRATION,
                severity=AlertSeverity.HIGH,
                pattern=r"",  # 通过行为分析检测
                description="检测到可疑的大数据量外传",
                false_positive_rate=0.05
            ),
            
            # 权限提升检测
            DetectionRule(
                rule_id="IDS-008",
                name="权限提升尝试检测",
                category=AttackType.PRIVILEGE_ESCALATION,
                severity=AlertSeverity.CRITICAL,
                pattern=r"(sudo|su\s+root|chmod\s+[0-7]777|chown\s+root)",
                description="检测到权限提升尝试",
                false_positive_rate=0.03
            )
        ]
        
        for rule in rules:
            self.detection_rules[rule.rule_id] = rule
    
    def _init_baseline(self):
        """初始化基线"""
        self.baseline = {
            'avg_packets_per_minute': 1000,
            'avg_connections_per_minute': 100,
            'avg_bytes_per_minute': 1024 * 1024,  # 1MB
            'max_packets_per_source': 100,
            'normal_ports': [80, 443, 22, 25, 53, 110, 143, 993, 995],
            'allowed_countries': ['CN', 'US', 'JP', 'EU']
        }
    
    def analyze_traffic(self, traffic_data: Dict) -> List[IDSAlert]:
        """
        分析流量数据
        
        Args:
            traffic_data: 流量数据，包含:
                - packets: 数据包列表
                - connections: 连接列表
                - payload: 载荷内容（可选）
        
        Returns:
            告警列表
        """
        alerts = []
        
        packets = traffic_data.get('packets', [])
        connections = traffic_data.get('connections', [])
        payload = traffic_data.get('payload', '')
        
        self.stats['total_packets_analyzed'] += len(packets)
        
        # 1. 基于规则的检测
        if payload:
            alerts.extend(self._rule_based_detection(payload, traffic_data))
        
        # 2. 基于行为的检测
        alerts.extend(self._behavior_based_detection(packets, connections))
        
        # 3. 异常检测
        alerts.extend(self._anomaly_detection(packets, connections))
        
        # 更新统计
        for alert in alerts:
            self.stats['total_alerts'] += 1
            self.stats['by_severity'][alert.severity.value] += 1
            self.stats['by_attack_type'][alert.attack_type.value] += 1
        
        self.alerts.extend(alerts)
        
        return alerts
    
    def _rule_based_detection(self, payload: str, traffic_data: Dict) -> List[IDSAlert]:
        """基于规则的检测"""
        alerts = []
        
        for rule_id, rule in self.detection_rules.items():
            if not rule.enabled or not rule.pattern:
                continue
            
            if re.search(rule.pattern, payload, re.IGNORECASE):
                alert = self._create_alert(
                    rule=rule,
                    traffic_data=traffic_data,
                    description=f"{rule.description}: 匹配规则 {rule_id}"
                )
                alerts.append(alert)
        
        return alerts
    
    def _behavior_based_detection(self, packets: List, connections: List) -> List[IDSAlert]:
        """基于行为的检测"""
        alerts = []
        
        # 统计每个源的连接数
        source_connections = defaultdict(int)
        source_ports = defaultdict(set)
        
        for conn in connections:
            src_ip = conn.get('source_ip', '')
            dst_port = conn.get('destination_port', 0)
            
            source_connections[src_ip] += 1
            source_ports[src_ip].add(dst_port)
        
        # 检测端口扫描
        port_scan_rule = self.detection_rules.get('IDS-006')
        if port_scan_rule:
            for src_ip, ports in source_ports.items():
                if len(ports) > 10:  # 短时间内连接超过10个不同端口
                    alerts.append(self._create_alert(
                        rule=port_scan_rule,
                        traffic_data={'source_ip': src_ip},
                        description=f"端口扫描行为: {src_ip} 扫描了 {len(ports)} 个端口"
                    ))
        
        # 检测暴力破解
        brute_force_rule = self.detection_rules.get('IDS-005')
        if brute_force_rule:
            for src_ip, count in source_connections.items():
                if count > self.baseline['max_packets_per_source'] * 5:
                    alerts.append(self._create_alert(
                        rule=brute_force_rule,
                        traffic_data={'source_ip': src_ip},
                        description=f"暴力破解尝试: {src_ip} 发起 {count} 次连接"
                    ))
        
        return alerts
    
    def _anomaly_detection(self, packets: List, connections: List) -> List[IDSAlert]:
        """异常检测"""
        alerts = []
        
        # 计算当前统计
        current_stats = {
            'packet_count': len(packets),
            'connection_count': len(connections),
            'unique_sources': len(set(p.get('source_ip', '') for p in packets))
        }
        
        # 与基线比较
        if current_stats['packet_count'] > self.baseline['avg_packets_per_minute'] * 5:
            # 可能是DDoS攻击
            ddos_rule = DetectionRule(
                rule_id="ANOMALY-001",
                name="DDoS攻击检测",
                category=AttackType.DDoS,
                severity=AlertSeverity.CRITICAL,
                pattern="",
                description="检测到异常高流量，可能是DDoS攻击",
                false_positive_rate=0.05
            )
            alerts.append(self._create_alert(
                rule=ddos_rule,
                traffic_data={'packet_count': current_stats['packet_count']},
                description=f"异常流量: {current_stats['packet_count']} 包/分钟 (基线: {self.baseline['avg_packets_per_minute']})"
            ))
        
        return alerts
    
    def _create_alert(self, rule: DetectionRule, traffic_data: Dict, description: str) -> IDSAlert:
        """创建告警"""
        return IDSAlert(
            alert_id=hashlib.md5(f"{rule.rule_id}{datetime.datetime.now().isoformat()}".encode()).hexdigest()[:12],
            timestamp=datetime.datetime.now().isoformat(),
            severity=rule.severity,
            attack_type=rule.category,
            source_ip=traffic_data.get('source_ip', 'unknown'),
            destination_ip=traffic_data.get('destination_ip', 'unknown'),
            source_port=traffic_data.get('source_port', 0),
            destination_port=traffic_data.get('destination_port', 0),
            protocol=traffic_data.get('protocol', 'TCP'),
            description=description,
            rule_id=rule.rule_id,
            status=AlertStatus.NEW
        )
    
    def get_alerts(self, severity: AlertSeverity = None, status: AlertStatus = None,
                   attack_type: AttackType = None) -> List[IDSAlert]:
        """获取告警列表"""
        alerts = self.alerts
        
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        
        if status:
            alerts = [a for a in alerts if a.status == status]
        
        if attack_type:
            alerts = [a for a in alerts if a.attack_type == attack_type]
        
        return alerts
    
    def update_alert_status(self, alert_id: str, status: AlertStatus,
                           assigned_to: str = None, note: str = None) -> Optional[IDSAlert]:
        """更新告警状态"""
        for alert in self.alerts:
            if alert.alert_id == alert_id:
                alert.status = status
                if assigned_to:
                    alert.assigned_to = assigned_to
                if note:
                    alert.notes.append(f"{datetime.datetime.now().isoformat()}: {note}")
                return alert
        return None
    
    def get_statistics(self, hours: int = 24) -> Dict:
        """获取统计信息"""
        cutoff = (datetime.datetime.now() - datetime.timedelta(hours=hours)).isoformat()
        
        recent_alerts = [a for a in self.alerts if a.timestamp >= cutoff]
        
        return {
            'period': f'{hours} hours',
            'total_alerts': len(recent_alerts),
            'by_severity': dict(self.stats['by_severity']),
            'by_attack_type': dict(self.stats['by_attack_type']),
            'by_status': {
                status.value: len([a for a in recent_alerts if a.status == status])
                for status in AlertStatus
            },
            'top_attack_sources': self._get_top_sources(recent_alerts)
        }
    
    def _get_top_sources(self, alerts: List[IDSAlert], limit: int = 10) -> List[Dict]:
        """获取攻击源排名"""
        source_counts = defaultdict(int)
        for alert in alerts:
            if alert.source_ip != 'unknown':
                source_counts[alert.source_ip] += 1
        
        return [
            {'ip': ip, 'count': count}
            for ip, count in sorted(source_counts.items(), key=lambda x: x[1], reverse=True)[:limit]
        ]


if __name__ == '__main__':
    print("=" * 60)
    print("入侵检测系统演示")
    print("=" * 60)
    
    # 创建IDS引擎
    ids = IntrusionDetectionEngine()
    
    # 模拟流量数据
    traffic_data = {
        'packets': [
            {'source_ip': '192.168.1.100', 'destination_ip': '10.0.0.1', 'source_port': 54321, 'destination_port': 80}
        ] * 150,  # 模拟大量流量
        'connections': [
            {'source_ip': '192.168.1.100', 'destination_port': port}
            for port in range(20, 35)  # 模拟端口扫描
        ],
        'payload': "SELECT * FROM users WHERE id=1 UNION SELECT password FROM admin--"
    }
    
    # 分析流量
    alerts = ids.analyze_traffic(traffic_data)
    
    print(f"\n检测到 {len(alerts)} 个告警:")
    for alert in alerts[:5]:
        print(f"  [{alert.severity.value}] {alert.attack_type.value}: {alert.description[:60]}...")
    
    # 获取统计
    stats = ids.get_statistics(hours=24)
    print(f"\n统计信息:")
    print(f"  总告警数: {stats['total_alerts']}")
    print(f"  按严重程度: {stats['by_severity']}")
    
    print("\n" + "=" * 60)
