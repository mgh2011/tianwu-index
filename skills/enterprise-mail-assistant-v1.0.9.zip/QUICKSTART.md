# 快速开始指南 - 5分钟上手

## 🚀 3步快速体验

### 第一步：运行快速演示
```bash
python quick_start.py
```
这将展示所有核心功能，大约需要30秒。

### 第二步：体验邮件分类
```bash
python demos/demo_mail_classification.py
```

### 第三步：体验安全检查
```bash
python demos/demo_security_check.py
```

---

## 📚 功能概览

| 功能 | 命令 | 说明 |
|------|------|------|
| 邮件分类 | `python demos/demo_mail_classification.py` | 智能识别邮件类型 |
| 安全检测 | `python demos/demo_security_check.py` | 检测钓鱼、病毒等威胁 |
| 自动回复 | `python demos/demo_auto_reply.py` | 自动生成回复内容 |
| 备份管理 | `python demos/demo_backup_restore.py` | 邮件数据备份恢复 |

---

## 💡 命令行使用

### 邮件分类
```bash
python cli.py classify --subject "会议邀请" --sender "boss@company.com"
```

### 安全检查
```bash
python cli.py security --sender "unknown@suspicious.com" --body "点击这里"
```

### 生成回复
```bash
python cli.py reply --subject "产品咨询" --body "请问价格是多少"
```

---

## 🔧 集成到您的项目

```python
# 导入邮件分类器
from demos.demo_mail_classification import MailClassifier

classifier = MailClassifier()

# 分类邮件
email = {
    "subject": "项目会议邀请",
    "sender": "colleague@company.com",
    "body": "明天下午3点项目会议"
}

category, icon, confidence = classifier.classify(email)
print(f"分类: {category[0]}, 置信度: {confidence*100:.0f}%")
```

---

## ❓ 常见问题

**Q: 需要安装依赖吗？**
A: 不需要！本技能使用Python标准库，直接运行即可。

**Q: 可以处理真实邮件吗？**
A: 可以。本演示使用模拟数据，您可以轻松替换为真实邮件数据。

**Q: 如何扩展功能？**
A: 参考示例代码中的规则定义，您可以根据需要添加新的分类规则。
