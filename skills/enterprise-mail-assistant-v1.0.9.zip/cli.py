#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
命令行工具
统一入口的CLI工具
"""

import sys
import argparse
from datetime import datetime

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def cmd_classify(args):
    """邮件分类命令"""
    print(f"""
{Colors.CYAN}╔════════════════════════════════════╗
║    📧 邮件分类功能                   ║
╚════════════════════════════════════╝{Colors.ENDC}
""")
    
    from demos.demo_mail_classification import MailClassifier, MailCategory
    
    classifier = MailClassifier()
    
    email = {
        "subject": args.subject or "测试邮件",
        "sender": args.sender or "test@example.com",
        "body": args.body or ""
    }
    
    cat, icon, conf = classifier.classify(email)
    
    print(f"\n📧 邮件信息:")
    print(f"   主题: {email['subject']}")
    print(f"   发件人: {email['sender']}")
    print(f"\n{Colors.GREEN}{icon} 分类结果: {cat}{Colors.ENDC}")
    print(f"{Colors.YELLOW}📊 置信度: {conf*100:.0f}%{Colors.ENDC}")

def cmd_security(args):
    """安全检查命令"""
    print(f"""
{Colors.CYAN}╔════════════════════════════════════╗
║    🔒 邮件安全检查                  ║
╚════════════════════════════════════╝{Colors.ENDC}
""")
    
    from demos.demo_security_check import SecurityChecker
    
    checker = SecurityChecker()
    
    email = {
        "subject": args.subject or "测试邮件",
        "sender": args.sender or "test@example.com",
        "body": args.body or "",
        "attachments": []
    }
    
    report = checker.check(email)
    level = report["threat_level"]
    
    print(f"\n📧 邮件信息:")
    print(f"   主题: {email['subject']}")
    print(f"   发件人: {email['sender']}")
    print(f"\n{Colors.GREEN}🔒 威胁等级: {level[1]} {level[0]}{Colors.ENDC}")
    print(f"{Colors.YELLOW}📊 风险评分: {report['risk_score']}/100{Colors.ENDC}")
    
    if report["warnings"]:
        print(f"\n{Colors.RED}⚠️  警告:{Colors.ENDC}")
        for w in report["warnings"][:3]:
            print(f"   • {w}")

def cmd_reply(args):
    """自动回复命令"""
    print(f"""
{Colors.CYAN}╔════════════════════════════════════╗
║    📤 自动回复生成                  ║
╚════════════════════════════════════╝{Colors.ENDC}
""")
    
    from demos.demo_auto_reply import AutoReplyGenerator
    
    generator = AutoReplyGenerator()
    
    email = {
        "subject": args.subject or "测试邮件",
        "sender": args.sender or "test@example.com",
        "body": args.body or ""
    }
    
    reply = generator.generate(email)
    
    print(f"\n📩 原始邮件:")
    print(f"   主题: {email['subject']}")
    print(f"   内容: {email['body'] or '(无正文)'}")
    print(f"\n{Colors.GREEN}📤 自动回复:{Colors.ENDC}")
    print(f"   {reply}")

def cmd_backup(args):
    """备份管理命令"""
    print(f"""
{Colors.CYAN}╔════════════════════════════════════╗
║    💾 备份管理                      ║
╚════════════════════════════════════╝{Colors.ENDC}
""")
    
    from demos.demo_backup_restore import BackupManager
    
    manager = BackupManager()
    backups = manager.list_backups()
    
    print(f"\n📦 当前备份 ({len(backups)} 个):\n")
    for b in backups:
        print(f"   ✅ {b['name']} | {b['timestamp']} | {b['size']}")

def cmd_demo(args):
    """运行演示"""
    print(f"""
{Colors.CYAN}╔════════════════════════════════════╗
║    🎬 运行演示                      ║
╚════════════════════════════════════╝{Colors.ENDC}
""")
    print(f"\n{Colors.YELLOW}请使用以下命令运行具体演示:{Colors.ENDC}")
    print(f"   python demos/demo_mail_classification.py")
    print(f"   python demos/demo_security_check.py")
    print(f"   python demos/demo_auto_reply.py")
    print(f"   python demos/demo_backup_restore.py")

def main():
    parser = argparse.ArgumentParser(
        description="企业级智能邮件助手 CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python cli.py classify --subject "会议邀请" --sender "boss@company.com"
  python cli.py security --sender "test@unknown.com" --body "点击这里"
  python cli.py reply --subject "咨询" --body "请问产品价格"
  python cli.py backup --list
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # classify
    p_classify = subparsers.add_parser("classify", help="邮件分类")
    p_classify.add_argument("--subject", "-s", help="邮件主题")
    p_classify.add_argument("--sender", "-f", help="发件人")
    p_classify.add_argument("--body", "-b", help="邮件正文")
    
    # security
    p_security = subparsers.add_parser("security", help="安全检查")
    p_security.add_argument("--subject", "-s", help="邮件主题")
    p_security.add_argument("--sender", "-f", help="发件人")
    p_security.add_argument("--body", "-b", help="邮件正文")
    
    # reply
    p_reply = subparsers.add_parser("reply", help="生成自动回复")
    p_reply.add_argument("--subject", "-s", help="邮件主题")
    p_reply.add_argument("--sender", "-f", help="发件人")
    p_reply.add_argument("--body", "-b", help="邮件正文")
    
    # backup
    p_backup = subparsers.add_parser("backup", help="备份管理")
    p_backup.add_argument("--list", "-l", action="store_true", help="列出备份")
    
    # demo
    p_demo = subparsers.add_parser("demo", help="运行演示")
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        print(f"\n{Colors.CYAN}快速开始: 运行 python quick_start.py 查看所有功能演示{Colors.ENDC}")
        return 0
    
    commands = {
        "classify": cmd_classify,
        "security": cmd_security,
        "reply": cmd_reply,
        "backup": cmd_backup,
        "demo": cmd_demo
    }
    
    if args.command in commands:
        commands[args.command](args)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
