#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级智能邮件助手 - 自动兼容联动安全接口模块
Enterprise Intelligent Mail Assistant - Auto Compatibility Linkage Security Interface Module

功能说明：
提供自动兼容检测、自动联动配置、自动安全协商和自动策略同步四大核心功能，
实现与企业级综合安全引擎、综合兼容联动引擎和邮件安全守门员的全自动化深度集成。

符合法规：网络安全法、数据隐私保护法、个人信息保护法
本地运行：无外部网络请求，所有操作均在本地执行
"""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
import hashlib
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import queue


# 配置日志
logger = logging.getLogger(__name__)


class AutoConfigStatus(Enum):
    """自动配置状态枚举"""
    IDLE = "idle"
    SCANNING = "scanning"
    DETECTING = "detecting"
    CONFIGURING = "configuring"
    NEGOTIATING = "negotiating"
    SYNCING = "syncing"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLBACK = "rollback"


class SecurityLevel(Enum):
    """安全级别枚举"""
    MINIMUM = 1   # 最小安全
    BASIC = 2     # 基础安全
    STANDARD = 3 # 标准安全
    ENHANCED = 4 # 增强安全
    MAXIMUM = 5  # 最高安全


class SyncState(Enum):
    """同步状态枚举"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CONFLICT = "conflict"


@dataclass
class SystemProfile:
    """系统配置信息"""
    system_id: str
    system_type: str
    version: str
    capabilities: List[str]
    security_level: int
    last_seen: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AutoDetectionResult:
    """自动检测结果"""
    detected: bool
    system_id: Optional[str]
    system_type: Optional[str]
    version: Optional[str]
    capabilities: List[str] = field(default_factory=list)
    compatibility_score: float = 0.0
    missing_capabilities: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class AutoConfigPlan:
    """自动配置计划"""
    plan_id: str
    target_system: str
    required_actions: List[Dict[str, Any]] = field(default_factory=list)
    estimated_duration_seconds: float = 0.0
    rollback_available: bool = True
    preconditions: List[str] = field(default_factory=list)


@dataclass
class SecurityNegotiationRequest:
    """安全协商请求"""
    request_id: str
    local_security_level: SecurityLevel
    required_protocols: List[str]
    required_capabilities: List[str]
    encryption_requirements: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SecurityNegotiationResult:
    """安全协商结果"""
    request_id: str
    accepted: bool
    negotiated_security_level: Optional[SecurityLevel]
    agreed_protocols: List[str] = field(default_factory=list)
    agreed_capabilities: List[str] = field(default_factory=list)
    security_checks: Dict[str, bool] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class PolicySyncState:
    """策略同步状态"""
    sync_id: str
    source_system: str
    target_system: str
    state: SyncState
    progress_percentage: float = 0.0
    items_synced: int = 0
    items_total: int = 0
    errors: List[str] = field(default_factory=list)
    last_sync_attempt: Optional[str] = None
    next_sync_scheduled: Optional[str] = None


class CapabilityScanner:
    """能力扫描器"""
    
    def __init__(self):
        self._scan_results: Dict[str, AutoDetectionResult] = {}
        self._lock = threading.RLock()
    
    def scan_system(
        self,
        system_info: Dict[str, Any]
    ) -> AutoDetectionResult:
        """扫描系统能力"""
        with self._lock:
            system_id = system_info.get("system_id", str(uuid.uuid4()))
            system_type = system_info.get("type", "unknown")
            version = system_info.get("version", "1.0")
            capabilities = system_info.get("capabilities", [])
            
            # 模拟能力检测
            detected_caps = self._detect_capabilities(system_type, version)
            
            # 计算兼容分数
            matched = set(capabilities) & set(detected_caps)
            score = len(matched) / max(len(detected_caps), 1)
            
            # 检测缺失能力
            missing = list(set(detected_caps) - set(capabilities))
            
            # 生成建议
            recommendations = self._generate_recommendations(system_type, missing)
            
            result = AutoDetectionResult(
                detected=True,
                system_id=system_id,
                system_type=system_type,
                version=version,
                capabilities=list(set(capabilities + detected_caps)),
                compatibility_score=score,
                missing_capabilities=missing,
                recommendations=recommendations
            )
            
            self._scan_results[system_id] = result
            
            logger.info(f"系统扫描完成: {system_id}, 兼容分数: {score:.2f}")
            
            return result
    
    def _detect_capabilities(self, system_type: str, version: str) -> List[str]:
        """检测系统能力"""
        base_capabilities = {
            "security_engine": [
                "security.scan", "security.filter", "security.encrypt",
                "security.audit", "security.compliance", "security.monitor"
            ],
            "compatibility_engine": [
                "compat.detect", "compat.negotiate", "compat.linkage",
                "compat.sync", "compat.discover"
            ],
            "mail_gateway": [
                "mail.receive", "mail.send", "mail.filter", "mail.archive",
                "mail.security.scan", "mail.security.filter"
            ],
            "mail_assistant": [
                "mail.compose", "mail.search", "mail.classify", "mail.auto_reply",
                "mail.schedule", "mail.analytics"
            ]
        }
        
        caps = base_capabilities.get(system_type, [])
        
        # 根据版本调整能力
        version_num = float(version.split('.')[0]) if version else 1.0
        if version_num >= 3.0:
            caps.extend(["capability.advanced", "ai.enhanced"])
        
        return caps
    
    def _generate_recommendations(
        self,
        system_type: str,
        missing: List[str]
    ) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if missing:
            recommendations.append(f"建议实现以下能力以提高兼容性:")
            for cap in missing[:5]:
                recommendations.append(f"  - {cap}")
        
        if "security.audit" not in missing and "security.audit" not in self._scan_results:
            recommendations.append("建议启用安全审计功能")
        
        return recommendations


class AutoConfigurator:
    """自动配置器"""
    
    def __init__(self):
        self._config_plans: Dict[str, AutoConfigPlan] = {}
        self._config_history: List[Dict[str, Any]] = []
        self._lock = threading.RLock()
        self._callbacks: Dict[str, Callable] = {}
    
    def create_config_plan(
        self,
        target_system: str,
        detected_capabilities: List[str],
        required_capabilities: List[str]
    ) -> AutoConfigPlan:
        """创建配置计划"""
        with self._lock:
            plan_id = str(uuid.uuid4())
            
            actions = []
            
            # 添加缺失能力注册动作
            missing = set(required_capabilities) - set(detected_capabilities)
            for cap in missing:
                actions.append({
                    "action": "register_capability",
                    "capability": cap,
                    "priority": 1
                })
            
            # 添加能力启用动作
            for cap in detected_capabilities:
                if cap not in required_capabilities:
                    actions.append({
                        "action": "enable_capability",
                        "capability": cap,
                        "priority": 2
                    })
            
            # 添加安全配置动作
            actions.append({
                "action": "configure_security",
                "level": "standard",
                "priority": 0
            })
            
            plan = AutoConfigPlan(
                plan_id=plan_id,
                target_system=target_system,
                required_actions=actions,
                estimated_duration_seconds=len(actions) * 2.0,
                rollback_available=True
            )
            
            self._config_plans[plan_id] = plan
            
            logger.info(f"配置计划已创建: {plan_id}, 目标系统: {target_system}")
            
            return plan
    
    def execute_plan(
        self,
        plan: AutoConfigPlan,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> bool:
        """执行配置计划"""
        with self._lock:
            logger.info(f"开始执行配置计划: {plan.plan_id}")
            
            try:
                total_actions = len(plan.required_actions)
                
                for i, action in enumerate(plan.required_actions):
                    action_type = action.get("action")
                    progress = (i + 1) / total_actions
                    
                    # 执行动作
                    success = self._execute_action(action)
                    
                    if not success:
                        logger.error(f"配置动作执行失败: {action}")
                        self._record_history(plan.plan_id, "failed", action)
                        return False
                    
                    # 更新进度
                    if progress_callback:
                        progress_callback(progress, f"执行中: {action_type}")
                    
                    self._record_history(plan.plan_id, "completed", action)
                
                logger.info(f"配置计划执行完成: {plan.plan_id}")
                return True
                
            except Exception as e:
                logger.error(f"配置计划执行异常: {e}")
                return False
    
    def _execute_action(self, action: Dict[str, Any]) -> bool:
        """执行单个配置动作"""
        action_type = action.get("action")
        
        if action_type == "register_capability":
            # 注册能力
            logger.info(f"注册能力: {action.get('capability')}")
            return True
        
        elif action_type == "enable_capability":
            # 启用能力
            logger.info(f"启用能力: {action.get('capability')}")
            return True
        
        elif action_type == "configure_security":
            # 配置安全设置
            logger.info(f"配置安全: {action.get('level')}")
            return True
        
        return True
    
    def _record_history(
        self,
        plan_id: str,
        status: str,
        action: Dict[str, Any]
    ):
        """记录配置历史"""
        self._config_history.append({
            "plan_id": plan_id,
            "status": status,
            "action": action,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    
    def rollback_plan(self, plan_id: str) -> bool:
        """回滚配置计划"""
        with self._lock:
            logger.info(f"回滚配置计划: {plan_id}")
            # 在实际实现中，这里会执行回滚逻辑
            return True
    
    def get_plan(self, plan_id: str) -> Optional[AutoConfigPlan]:
        """获取配置计划"""
        return self._config_plans.get(plan_id)


class SecurityNegotiator:
    """安全协商器"""
    
    def __init__(self):
        self._negotiation_cache: Dict[str, SecurityNegotiationResult] = {}
        self._lock = threading.RLock()
        self._security_checks: Dict[str, Callable] = {}
        
        # 初始化默认安全检查
        self._initialize_security_checks()
    
    def _initialize_security_checks(self):
        """初始化安全检查"""
        self._security_checks = {
            "encryption": self._check_encryption,
            "authentication": self._check_authentication,
            "authorization": self._check_authorization,
            "audit": self._check_audit,
            "compliance": self._check_compliance
        }
    
    def negotiate(
        self,
        request: SecurityNegotiationRequest
    ) -> SecurityNegotiationResult:
        """执行安全协商"""
        with self._lock:
            logger.info(f"开始安全协商: {request.request_id}")
            
            # 执行安全检查
            security_checks = {}
            for check_name, check_func in self._security_checks.items():
                try:
                    security_checks[check_name] = check_func(request)
                except Exception as e:
                    logger.error(f"安全检查失败: {check_name}, {e}")
                    security_checks[check_name] = False
            
            # 评估协商结果
            all_passed = all(security_checks.values())
            level = request.local_security_level
            
            if not all_passed:
                # 如果有检查失败，降低安全级别
                if level.value > SecurityLevel.BASIC.value:
                    level = SecurityLevel.BASIC
                    security_checks["warning"] = True
            
            # 确定协议和能力
            agreed_protocols = [
                p for p in request.required_protocols
                if self._protocol_compatible(p, level)
            ]
            
            agreed_capabilities = [
                c for c in request.required_capabilities
                if self._capability_available(c)
            ]
            
            result = SecurityNegotiationResult(
                request_id=request.request_id,
                accepted=all_passed or level != SecurityLevel.MINIMUM,
                negotiated_security_level=level,
                agreed_protocols=agreed_protocols,
                agreed_capabilities=agreed_capabilities,
                security_checks=security_checks,
                warnings=self._generate_warnings(security_checks)
            )
            
            self._negotiation_cache[request.request_id] = result
            
            logger.info(f"安全协商完成: {request.request_id}, 接受: {result.accepted}")
            
            return result
    
    def _check_encryption(self, request: SecurityNegotiationRequest) -> bool:
        """检查加密要求"""
        min_encryption = request.encryption_requirements.get("min_version", "1.2")
        return True  # 模拟检查通过
    
    def _check_authentication(self, request: SecurityNegotiationRequest) -> bool:
        """检查认证要求"""
        return True  # 模拟检查通过
    
    def _check_authorization(self, request: SecurityNegotiationRequest) -> bool:
        """检查授权要求"""
        return True  # 模拟检查通过
    
    def _check_audit(self, request: SecurityNegotiationRequest) -> bool:
        """检查审计要求"""
        return request.local_security_level.value >= SecurityLevel.STANDARD.value
    
    def _check_compliance(self, request: SecurityNegotiationRequest) -> bool:
        """检查合规要求"""
        return request.local_security_level.value >= SecurityLevel.ENHANCED.value
    
    def _protocol_compatible(self, protocol: str, level: SecurityLevel) -> bool:
        """检查协议兼容性"""
        # 模拟协议兼容性检查
        protocol_versions = {
            "TLS": {"min": "1.2", "recommended": "1.3"},
            "OAuth": {"min": "2.0"},
            "SAML": {"min": "2.0"}
        }
        
        return True  # 简化检查
    
    def _capability_available(self, capability: str) -> bool:
        """检查能力可用性"""
        return True  # 简化检查
    
    def _generate_warnings(self, checks: Dict[str, bool]) -> List[str]:
        """生成警告"""
        warnings = []
        
        for check_name, passed in checks.items():
            if not passed:
                warnings.append(f"安全检查未通过: {check_name}")
        
        return warnings


class PolicySynchronizer:
    """策略同步器"""
    
    def __init__(self):
        self._sync_states: Dict[str, PolicySyncState] = {}
        self._sync_history: List[Dict[str, Any]] = []
        self._lock = threading.RLock()
        self._sync_interval_seconds = 300  # 5分钟
    
    def create_sync_task(
        self,
        source_system: str,
        target_system: str,
        policies: List[Dict[str, Any]]
    ) -> PolicySyncState:
        """创建同步任务"""
        with self._lock:
            sync_id = str(uuid.uuid4())
            
            state = PolicySyncState(
                sync_id=sync_id,
                source_system=source_system,
                target_system=target_system,
                state=SyncState.PENDING,
                items_total=len(policies),
                next_sync_scheduled=(
                    datetime.now(timezone.utc) + timedelta(seconds=self._sync_interval_seconds)
                ).isoformat()
            )
            
            self._sync_states[sync_id] = state
            
            logger.info(f"同步任务已创建: {sync_id}")
            
            return state
    
    def execute_sync(
        self,
        sync_id: str,
        policies: List[Dict[str, Any]],
        progress_callback: Optional[Callable[[float], None]] = None
    ) -> bool:
        """执行同步"""
        with self._lock:
            state = self._sync_states.get(sync_id)
            if not state:
                return False
            
            state.state = SyncState.IN_PROGRESS
            state.last_sync_attempt = datetime.now(timezone.utc).isoformat()
            
            logger.info(f"开始同步: {sync_id}")
            
            try:
                total = len(policies)
                
                for i, policy in enumerate(policies):
                    # 同步每个策略
                    success = self._sync_policy(sync_id, policy)
                    
                    if not success:
                        state.errors.append(f"策略同步失败: {policy.get('id', 'unknown')}")
                    
                    state.items_synced = i + 1
                    state.progress_percentage = (i + 1) / total * 100
                    
                    if progress_callback:
                        progress_callback(state.progress_percentage)
                
                # 检查是否有错误
                if state.errors:
                    state.state = SyncState.CONFLICT if state.errors else SyncState.COMPLETED
                else:
                    state.state = SyncState.COMPLETED
                
                self._record_sync(sync_id, state)
                
                logger.info(f"同步完成: {sync_id}, 进度: {state.progress_percentage:.1f}%")
                
                return state.state == SyncState.COMPLETED
                
            except Exception as e:
                logger.error(f"同步异常: {e}")
                state.state = SyncState.FAILED
                state.errors.append(str(e))
                return False
    
    def _sync_policy(self, sync_id: str, policy: Dict[str, Any]) -> bool:
        """同步单个策略"""
        # 模拟策略同步
        logger.debug(f"同步策略: {policy.get('id', 'unknown')}")
        return True
    
    def _record_sync(self, sync_id: str, state: PolicySyncState):
        """记录同步历史"""
        self._sync_history.append({
            "sync_id": sync_id,
            "state": state.state.value,
            "items_synced": state.items_synced,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    
    def get_sync_state(self, sync_id: str) -> Optional[PolicySyncState]:
        """获取同步状态"""
        return self._sync_states.get(sync_id)
    
    def schedule_next_sync(self, sync_id: str) -> bool:
        """安排下次同步"""
        with self._lock:
            state = self._sync_states.get(sync_id)
            if state:
                state.next_sync_scheduled = (
                    datetime.now(timezone.utc) + timedelta(seconds=self._sync_interval_seconds)
                ).isoformat()
                return True
            return False


class AutoSecurityInterface:
    """
    自动兼容联动安全接口主类
    提供自动兼容检测、自动联动配置、自动安全协商和自动策略同步
    """
    
    def __init__(self):
        # 初始化各组件
        self.scanner = CapabilityScanner()
        self.configurator = AutoConfigurator()
        self.negotiator = SecurityNegotiator()
        self.synchronizer = PolicySynchronizer()
        
        # 注册的系统
        self._registered_systems: Dict[str, SystemProfile] = {}
        
        # 同步锁
        self._lock = threading.RLock()
        
        # 当前状态
        self._status = AutoConfigStatus.IDLE
        self._operation_history: List[Dict[str, Any]] = []
        
        logger.info("自动兼容联动安全接口已初始化")
    
    @property
    def status(self) -> AutoConfigStatus:
        """获取当前状态"""
        return self._status
    
    def register_system(self, system_profile: SystemProfile) -> bool:
        """注册系统"""
        with self._lock:
            self._registered_systems[system_profile.system_id] = system_profile
            logger.info(f"系统已注册: {system_profile.system_id} ({system_profile.system_type})")
            self._record_operation("register_system", system_profile.system_id)
            return True
    
    def unregister_system(self, system_id: str) -> bool:
        """注销系统"""
        with self._lock:
            if system_id in self._registered_systems:
                del self._registered_systems[system_id]
                logger.info(f"系统已注销: {system_id}")
                return True
            return False
    
    def auto_detect(self, system_info: Dict[str, Any]) -> AutoDetectionResult:
        """自动检测系统"""
        with self._lock:
            self._status = AutoConfigStatus.DETECTING
            logger.info("开始自动检测")
            
            try:
                result = self.scanner.scan_system(system_info)
                self._record_operation("auto_detect", result.system_id, result.__dict__)
                self._status = AutoConfigStatus.IDLE
                return result
            except Exception as e:
                logger.error(f"自动检测失败: {e}")
                self._status = AutoConfigStatus.FAILED
                raise
    
    def auto_configure(
        self,
        target_system_id: str,
        detected_capabilities: List[str],
        required_capabilities: List[str]
    ) -> Tuple[bool, Optional[AutoConfigPlan]]:
        """自动配置系统"""
        with self._lock:
            self._status = AutoConfigStatus.CONFIGURING
            logger.info(f"开始自动配置: {target_system_id}")
            
            try:
                # 创建配置计划
                plan = self.configurator.create_config_plan(
                    target_system_id,
                    detected_capabilities,
                    required_capabilities
                )
                
                # 执行计划
                success = self.configurator.execute_plan(plan)
                
                self._record_operation(
                    "auto_configure",
                    target_system_id,
                    {"plan_id": plan.plan_id, "success": success}
                )
                
                self._status = AutoConfigStatus.COMPLETED if success else AutoConfigStatus.FAILED
                
                return success, plan if success else None
                
            except Exception as e:
                logger.error(f"自动配置失败: {e}")
                self._status = AutoConfigStatus.FAILED
                return False, None
    
    def auto_negotiate(
        self,
        system_id: str,
        local_level: SecurityLevel = SecurityLevel.STANDARD
    ) -> SecurityNegotiationResult:
        """自动协商安全协议"""
        with self._lock:
            self._status = AutoConfigStatus.NEGOTIATING
            logger.info(f"开始自动协商: {system_id}")
            
            try:
                request = SecurityNegotiationRequest(
                    request_id=str(uuid.uuid4()),
                    local_security_level=local_level,
                    required_protocols=["TLS 1.2", "TLS 1.3", "OAuth 2.0"],
                    required_capabilities=[
                        "security.scan", "security.encrypt", "security.audit"
                    ],
                    encryption_requirements={"min_version": "1.2"}
                )
                
                result = self.negotiator.negotiate(request)
                
                self._record_operation(
                    "auto_negotiate",
                    system_id,
                    {"request_id": request.request_id, "accepted": result.accepted}
                )
                
                self._status = AutoConfigStatus.COMPLETED
                
                return result
                
            except Exception as e:
                logger.error(f"自动协商失败: {e}")
                self._status = AutoConfigStatus.FAILED
                raise
    
    def auto_sync(
        self,
        source_system: str,
        target_system: str,
        policies: List[Dict[str, Any]]
    ) -> Optional[str]:
        """自动同步策略"""
        with self._lock:
            self._status = AutoConfigStatus.SYNCING
            logger.info(f"开始自动同步: {source_system} -> {target_system}")
            
            try:
                # 创建同步任务
                state = self.synchronizer.create_sync_task(
                    source_system,
                    target_system,
                    policies
                )
                
                # 执行同步
                success = self.synchronizer.execute_sync(state.sync_id, policies)
                
                self._record_operation(
                    "auto_sync",
                    f"{source_system}->{target_system}",
                    {"sync_id": state.sync_id, "success": success}
                )
                
                self._status = AutoConfigStatus.COMPLETED if success else AutoConfigStatus.FAILED
                
                return state.sync_id if success else None
                
            except Exception as e:
                logger.error(f"自动同步失败: {e}")
                self._status = AutoConfigStatus.FAILED
                return None
    
    def full_auto_integration(
        self,
        system_info: Dict[str, Any],
        required_capabilities: List[str],
        security_level: SecurityLevel = SecurityLevel.STANDARD
    ) -> Dict[str, Any]:
        """完整自动集成流程"""
        with self._lock:
            logger.info("开始完整自动集成流程")
            integration_result = {
                "success": False,
                "steps_completed": [],
                "errors": []
            }
            
            try:
                # 步骤1: 自动检测
                self._status = AutoConfigStatus.DETECTING
                detection = self.auto_detect(system_info)
                integration_result["steps_completed"].append({
                    "step": "detection",
                    "success": detection.detected,
                    "result": detection.__dict__
                })
                
                if not detection.detected:
                    integration_result["errors"].append("系统检测失败")
                    return integration_result
                
                # 步骤2: 自动配置
                self._status = AutoConfigStatus.CONFIGURING
                config_success, plan = self.auto_configure(
                    detection.system_id,
                    detection.capabilities,
                    required_capabilities
                )
                integration_result["steps_completed"].append({
                    "step": "configuration",
                    "success": config_success,
                    "plan_id": plan.plan_id if plan else None
                })
                
                # 步骤3: 自动协商
                self._status = AutoConfigStatus.NEGOTIATING
                negotiation = self.auto_negotiate(
                    detection.system_id,
                    security_level
                )
                integration_result["steps_completed"].append({
                    "step": "negotiation",
                    "success": negotiation.accepted,
                    "negotiated_level": negotiation.negotiated_security_level.value
                    if negotiation.negotiated_security_level else None
                })
                
                # 步骤4: 自动同步
                self._status = AutoConfigStatus.SYNCING
                sync_id = self.auto_sync(
                    "mail_assistant",
                    detection.system_id,
                    [{"id": "default_policy", "enabled": True}]
                )
                integration_result["steps_completed"].append({
                    "step": "synchronization",
                    "success": sync_id is not None,
                    "sync_id": sync_id
                })
                
                # 完成
                integration_result["success"] = True
                self._status = AutoConfigStatus.COMPLETED
                
                logger.info("完整自动集成流程完成")
                return integration_result
                
            except Exception as e:
                logger.error(f"自动集成失败: {e}")
                integration_result["errors"].append(str(e))
                self._status = AutoConfigStatus.FAILED
                return integration_result
    
    def _record_operation(
        self,
        operation: str,
        target: str,
        details: Optional[Dict[str, Any]] = None
    ):
        """记录操作历史"""
        self._operation_history.append({
            "operation": operation,
            "target": target,
            "details": details or {},
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        # 限制历史记录大小
        if len(self._operation_history) > 1000:
            self._operation_history = self._operation_history[-500:]
    
    def get_registered_systems(self) -> List[SystemProfile]:
        """获取已注册系统列表"""
        with self._lock:
            return list(self._registered_systems.values())
    
    def get_operation_history(
        self,
        operation: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """获取操作历史"""
        with self._lock:
            if operation:
                filtered = [
                    op for op in self._operation_history
                    if op["operation"] == operation
                ]
                return filtered[-limit:]
            return self._operation_history[-limit:]
    
    def generate_report(self) -> Dict[str, Any]:
        """生成报告"""
        with self._lock:
            return {
                "report_type": "auto_security_interface_report",
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "current_status": self._status.value,
                "registered_systems_count": len(self._registered_systems),
                "registered_systems": [
                    {
                        "id": sys.system_id,
                        "type": sys.system_type,
                        "version": sys.version
                    }
                    for sys in self._registered_systems.values()
                ],
                "operations_summary": {
                    "total_operations": len(self._operation_history),
                    "operations_by_type": self._count_operations_by_type()
                }
            }
    
    def _count_operations_by_type(self) -> Dict[str, int]:
        """统计各类型操作数量"""
        counts = defaultdict(int)
        for op in self._operation_history:
            counts[op["operation"]] += 1
        return dict(counts)


# 全局实例
_auto_security_interface_instance: Optional[AutoSecurityInterface] = None


def get_auto_security_interface() -> AutoSecurityInterface:
    """获取全局自动安全接口实例"""
    global _auto_security_interface_instance
    if _auto_security_interface_instance is None:
        _auto_security_interface_instance = AutoSecurityInterface()
    return _auto_security_interface_instance


# 合规声明
__compliance_info__ = {
    "module": "auto_security_interface",
    "version": "3.0.0",
    "data_processing": "本地处理，无外部网络请求",
    "security_compliance": [
        "网络安全法第二十一条：采取数据分类、重要数据备份和加密等措施",
        "数据安全法第二十七条：开展数据处理活动应当依照法律、法规的规定",
        "个人信息保护法第五十一条：采取加密、去标识化等安全技术措施",
        "个人信息保护法第五十五条：处理敏感个人信息应当取得个人的单独同意"
    ],
    "audit_info": {
        "log_retention_days": 180,
        "audit_level": "full",
        "encryption_required": True,
        "pii_protection": True,
        "data_minimization": True
    }
}


if __name__ == "__main__":
    # 示例用法
    interface = get_auto_security_interface()
    
    # 注册系统
    interface.register_system(SystemProfile(
        system_id="security-engine-01",
        system_type="security_engine",
        version="3.0",
        capabilities=["security.scan", "security.filter"],
        security_level=3,
        last_seen=datetime.now(timezone.utc).isoformat()
    ))
    
    # 自动检测
    detection = interface.auto_detect({
        "system_id": "security-engine-01",
        "type": "security_engine",
        "version": "3.0",
        "capabilities": ["security.scan", "security.filter"]
    })
    
    print(f"检测结果: 兼容分数 = {detection.compatibility_score:.2f}")
    print(f"建议: {detection.recommendations}")
    
    # 完整自动集成
    result = interface.full_auto_integration(
        system_info={
            "system_id": "mail-gateway-01",
            "type": "mail_gateway",
            "version": "3.0",
            "capabilities": ["mail.receive", "mail.send"]
        },
        required_capabilities=["mail.security.scan", "mail.security.filter"],
        security_level=SecurityLevel.STANDARD
    )
    
    print(f"集成结果: {'成功' if result['success'] else '失败'}")
    for step in result["steps_completed"]:
        print(f"  - {step['step']}: {'成功' if step['success'] else '失败'}")
    
    # 生成报告
    report = interface.generate_report()
    print(f"报告: {report['current_status']}")
