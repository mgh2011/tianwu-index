#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级智能邮件助手 - 兼容与联动接口模块
Enterprise Intelligent Mail Assistant - Compatibility and Linkage Interface Module

功能说明：
提供兼容性检测、联动协议、版本协商和能力发现等核心接口，
实现与企业级综合安全引擎、综合兼容联动引擎和邮件安全守门员的深度集成。

符合法规：网络安全法、数据隐私保护法、个人信息保护法
本地运行：无外部网络请求，所有操作均在本地执行
"""

from __future__ import annotations

import json
import hashlib
import logging
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Protocol, Set, Tuple
from dataclasses import dataclass, field, asdict
from abc import ABC, abstractmethod
import threading
import uuid

# 配置日志
logger = logging.getLogger(__name__)


class CompatibilityLevel(Enum):
    """兼容级别枚举"""
    FULL = "full"                    # 完全兼容
    PARTIAL = "partial"              # 部分兼容
    LIMITED = "limited"              # 有限兼容
    INCOMPATIBLE = "incompatible"    # 不兼容


class ProtocolVersion(Enum):
    """协议版本枚举"""
    V1_0 = "1.0"
    V2_0 = "2.0"
    V3_0 = "3.0"
    LATEST = "3.0"


class SystemType(Enum):
    """系统类型枚举"""
    SECURITY_ENGINE = "security_engine"           # 企业级综合安全引擎
    COMPATIBILITY_ENGINE = "compatibility_engine"  # 企业级综合兼容联动引擎
    MAIL_GATEWAY = "mail_gateway"                  # 邮件安全守门员
    MAIL_ASSISTANT = "mail_assistant"              # 邮件助手


class CapabilityCategory(Enum):
    """能力类别枚举"""
    SECURITY = "security"
    DATA = "data"
    EVENT = "event"
    DECISION = "decision"
    MONITORING = "monitoring"


@dataclass
class VersionInfo:
    """版本信息数据结构"""
    major: int = 3
    minor: int = 0
    patch: int = 0
    build: str = ""
    
    def __str__(self) -> str:
        version = f"{self.major}.{self.minor}.{self.patch}"
        if self.build:
            version += f"-{self.build}"
        return version
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "major": self.major,
            "minor": self.minor,
            "patch": self.patch,
            "build": self.build,
            "full_version": str(self)
        }
    
    @classmethod
    def from_string(cls, version_str: str) -> VersionInfo:
        """从字符串解析版本信息"""
        version_str = version_str.strip().lstrip('vV')
        parts = version_str.split('-')
        version_parts = parts[0].split('.')
        
        return cls(
            major=int(version_parts[0]) if len(version_parts) > 0 else 1,
            minor=int(version_parts[1]) if len(version_parts) > 1 else 0,
            patch=int(version_parts[2]) if len(version_parts) > 2 else 0,
            build=parts[1] if len(parts) > 1 else ""
        )


@dataclass
class CapabilityInfo:
    """能力信息数据结构"""
    capability_id: str
    name: str
    category: CapabilityCategory
    version: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    deprecated: bool = False
    experimental: bool = False


@dataclass
class CompatibilityResult:
    """兼容性检测结果数据结构"""
    is_compatible: bool
    level: CompatibilityLevel
    score: float  # 0.0 - 1.0
    matched_capabilities: List[str] = field(default_factory=list)
    missing_capabilities: List[str] = field(default_factory=list)
    incompatible_capabilities: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class NegotiationRequest:
    """版本协商请求数据结构"""
    request_id: str
    system_type: SystemType
    local_version: VersionInfo
    required_capabilities: List[str]
    optional_capabilities: List[str]
    security_level: int = 3  # 1-5, 5为最高安全级别
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class NegotiationResponse:
    """版本协商响应数据结构"""
    request_id: str
    accepted: bool
    negotiated_version: Optional[VersionInfo]
    agreed_capabilities: List[str]
    rejected_capabilities: List[str]
    rejection_reasons: Dict[str, str] = field(default_factory=dict)
    security_requirements: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class CapabilityDiscoveryResult:
    """能力发现结果数据结构"""
    system_id: str
    system_type: SystemType
    capabilities: List[CapabilityInfo]
    supported_protocols: List[str]
    security_level: int
    performance_metrics: Dict[str, Any] = field(default_factory=dict)
    last_updated: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class CapabilityRegistry:
    """能力注册表 - 管理所有已注册的能力"""
    
    def __init__(self):
        self._capabilities: Dict[str, CapabilityInfo] = {}
        self._lock = threading.RLock()
    
    def register(self, capability: CapabilityInfo) -> bool:
        """注册能力"""
        with self._lock:
            if capability.deprecated:
                logger.warning(f"注册已弃用能力: {capability.capability_id}")
            
            self._capabilities[capability.capability_id] = capability
            logger.info(f"已注册能力: {capability.capability_id} ({capability.name})")
            return True
    
    def unregister(self, capability_id: str) -> bool:
        """注销能力"""
        with self._lock:
            if capability_id in self._capabilities:
                del self._capabilities[capability_id]
                logger.info(f"已注销能力: {capability_id}")
                return True
            return False
    
    def get(self, capability_id: str) -> Optional[CapabilityInfo]:
        """获取能力"""
        with self._lock:
            return self._capabilities.get(capability_id)
    
    def get_by_category(self, category: CapabilityCategory) -> List[CapabilityInfo]:
        """按类别获取能力"""
        with self._lock:
            return [
                cap for cap in self._capabilities.values()
                if cap.category == category
            ]
    
    def get_all(self) -> List[CapabilityInfo]:
        """获取所有能力"""
        with self._lock:
            return list(self._capabilities.values())
    
    def find_compatible(
        self,
        required: List[str],
        optional: List[str]
    ) -> Tuple[List[str], List[str], List[str]]:
        """
        查找兼容能力
        返回: (完全匹配列表, 部分匹配列表, 不匹配列表)
        """
        with self._lock:
            fully_matched = []
            partial_matched = []
            not_matched = []
            
            for cap_id in required:
                if cap_id in self._capabilities:
                    fully_matched.append(cap_id)
                else:
                    not_matched.append(cap_id)
            
            for cap_id in optional:
                if cap_id in self._capabilities:
                    partial_matched.append(cap_id)
            
            return fully_matched, partial_matched, not_matched


class CompatibilityDetector(ABC):
    """兼容性检测器抽象基类"""
    
    @abstractmethod
    def detect(self, target_system: SystemType, target_info: Dict[str, Any]) -> CompatibilityResult:
        """执行兼容性检测"""
        pass
    
    @abstractmethod
    def calculate_score(self, local_caps: List[str], target_caps: List[str]) -> float:
        """计算兼容分数"""
        pass


class StandardCompatibilityDetector(CompatibilityDetector):
    """标准兼容性检测器实现"""
    
    def __init__(self, registry: CapabilityRegistry):
        self.registry = registry
    
    def detect(self, target_system: SystemType, target_info: Dict[str, Any]) -> CompatibilityResult:
        """执行标准兼容性检测"""
        target_caps = target_info.get("capabilities", [])
        target_version = VersionInfo.from_string(target_info.get("version", "1.0"))
        
        # 获取本地能力
        local_caps = self.registry.get_all()
        local_cap_ids = [cap.capability_id for cap in local_caps]
        
        # 计算匹配情况
        matched = set(local_cap_ids) & set(target_caps)
        missing = set(target_caps) - set(local_cap_ids)
        
        # 计算兼容分数
        score = self.calculate_score(local_cap_ids, target_caps)
        
        # 确定兼容级别
        if score >= 0.9:
            level = CompatibilityLevel.FULL
        elif score >= 0.6:
            level = CompatibilityLevel.PARTIAL
        elif score >= 0.3:
            level = CompatibilityLevel.LIMITED
        else:
            level = CompatibilityLevel.INCOMPATIBLE
        
        # 生成建议
        recommendations = self._generate_recommendations(level, missing, target_system)
        
        # 生成警告
        warnings = self._generate_warnings(score, missing, target_version)
        
        return CompatibilityResult(
            is_compatible=level != CompatibilityLevel.INCOMPATIBLE,
            level=level,
            score=score,
            matched_capabilities=list(matched),
            missing_capabilities=list(missing),
            incompatible_capabilities=[],
            recommendations=recommendations,
            warnings=warnings,
            metadata={
                "target_system": target_system.value,
                "target_version": target_info.get("version"),
                "local_capability_count": len(local_cap_ids),
                "target_capability_count": len(target_caps)
            }
        )
    
    def calculate_score(self, local_caps: List[str], target_caps: List[str]) -> float:
        """计算兼容分数"""
        if not target_caps:
            return 1.0
        
        matched = len(set(local_caps) & set(target_caps))
        return matched / len(target_caps)
    
    def _generate_recommendations(
        self,
        level: CompatibilityLevel,
        missing: Set[str],
        target: SystemType
    ) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if level == CompatibilityLevel.FULL:
            recommendations.append("系统完全兼容，可直接进行联动配置")
        elif level == CompatibilityLevel.PARTIAL:
            recommendations.append("建议升级以下能力模块以提高兼容性")
            for cap in list(missing)[:5]:
                recommendations.append(f"  - 实现能力: {cap}")
        elif level == CompatibilityLevel.LIMITED:
            recommendations.append("当前兼容性有限，需要进行能力扩展")
            recommendations.append("建议联系系统管理员进行能力升级")
        else:
            recommendations.append("系统不兼容，需要进行全面评估")
        
        return recommendations
    
    def _generate_warnings(
        self,
        score: float,
        missing: Set[str],
        target_version: VersionInfo
    ) -> List[str]:
        """生成警告"""
        warnings = []
        
        if score < 0.5:
            warnings.append("警告: 兼容性分数较低，联动可能不稳定")
        
        # 检查安全相关缺失
        security_caps = [c for c in missing if "security" in c.lower() or "auth" in c.lower()]
        if security_caps:
            warnings.append("警告: 存在安全相关能力缺失，可能影响系统安全")
        
        return warnings


class ProtocolHandler(ABC):
    """协议处理器抽象基类"""
    
    @abstractmethod
    def negotiate(self, request: NegotiationRequest) -> NegotiationResponse:
        """执行协议协商"""
        pass
    
    @abstractmethod
    def validate(self, message: Dict[str, Any]) -> bool:
        """验证消息格式"""
        pass


class StandardProtocolHandler(ProtocolHandler):
    """标准协议处理器实现"""
    
    def __init__(self, registry: CapabilityRegistry):
        self.registry = registry
        self._supported_versions = ["1.0", "2.0", "3.0"]
    
    def negotiate(self, request: NegotiationRequest) -> NegotiationResponse:
        """执行标准协议协商"""
        # 验证请求
        if not self.validate(request.__dict__):
            return NegotiationResponse(
                request_id=request.request_id,
                accepted=False,
                negotiated_version=None,
                agreed_capabilities=[],
                rejected_capabilities=request.required_capabilities,
                rejection_reasons={"validation": "请求格式验证失败"},
                security_requirements={}
            )
        
        # 确定协商版本
        negotiated_version = self._determine_version(request.local_version)
        
        # 确定达成的能力
        agreed = []
        rejected = []
        rejection_reasons = {}
        
        for cap_id in request.required_capabilities:
            capability = self.registry.get(cap_id)
            if capability:
                if not capability.deprecated:
                    agreed.append(cap_id)
                else:
                    rejected.append(cap_id)
                    rejection_reasons[cap_id] = "能力已弃用"
            else:
                # 检查可选能力是否可以作为备选
                if cap_id in request.optional_capabilities:
                    continue
                rejected.append(cap_id)
                rejection_reasons[cap_id] = "能力未注册"
        
        # 添加可选能力中可用的部分
        for cap_id in request.optional_capabilities:
            if cap_id not in agreed and cap_id not in rejected:
                if self.registry.get(cap_id):
                    agreed.append(cap_id)
        
        accepted = len(agreed) >= len(request.required_capabilities) * 0.5
        
        return NegotiationResponse(
            request_id=request.request_id,
            accepted=accepted,
            negotiated_version=negotiated_version,
            agreed_capabilities=agreed,
            rejected_capabilities=rejected,
            rejection_reasons=rejection_reasons,
            security_requirements=self._get_security_requirements(request.security_level),
            metadata={
                "negotiation_timestamp": datetime.now(timezone.utc).isoformat(),
                "original_version": str(request.local_version)
            }
        )
    
    def validate(self, message: Dict[str, Any]) -> bool:
        """验证消息格式"""
        required_fields = ["request_id", "system_type", "local_version"]
        for field in required_fields:
            if field not in message:
                return False
        return True
    
    def _determine_version(self, local_version: VersionInfo) -> VersionInfo:
        """确定协商版本"""
        # 选择本地版本和支持版本中的最小版本以确保兼容性
        local_str = str(local_version)
        major = local_version.major
        
        # 找到支持的版本
        for version_str in self._supported_versions:
            v = VersionInfo.from_string(version_str)
            if v.major == major:
                return v
        
        # 返回最新支持的版本
        return VersionInfo.from_string("3.0")
    
    def _get_security_requirements(self, level: int) -> Dict[str, Any]:
        """获取安全要求"""
        return {
            "minimum_tls_version": "1.2" if level >= 3 else "1.0",
            "require_encryption": level >= 2,
            "require_audit_log": level >= 4,
            "require_multifactor_auth": level >= 5,
            "encryption_algorithm": "AES-256-GCM" if level >= 4 else "AES-128-CBC"
        }


class CapabilityDiscoverer:
    """能力发现器"""
    
    def __init__(self, registry: CapabilityRegistry):
        self.registry = registry
    
    def discover(
        self,
        system_id: str,
        system_type: SystemType,
        advertised_info: Optional[Dict[str, Any]] = None
    ) -> CapabilityDiscoveryResult:
        """执行能力发现"""
        # 如果没有提供广告信息，则返回本地能力
        if not advertised_info:
            capabilities = self.registry.get_all()
            return CapabilityDiscoveryResult(
                system_id=system_id,
                system_type=system_type,
                capabilities=capabilities,
                supported_protocols=["1.0", "2.0", "3.0"],
                security_level=3,
                performance_metrics=self._get_local_metrics()
            )
        
        # 发现目标系统的能力
        capabilities = []
        for cap_data in advertised_info.get("capabilities", []):
            cap = CapabilityInfo(
                capability_id=cap_data.get("id", ""),
                name=cap_data.get("name", ""),
                category=CapabilityCategory(cap_data.get("category", "security")),
                version=cap_data.get("version", "1.0"),
                description=cap_data.get("description", ""),
                parameters=cap_data.get("parameters", {}),
                dependencies=cap_data.get("dependencies", [])
            )
            capabilities.append(cap)
        
        return CapabilityDiscoveryResult(
            system_id=system_id,
            system_type=system_type,
            capabilities=capabilities,
            supported_protocols=advertised_info.get("protocols", ["1.0"]),
            security_level=advertised_info.get("security_level", 3),
            performance_metrics=advertised_info.get("metrics", {}),
            last_updated=advertised_info.get("last_updated", datetime.now(timezone.utc).isoformat())
        )
    
    def _get_local_metrics(self) -> Dict[str, Any]:
        """获取本地性能指标"""
        return {
            "response_time_ms": 50,
            "throughput_rps": 1000,
            "error_rate": 0.001,
            "uptime_percentage": 99.9
        }


class CompatibilityInterface:
    """
    兼容与联动接口主类
    提供统一的兼容性检测、联动协议、版本协商和能力发现接口
    """
    
    def __init__(self):
        self.registry = CapabilityRegistry()
        self.detector = StandardCompatibilityDetector(self.registry)
        self.protocol_handler = StandardProtocolHandler(self.registry)
        self.discoverer = CapabilityDiscoverer(self.registry)
        self._lock = threading.RLock()
        self._connected_systems: Dict[str, Dict[str, Any]] = {}
        self._negotiation_history: List[NegotiationResponse] = []
        
        # 初始化默认能力
        self._initialize_default_capabilities()
    
    def _initialize_default_capabilities(self):
        """初始化默认能力"""
        default_capabilities = [
            CapabilityInfo(
                capability_id="mail.security.scan",
                name="邮件安全扫描",
                category=CapabilityCategory.SECURITY,
                version="3.0",
                description="对入站和出站邮件进行安全扫描",
                parameters={"scan_types": ["virus", "malware", "phishing"]}
            ),
            CapabilityInfo(
                capability_id="mail.security.filter",
                name="邮件安全过滤",
                category=CapabilityCategory.SECURITY,
                version="3.0",
                description="基于规则和AI的内容过滤"
            ),
            CapabilityInfo(
                capability_id="mail.data.classify",
                name="邮件数据分类",
                category=CapabilityCategory.DATA,
                version="3.0",
                description="自动分类和标注邮件内容"
            ),
            CapabilityInfo(
                capability_id="mail.event.notify",
                name="邮件事件通知",
                category=CapabilityCategory.EVENT,
                version="3.0",
                description="实时邮件事件通知"
            ),
            CapabilityInfo(
                capability_id="mail.decision.auto",
                name="自动决策引擎",
                category=CapabilityCategory.DECISION,
                version="3.0",
                description="基于规则的自动决策"
            ),
            CapabilityInfo(
                capability_id="mail.monitoring.stats",
                name="监控统计",
                category=CapabilityCategory.MONITORING,
                version="3.0",
                description="邮件系统监控和统计"
            )
        ]
        
        for cap in default_capabilities:
            self.registry.register(cap)
    
    def register_capability(self, capability: CapabilityInfo) -> bool:
        """注册新能力"""
        return self.registry.register(capability)
    
    def unregister_capability(self, capability_id: str) -> bool:
        """注销能力"""
        return self.registry.unregister(capability_id)
    
    def check_compatibility(
        self,
        target_system: SystemType,
        target_info: Dict[str, Any]
    ) -> CompatibilityResult:
        """
        检查与目标系统的兼容性
        
        Args:
            target_system: 目标系统类型
            target_info: 目标系统信息，包含capabilities、version等
        
        Returns:
            CompatibilityResult: 兼容性检测结果
        """
        with self._lock:
            logger.info(f"检查与 {target_system.value} 的兼容性")
            result = self.detector.detect(target_system, target_info)
            logger.info(f"兼容性检测完成: {result.level.value} (分数: {result.score:.2f})")
            return result
    
    def negotiate_protocol(
        self,
        target_system: SystemType,
        version: VersionInfo,
        required_caps: List[str],
        optional_caps: Optional[List[str]] = None
    ) -> NegotiationResponse:
        """
        与目标系统协商协议版本和能力
        
        Args:
            target_system: 目标系统类型
            version: 本地版本
            required_caps: 必需的能力列表
            optional_caps: 可选的能力列表
        
        Returns:
            NegotiationResponse: 协商结果
        """
        with self._lock:
            request_id = str(uuid.uuid4())
            
            request = NegotiationRequest(
                request_id=request_id,
                system_type=target_system,
                local_version=version,
                required_capabilities=required_caps,
                optional_capabilities=optional_caps or [],
                security_level=3
            )
            
            logger.info(f"发起协议协商: {request_id}")
            response = self.protocol_handler.negotiate(request)
            
            self._negotiation_history.append(response)
            
            if response.accepted:
                logger.info(f"协议协商成功: {request_id}, 版本: {response.negotiated_version}")
            else:
                logger.warning(f"协议协商失败: {request_id}")
            
            return response
    
    def discover_capabilities(
        self,
        system_id: str,
        system_type: SystemType,
        advertised_info: Optional[Dict[str, Any]] = None
    ) -> CapabilityDiscoveryResult:
        """
        发现系统能力
        
        Args:
            system_id: 系统标识
            system_type: 系统类型
            advertised_info: 广告的能力信息
        
        Returns:
            CapabilityDiscoveryResult: 能力发现结果
        """
        with self._lock:
            return self.discoverer.discover(system_id, system_type, advertised_info)
    
    def get_system_info(self, system_id: str) -> Optional[Dict[str, Any]]:
        """获取已连接系统的信息"""
        with self._lock:
            return self._connected_systems.get(system_id)
    
    def register_system(self, system_id: str, info: Dict[str, Any]):
        """注册已连接的系统"""
        with self._lock:
            self._connected_systems[system_id] = {
                **info,
                "registered_at": datetime.now(timezone.utc).isoformat()
            }
            logger.info(f"已注册系统: {system_id}")
    
    def unregister_system(self, system_id: str) -> bool:
        """注销系统"""
        with self._lock:
            if system_id in self._connected_systems:
                del self._connected_systems[system_id]
                logger.info(f"已注销系统: {system_id}")
                return True
            return False
    
    def get_connected_systems(self) -> List[Dict[str, Any]]:
        """获取所有已连接系统"""
        with self._lock:
            return list(self._connected_systems.values())
    
    def get_negotiation_history(self) -> List[NegotiationResponse]:
        """获取协商历史"""
        with self._lock:
            return list(self._negotiation_history)
    
    def get_capabilities(self, category: Optional[CapabilityCategory] = None) -> List[CapabilityInfo]:
        """获取能力列表"""
        if category:
            return self.registry.get_by_category(category)
        return self.registry.get_all()
    
    def export_capabilities(self) -> Dict[str, Any]:
        """导出能力清单"""
        capabilities = self.registry.get_all()
        return {
            "total_count": len(capabilities),
            "capabilities": [
                {
                    "id": cap.capability_id,
                    "name": cap.name,
                    "category": cap.category.value,
                    "version": cap.version,
                    "deprecated": cap.deprecated
                }
                for cap in capabilities
            ],
            "exported_at": datetime.now(timezone.utc).isoformat()
        }
    
    def generate_report(self) -> Dict[str, Any]:
        """生成兼容性报告"""
        connected = self.get_connected_systems()
        capabilities = self.export_capabilities()
        
        return {
            "report_type": "compatibility_interface_report",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "registered_systems_count": len(connected),
            "registered_systems": [
                {"system_id": sys.get("system_id"), "type": sys.get("type")}
                for sys in connected
            ],
            "capabilities_summary": {
                "total": capabilities["total_count"],
                "by_category": self._count_by_category()
            },
            "negotiation_history_count": len(self._negotiation_history)
        }
    
    def _count_by_category(self) -> Dict[str, int]:
        """按类别统计能力数量"""
        counts = {}
        for cat in CapabilityCategory:
            caps = self.registry.get_by_category(cat)
            counts[cat.value] = len(caps)
        return counts


# 全局兼容接口实例
_compatibility_interface_instance: Optional[CompatibilityInterface] = None


def get_compatibility_interface() -> CompatibilityInterface:
    """获取全局兼容接口实例"""
    global _compatibility_interface_instance
    if _compatibility_interface_instance is None:
        _compatibility_interface_instance = CompatibilityInterface()
    return _compatibility_interface_instance


# 合规声明
__compliance_info__ = {
    "module": "compatibility_interface",
    "version": "3.0.0",
    "data_processing": "本地处理，无外部网络请求",
    "security_compliance": [
        "网络安全法第二十一条：采取数据分类、重要数据备份和加密等措施",
        "数据安全法第二十七条：开展数据处理活动应当依照法律、法规的规定",
        "个人信息保护法第五十一条：采取加密、去标识化等安全技术措施"
    ],
    "audit_info": {
        "log_retention_days": 180,
        "audit_level": "full",
        "encryption_required": True
    }
}


if __name__ == "__main__":
    # 示例用法
    interface = get_compatibility_interface()
    
    # 注册系统
    interface.register_system("security-engine-01", {
        "system_id": "security-engine-01",
        "type": "security_engine",
        "version": "3.0",
        "capabilities": ["mail.security.scan", "mail.security.filter"]
    })
    
    # 检查兼容性
    result = interface.check_compatibility(
        SystemType.SECURITY_ENGINE,
        {
            "version": "3.0",
            "capabilities": ["mail.security.scan", "mail.security.filter", "mail.security.encrypt"]
        }
    )
    
    print(f"兼容性级别: {result.level.value}")
    print(f"兼容分数: {result.score:.2f}")
    print(f"匹配的能力: {result.matched_capabilities}")
    print(f"缺失的能力: {result.missing_capabilities}")
    
    # 协商协议
    negotiation = interface.negotiate_protocol(
        SystemType.SECURITY_ENGINE,
        VersionInfo(major=3, minor=0, patch=0),
        required_caps=["mail.security.scan"],
        optional_caps=["mail.security.filter"]
    )
    
    print(f"协商成功: {negotiation.accepted}")
    print(f"协商版本: {negotiation.negotiated_version}")
    print(f"达成的能力: {negotiation.agreed_capabilities}")
