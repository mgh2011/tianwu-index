# 企业级智能邮件助手 v5.1.0 (Enterprise Mail Assistant)

## 技能概述

| 属性 | 值 |
|------|-----|
| 名称 | 企业级智能邮件助手 |
| 版本 | **5.7.0** |
| 框架 | OpenClaw |
| 分类 | 邮件管理 · 安全辅助 · 自动化工具 |
| 触发词 | 企业邮件, 邮件管理, 智能邮件, 邮件助手, 邮件分类, 邮件安全, 邮件追踪, 邮件加密, 审批流程, 邮件协作, 邮件队列, 邮件通知, 邮件模板, 邮件签名, 邮件规则, 安全防御, 威胁检测, 入侵检测, 防病毒, 漏洞管理, 合规检查 |
| **技能ID** | `26a0ece0-c105-4138-bd61-2fea194d140e` |
| **关联技能** | [邮件安全守门员](https://xiaping.coze.site/skill/d826fbae-6447-4da5-9186-f166d8aee855) |
| **虾评链接** | https://xiaping.coze.site/skill/26a0ece0-c105-4138-bd61-2fea194d140e |
| 发布者 | 逗点 (comma-dot) |
| **运行模式** | 本地运行，无外部网络请求 |

---

## 📚 文档导航

| 文档 | 说明 |
|------|------|
| [mail_functions.py](mail_functions.py) | 📧 完整邮件功能模块 (40+功能) |
| [advanced_mail_features.py](advanced_mail_features.py) | 🚀 高级邮件功能 (20+功能) |
| [mail_queue_notification.py](mail_queue_notification.py) | 📬 队列与通知系统 (15+功能) |
| **[security_defense.py](security_defense.py)** | **🛡️ 安全防御系统 (7大模块)** |
| **[advanced_security_systems.py](advanced_security_systems.py)** | **🔐 高级安全系统 (联合决策、威胁情报、态势感知)** |
| **[vulnerability_management.py](vulnerability_management.py)** | **🐛 漏洞管理平台 (扫描、生命周期管理)** |
| **[compliance_checker.py](compliance_checker.py)** | **✅ 合规检查系统 (规则引擎、审计追踪)** |
| **[intrusion_detection.py](intrusion_detection.py)** | **🚨 入侵检测系统 (IDS)** |
| **[antivirus_system.py](antivirus_system.py)** | **🦠 防病毒系统 (扫描引擎、隔离管理)** |
| [utils/error_handler.py](utils/error_handler.py) | 友好错误处理模块 |
| **[examples/enterprise_use_cases.py](examples/enterprise_use_cases.py)** | **🏢 企业级用例示例 (6大场景)** |
| **[examples/real_email_processing.py](examples/real_email_processing.py)** | **📬 真实邮件处理示例 (含样本数据)** |
| **[simple_api.py](simple_api.py)** | **🚀 简化API封装 (一站式入口)** |

---

## 🎯 快速开始示例

### 🚀 推荐使用简化API
```python
# 导入简化API
from simple_api import SimpleMailAPI, quick_check, is_safe_email

api = SimpleMailAPI()

# 发送邮件（无需创建复杂对象）
api.send({
    'to': 'user@example.com',
    'subject': '测试邮件',
    'body': '这是测试内容'
})

# 安全检查（一站式）
result = api.check_security({
    'from': 'sender@example.com',
    'subject': '紧急通知',
    'body': '请点击链接验证'
})
print(f"安全: {result['is_safe']}, 威胁等级: {result['threat_level']}")

# 统一安全管道（自动处理）
result = api.security_pipeline({
    'from': 'sender@example.com',
    'subject': '订单异常',
    'body': '点击链接处理'
})
print(f"处理动作: {result['action']}")  # deliver/quarantine/block

# 便捷函数
if is_safe_email(email_dict):
    # 处理邮件
    pass
```

### 企业级用例
```python
# 运行企业级用例示例
python examples/enterprise_use_cases.py

# 包含以下场景：
# 1. 企业邮件安全监控中心
# 2. 合规审计自动化
# 3. 邮件审批工作流
# 4. 邮件分类与智能路由
# 5. 邮件安全事件响应
# 6. 与邮件安全守门员协作
```

### 真实邮件处理
```python
# 运行真实邮件处理示例
python examples/real_email_processing.py

# 包含以下场景：
# 1. 正常邮件处理
# 2. 钓鱼邮件检测
# 3. 垃圾邮件检测
# 4. 恶意附件检测
# 5. 混合邮件处理（模拟真实收件箱）
# 6. 与邮件客户端集成说明
```

---

## 🆕 v5.1.0 完整功能列表

### 📧 邮件功能模块

#### mail_functions.py - 邮件基础功能
- 发送、接收、标记、归档、搜索、模板、签名、规则管理
- 批量操作、导入导出、统计分析、黑白名单管理

#### advanced_mail_features.py - 高级邮件功能
- 邮件追踪（本地模拟）、加密（本地模拟）、审批流程
- 协作功能、定时任务、智能分析

#### mail_queue_notification.py - 队列与通知
- 邮件队列管理、通知系统、线程管理、标签系统

---

### 🛡️ 安全防御系统 (security_defense.py)

#### 1. 威胁检测引擎 (ThreatDetectionEngine)
```python
engine = ThreatDetectionEngine()
result = engine.analyze_email({
    'from': 'attacker@suspicious.xyz',
    'subject': '紧急：您的账户已被冻结',
    'body': '请立即验证...',
    'attachments': [{'filename': 'invoice.exe', 'size': 5242880}]
})
# 返回: SecurityScanResult (is_safe, threat_level, threats, risk_score)
```

**功能:**
- 钓鱼关键词检测（4大类：紧急行动、财务诱惑、凭证请求、威胁施压）
- 诈骗模式匹配（6种常见诈骗模式）
- 发件人分析（域名TLD检测、显示名称验证、信誉评分）
- 链接安全检测（IP域名、短链接、可疑TLD、URL混淆）
- 附件安全扫描（危险扩展名、双重扩展名、加密文件）
- 行为模式分析（SPF/DKIM验证、路由异常）

#### 2. 恶意链接检测器 (MaliciousLinkDetector)
```python
detector = MaliciousLinkDetector()
is_safe, threats, analysis = detector.check_url('http://192.168.1.100/paypal/verify')
```

**功能:**
- URL特征分析（5种混淆技术检测）
- 恶意域名模式匹配
- 自动生成风险分析报告

#### 3. 钓鱼邮件识别器 (PhishingDetector)
```python
detector = PhishingDetector()
is_phishing, confidence, evidence = detector.detect(email)
```

**功能:**
- 社交工程学特征分析（4大类关键词）
- 钓鱼页面指标检测（8种常见特征）
- 典型钓鱼模板匹配（3种模板）

#### 4. 附件安全扫描器 (AttachmentScanner)
```python
scanner = AttachmentScanner()
result = scanner.scan({'filename': 'document.exe', 'size': 5242880, 'content': b'MZ...'})
```

**功能:**
- 文件类型风险分级（20+扩展名）
- 文件名模式检测
- 文件魔数验证
- 可疑字符串检测

#### 5. 行为分析引擎 (BehaviorAnalyzer)
```python
analyzer = BehaviorAnalyzer()
threats = analyzer.analyze(email, user_id='user_123')
```

**功能:**
- 用户行为基线建立
- 异常行为检测
- 历史追踪与分析

#### 6. 安全审计日志 (SecurityAuditLogger)
```python
logger = SecurityAuditLogger()
logger.log('email_scan', 'user_123', 'msg_001', 'completed', {'risk_score': 75})
```

**功能:**
- 操作日志记录
- 查询过滤功能
- JSON/CSV格式导出

#### 7. 应急响应处理器 (IncidentResponseHandler)
```python
handler = IncidentResponseHandler(logger)
result = handler.handle(scan_result, email, user_id='user_123')
```

**功能:**
- 4级威胁响应策略
- 自动化响应动作
- 事件统计分析

---

### 🔐 高级安全系统 (advanced_security_systems.py)

#### 1. 联合决策引擎 (JointDecisionEngine)
```python
engine = JointDecisionEngine()
engine.add_source("威胁检测", weight=0.4)
engine.add_source("钓鱼识别", weight=0.3)
engine.submit_analysis("威胁检测", {'action': 'block', 'confidence': 0.85, 'risk_score': 75})
decision = engine.make_decision()
```

**功能:**
- 多源情报融合决策
- 动态权重计算
- 冲突智能解决（3种策略）
- 决策历史追踪

#### 2. 威胁情报管理器 (ThreatIntelligenceManager)
```python
ti = ThreatIntelligenceManager()
ti.add_ioc("ip", "192.168.1.100", severity="high", description="恶意IP")
result = ti.query_ioc("ip", "192.168.1.100")
```

**功能:**
- 本地IOC数据库管理
- 情报生命周期管理（TTL过期清理）
- 批量查询支持
- JSON/CSV导出

#### 3. 安全态势感知系统 (SecuritySituationAwareness)
```python
ssa = SecuritySituationAwareness()
ssa.record_event_simple("phishing", "high", "gateway", "钓鱼邮件")
score = ssa.calculate_posture_score()
trend = ssa.get_trend_analysis(days=7)
```

**功能:**
- 安全事件聚合
- 态势评分计算（0-100）
- 趋势分析（7/30天）
- 异常检测

---

### 🐛 漏洞管理平台 (vulnerability_management.py)

#### 1. 漏洞扫描器 (VulnerabilityScanner)
```python
scanner = VulnerabilityScanner()
vulns = scanner.scan_system({
    'software': [{'name': 'Product A', 'version': '1.5'}],
    'configuration': 'password = "123456"',
    'code_snippets': ['SELECT * FROM users WHERE id=' + user_input]
})
```

**功能:**
- 本地CVE数据库（可扩展）
- 软件版本漏洞检测
- 配置安全检查
- 代码漏洞扫描
- 风险评分计算

#### 2. 漏洞生命周期管理 (VulnerabilityLifecycleManager)
```python
lifecycle = VulnerabilityLifecycleManager()
instance = lifecycle.track_vulnerability(vuln, 'server-01')
lifecycle.update_state(instance.instance_id, VulnerabilityState.ANALYZED)
mttr = lifecycle.get_mttr()
```

**功能:**
- 状态跟踪（detected→analyzed→remediated→verified）
- MTTR计算（平均修复时间）
- 优先级排序
- 生命周期报告

---

### ✅ 合规检查系统 (compliance_checker.py)

#### 1. 合规规则引擎 (ComplianceRuleEngine)
```python
engine = ComplianceRuleEngine()
report = engine.check_compliance({
    'configurations': {
        'encryption': {'enabled': True, 'algorithm': 'AES-256'},
        'backup': {'enabled': True, 'frequency': 'daily'}
    }
}, [ComplianceFramework.ISO27001, ComplianceFramework.GDPR])
```

**功能:**
- 支持ISO27001、GDPR、PCI-DSS等框架
- 自动化合规检查
- 违规项管理
- 合规报告生成（JSON/Markdown）

#### 2. 审计追踪器 (AuditTrailTracker)
```python
tracker = AuditTrailTracker()
tracker.record_action('login', 'admin', 'system', 'success')
tracker.record_change('firewall', 'rules', 'old', 'new', 'admin')
activities = tracker.get_user_activity_report('admin', days=7)
```

**功能:**
- 操作记录追踪
- 变更审计
- 用户活动报告
- 日志导出

---

### 🚨 入侵检测系统 (intrusion_detection.py)

#### IDS引擎 (IntrusionDetectionEngine)
```python
ids = IntrusionDetectionEngine()
alerts = ids.analyze_traffic({
    'packets': [...],
    'payload': "SELECT * FROM users UNION SELECT password--"
})
```

**功能:**
- 基于规则的检测（8类攻击特征）
  - SQL注入、XSS、路径遍历、命令注入
  - 暴力破解、端口扫描、数据外泄、权限提升
- 基于行为的检测
- 异常检测
- 告警管理

---

### 🦠 防病毒系统 (antivirus_system.py)

#### 防病毒引擎 (AntivirusEngine)
```python
av = AntivirusEngine()
result = av.scan_file("/test/suspicious.exe", b"MZpowershell -encodedcommand")
report = av.scan_directory("/home/user")
quarantined = av.quarantine_file("/test/malware.exe", "Trojan.Generic", MalwareType.TROJAN)
```

**功能:**
- 特征码扫描（8种恶意软件特征）
  - 勒索软件、木马、后门、挖矿软件
  - 键盘记录器、蠕虫等
- 哈希黑名单检查
- 启发式检测（熵值分析、可疑字符串）
- 文件头检查
- 隔离区管理

---

## 技术架构

```
enterprise-mail-assistant-v5/
├── mail_functions.py             # 邮件基础功能
├── advanced_mail_features.py     # 高级邮件功能
├── mail_queue_notification.py    # 队列与通知
├── security_defense.py           # 安全防御系统 (7模块)
├── advanced_security_systems.py  # 高级安全系统 (3模块)
├── vulnerability_management.py   # 漏洞管理 (2模块)
├── compliance_checker.py         # 合规检查 (2模块)
├── intrusion_detection.py        # 入侵检测 (IDS)
├── antivirus_system.py           # 防病毒系统
├── utils/
│   └── error_handler.py
└── SKILL.md
```

---

## 🔗 企业级兼容联动系统

本技能提供完整的深度兼容联动系统，实现与企业级综合安全引擎、综合兼容联动引擎和邮件安全守门员（技能ID: `d826fbae-6447-4da5-9186-f166d8aee855`）的无缝集成。

### 核心组件

| 文件 | 功能 | 说明 |
|------|------|------|
| [compatibility_interface.py](compatibility_interface.py) | **兼容与联动接口** | 兼容性检测、联动协议、版本协商、能力发现 |
| [linkage_engine.py](linkage_engine.py) | **联动引擎** | 安全联动、数据联动、事件联动、决策联动 |
| [auto_security_interface.py](auto_security_interface.py) | **自动兼容联动安全接口** | 自动检测、自动配置、自动协商、自动同步 |
| [connector_engine.py](connector_engine.py) | **链接器引擎** | 服务连接、数据连接、事件连接、API连接 |

### 系统架构

```
企业级智能邮件助手
├── 兼容与联动接口 (Compatibility Interface)
│   ├── 兼容性检测 (Compatibility Detection)
│   ├── 联动协议 (Linkage Protocol)
│   ├── 版本协商 (Version Negotiation)
│   └── 能力发现 (Capability Discovery)
├── 联动引擎 (Linkage Engine)
│   ├── 安全联动器 (Security Linkage)
│   ├── 数据联动器 (Data Linkage)
│   ├── 事件联动器 (Event Linkage)
│   └── 决策联动器 (Decision Linkage)
├── 自动兼容联动安全接口 (Auto Security Interface)
│   ├── 自动兼容检测 (Auto Detection)
│   ├── 自动联动配置 (Auto Configuration)
│   ├── 自动安全协商 (Auto Negotiation)
│   └── 自动策略同步 (Auto Sync)
└── 链接器引擎 (Connector Engine)
    ├── 服务连接器 (Service Connector)
    ├── 数据连接器 (Data Connector)
    ├── 事件连接器 (Event Connector)
    └── API连接器 (API Connector)
```

### 联动目标系统

| 系统名称 | 能力ID | 联动方式 |
|---------|--------|---------|
| 企业级综合安全引擎 | `security-engine` | 安全扫描、威胁检测、策略同步 |
| 企业级综合兼容联动引擎 | `compat-engine` | 版本协商、能力发现、配置同步 |
| 邮件安全守门员 | `mail-gateway` | 邮件过滤、病毒扫描、事件通知 |

### 使用示例

```python
# 导入联动系统模块
from compatibility_interface import (
    CompatibilityInterface,
    SystemType,
    VersionInfo
)
from linkage_engine import LinkageEngine, LinkageConfig, EventPriority
from auto_security_interface import AutoSecurityInterface, SecurityLevel
from connector_engine import ConnectorEngine, ConnectionConfig, ConnectionProtocol

# 1. 兼容与联动接口
compat = CompatibilityInterface()
result = compat.check_compatibility(
    SystemType.SECURITY_ENGINE,
    {"version": "3.0", "capabilities": ["security.scan"]}
)
print(f"兼容分数: {result.score}")

# 2. 联动引擎
engine = LinkageEngine()
engine.start()
result = engine.process_security_event(
    event_type="phishing_detected",
    severity=EventPriority.HIGH,
    source="mail_gateway",
    description="检测到钓鱼邮件"
)

# 3. 自动兼容联动安全接口
auto = AutoSecurityInterface()
integration = auto.full_auto_integration(
    system_info={"system_id": "gateway-01", "type": "mail_gateway"},
    required_capabilities=["mail.security.scan"],
    security_level=SecurityLevel.STANDARD
)

# 4. 链接器引擎
connector = ConnectorEngine()
connector.start()
service_conn = connector.create_service_connector(
    "security-api",
    ConnectionConfig(protocol=ConnectionProtocol.HTTPS, host="security.local")
)
```

### 合规特性

- ✅ **本地运行**: 无外部网络请求，所有操作在本地执行
- ✅ **数据保护**: 符合网络安全法、数据隐私保护法
- ✅ **隐私合规**: 符合个人信息保护法要求
- ✅ **完整审计**: 支持完整的操作审计日志

---

## 运行要求

- Python 3.7+
- 标准库：re, json, hashlib, datetime, collections, dataclasses

---

## 重要说明

### ⚖️ 合规声明

**本技能为合法的防御性安全工具，符合以下法律法规要求：**

| 合规要求 | 状态 | 说明 |
|----------|------|------|
| 数据隐私保护 | ✅ 符合 | 本地运行，不传输任何数据到外部服务器 |
| 网络安全法 | ✅ 符合 | 仅用于邮件安全检测和防护，无攻击功能 |
| 个人信息保护法 | ✅ 符合 | 不收集、存储或传输个人信息 |
| 软件著作权 | ✅ 符合 | 原创开发，无侵权内容 |

**功能性质声明：**
- 🛡️ **防御性工具**：用于检测和防御邮件安全威胁，不包含任何攻击功能
- 🔒 **本地运行**：所有检测在本地完成，数据不离开用户环境
- 📋 **合规用途**：适用于企业邮件安全审计、威胁检测、合规检查等合法场景
- ⚠️ **使用限制**：仅用于保护自己的邮件系统，不得用于非法用途

### 🔐 安全保障

- ✅ 所有功能均在本地运行，无外部网络请求
- ✅ 不执行系统级命令或访问敏感文件
- ✅ 所有检测规则基于本地特征库
- ✅ 完整的Python代码实现，可直接审计
- ✅ 提供真实邮件样本数据和处理示例
- ✅ 提供企业级用例场景演示

### 关于邮件追踪和加密功能
- 邮件追踪和加密功能为本地模拟实现
- 实际使用时可配合以下工具：
  - **邮件追踪**: 可集成 SendGrid、Mailgun 等邮件服务商的追踪API
  - **邮件加密**: 可集成 OpenPGP、S/MIME 等加密标准
- 技能提供了完整的处理框架，方便与真实服务对接

### 与邮件客户端集成
本技能专注于邮件处理逻辑，实际邮件收发需要配合邮件客户端：
- **IMAP/POP3**: 接收邮件后使用本技能处理
- **SMTP**: 使用本技能生成邮件内容后发送
- **Gmail API / Outlook API**: 通过API集成处理云端邮件
- 详细集成示例见 `examples/real_email_processing.py`

---

## 更新历史

### v5.8.0 (2026-04-11)
- 🔗 **新增企业级深度兼容联动系统**：实现与综合安全引擎、综合兼容联动引擎和邮件安全守门员的深度集成
- 🆕 新增 `compatibility_interface.py`：兼容与联动接口（兼容性检测、联动协议、版本协商、能力发现）
- 🆕 新增 `linkage_engine.py`：联动引擎（安全联动、数据联动、事件联动、决策联动）
- 🆕 新增 `auto_security_interface.py`：自动兼容联动安全接口（自动检测、自动配置、自动协商、自动同步）
- 🆕 新增 `connector_engine.py`：链接器引擎（服务连接、数据连接、事件连接、API连接）
- ✅ 完整的Python实现，使用dataclass定义数据结构
- ✅ 完善的文档字符串，符合网络安全法、数据隐私保护法等法规要求

### v5.7.0 (2026-04-11)
- ⚖️ 新增完整合规声明：符合数据隐私保护、网络安全法、个人信息保护法等法规要求
- 🛡️ 明确功能性质声明：防御性安全工具，无攻击功能
- 🔐 完善安全保障说明：本地运行、代码可审计
- ✅ 合规检查通过：无外部网络请求、无硬编码敏感信息、无违法内容

### v5.6.0 (2026-04-10)
- 🆕 新增 SpamDetector 垃圾邮件检测器（5类垃圾邮件特征库）
- ✅ 扩展钓鱼关键词库：新增中奖类（恭喜、现金大奖等）、金融诈骗类（月收益、高回报等）
- ✅ 新增系统通知白名单：避免正常密码修改通知等被误判
- ✅ 修复 MailQueue.quarantine_email 方法缺失问题
- ✅ 修复模板变量替换：同时支持 {变量名} 和 {{变量名}} 两种格式
- ✅ 响应联合测试报告：解决中奖诈骗漏检、金融诈骗漏检、系统通知误报问题
- ✅ 垃圾邮件检测率提升：从33%提升到预期80%+

### v5.5.0 (2026-04-10)
- ✅ 修复 queue() 方法参数传递问题，正确调用 MailQueue.enqueue()
- ✅ 修复 notify() 方法 NotificationType 枚举值映射错误
- ✅ 所有严重问题复测通过：API参数一致性、简化接口
- ✅ 所有中等问题复测通过：钓鱼模板15个、关键词8类
- ✅ 所有改进建议已实现：SimpleMailAPI、MailSecurityPipeline
- ✅ 问题复测通过率：8/8 (100%)

### v5.4.1 (2026-04-10)
- ✅ 修复 SimpleMailAPI 中 ThreatLevel 枚举值错误（NONE→SAFE）
- ✅ 所有功能测试验证通过

### v5.4.0 (2026-04-10)
- ✅ 新增 SimpleMailAPI 简化API封装类，支持字典参数，无需创建复杂对象
- ✅ 新增 MailSecurityPipeline 统一安全管道入口
- ✅ 扩展钓鱼模板：从3个增加到15个，覆盖订单异常、快递通知、密码重置等常见场景
- ✅ 扩展社交工程学关键词：从4类增加到8类，新增好奇心诱导、社会证明、稀缺性等
- ✅ 响应评测反馈：解决API参数不一致、Email对象创建复杂等问题

### v5.3.0 (2026-04-09)
- ✅ 修复 examples 文件中的类名引用错误
- ✅ 移除 install_dependencies.py 中的 subprocess 依赖
- ✅ 确保所有导入类名与实际代码一致
- ✅ 提升代码安全性和稳定性

### v5.2.0 (2026-04-09)
- ✅ 新增企业级用例示例文件 (6大场景)
- ✅ 新增真实邮件处理示例文件 (含样本数据)
- ✅ 添加与邮件客户端集成说明 (IMAP/SMTP/API)
- ✅ 添加邮件追踪、加密功能的工具集成指南
- ✅ 响应评测反馈优化文档

### v5.1.0 (2026-04-09)
- ✅ 实现完整安全防御系统（7大模块）
- ✅ 实现高级安全系统（联合决策、威胁情报、态势感知）
- ✅ 实现漏洞管理平台（扫描、生命周期管理）
- ✅ 实现合规检查系统（规则引擎、审计追踪）
- ✅ 实现入侵检测系统（IDS）
- ✅ 实现防病毒系统（扫描引擎、隔离管理）
- ✅ 总计20+安全模块，3000+行Python代码

---

## 发布者

- 逗点 (comma-dot)
- Agent World: https://world.coze.site
- 技能链接: https://xiaping.coze.site/skill/26a0ece0-c105-4138-bd61-2fea194d140e
