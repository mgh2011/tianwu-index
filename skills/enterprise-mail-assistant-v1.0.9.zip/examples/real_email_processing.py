"""
企业级智能邮件助手 - 真实邮件处理示例
Enterprise Mail Assistant - Real Email Processing Examples

本文件展示如何处理各种真实邮件场景，包括钓鱼邮件识别、正常邮件处理等。
所有示例均可在本地运行，无需连接真实邮件服务器。
"""

from datetime import datetime
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import json
import re

# 导入技能模块
from security_defense import (
    ThreatDetectionEngine, 
    PhishingDetector, 
    MaliciousLinkDetector,
    AttachmentScanner,
    BehaviorAnalyzer,
    ThreatLevel
)
from mail_functions import MailCore, Email, EmailAddress


# ============================================================
# 真实邮件样本数据集
# ============================================================

REAL_EMAIL_SAMPLES = {
    # 正常邮件样本
    "normal": [
        {
            "id": "normal_001",
            "from": "hr@company.com",
            "to": "employee@company.com",
            "subject": "2024年度休假安排通知",
            "body": """
各位同事：

公司2024年度休假安排如下：
- 春节假期：2月10日-2月17日
- 国庆假期：10月1日-10月7日

请各部门提前做好工作安排。

人事部
2024年1月15日
""",
            "attachments": [{"filename": "休假安排.pdf", "size": 102400}],
            "category": "正常内部通知"
        },
        {
            "id": "normal_002",
            "from": "supplier@trusted-partner.com",
            "to": "procurement@company.com",
            "subject": "订单PO-2024-0056发货确认",
            "body": """
尊敬的客户：

您的订单PO-2024-0056已于今日发货。
物流单号：SF1234567890
预计送达时间：3-5个工作日

如有问题请联系客服。

顺祝商祺
供应商A
""",
            "attachments": [{"filename": "发货单.pdf", "size": 51200}],
            "category": "正常商务邮件"
        },
        {
            "id": "normal_003",
            "from": "newsletter@tech-blog.com",
            "to": "subscriber@email.com",
            "subject": "本周技术周报：AI新动态",
            "body": """
本周热门文章：

1. GPT-5发布在即，有哪些值得期待的新功能？
2. 如何在项目中有效使用AI辅助开发
3. 开源大模型对比：Llama 3 vs Mistral

点击阅读更多内容...
""",
            "attachments": [],
            "category": "正常订阅邮件"
        }
    ],
    
    # 钓鱼邮件样本
    "phishing": [
        {
            "id": "phishing_001",
            "from": "security@bank0famerica.com",  # 注意：bank0f 中的0代替了o
            "to": "victim@email.com",
            "subject": "【紧急】您的账户存在异常活动",
            "body": """
尊敬的客户：

我们检测到您的账户存在异常登录活动。
IP地址：192.168.1.100
时间：2024-01-15 03:45:22

为保护您的账户安全，请立即验证您的身份：
http://bank0famerica-verify.xyz/confirm

如果在24小时内未验证，您的账户将被永久冻结。

美国银行安全团队
""",
            "attachments": [],
            "category": "银行钓鱼",
            "threat_indicators": [
                "伪造域名 (bank0famerica)",
                "紧急行动要求",
                "可疑链接 (.xyz域名)",
                "威胁性语言"
            ]
        },
        {
            "id": "phishing_002",
            "from": "ceo@company-similiar.com",
            "to": "finance@company.com",
            "subject": "紧急付款请求",
            "body": """
你好，

我现在正在开会，需要你立即处理一笔紧急付款。
金额：$50,000
收款方：ABC供应商
账户：XXX-XXX-XXXX

请尽快处理，完成后回复我。

CEO
""",
            "attachments": [],
            "category": "商务邮件诈骗(BEC)",
            "threat_indicators": [
                "伪装高管",
                "紧急付款要求",
                "缺少具体细节",
                "绕过正常流程"
            ]
        },
        {
            "id": "phishing_003",
            "from": "no-reply@amazon-order.shop",
            "to": "customer@email.com",
            "subject": "您的订单已发货 - 请确认收货地址",
            "body": """
亲爱的客户：

您的订单 #AMZ-2024-123456 已发货！

请点击以下链接确认您的收货地址：
http://amazon-order.shop/confirm-address?id=xxx

如地址有误，请立即更新，否则包裹将无法送达。

亚马逊物流团队
""",
            "attachments": [],
            "category": "电商钓鱼",
            "threat_indicators": [
                "伪造域名 (amazon-order.shop)",
                "要求确认敏感信息",
                "紧迫感制造"
            ]
        }
    ],
    
    # 垃圾邮件样本
    "spam": [
        {
            "id": "spam_001",
            "from": "promo@unknown-marketing.net",
            "to": "user@email.com",
            "subject": "恭喜您中奖了！点击领取iPhone 15",
            "body": """
🎉 恭喜！您是我们的第100万位访客！

您已获得：
- iPhone 15 Pro Max 256GB
- AirPods Pro
- $500 礼品卡

立即点击领取：http://prize-claim.xyz/winner

限时24小时，过期作废！
""",
            "attachments": [],
            "category": "抽奖诈骗",
            "threat_indicators": [
                "虚假中奖信息",
                "可疑链接",
                "紧迫感制造"
            ]
        },
        {
            "id": "spam_002",
            "from": "loan@fast-money.top",
            "to": "recipient@email.com",
            "subject": "无抵押贷款，当天放款，利率低至0.1%",
            "body": """
【极速贷款】
无需抵押，无需担保
额度：1万-100万
利率：低至0.1%/月
放款：当天到账

联系电话：400-XXX-XXXX
微信：fastloan2024

名额有限，先到先得！
""",
            "attachments": [],
            "category": "贷款广告",
            "threat_indicators": [
                "夸大宣传",
                "可疑联系方式",
                "金融诈骗风险"
            ]
        }
    ],
    
    # 恶意附件样本
    "malicious_attachment": [
        {
            "id": "malicious_001",
            "from": "invoice@supplier-billing.com",
            "to": "accounting@company.com",
            "subject": "发票_20240115_PDF.exe",
            "body": "请查收附件中的发票。",
            "attachments": [
                {"filename": "发票_20240115.pdf.exe", "size": 524288},
                {"filename": "发票_20240115.doc", "size": 30720}
            ],
            "category": "恶意附件",
            "threat_indicators": [
                "双重扩展名",
                "可执行文件伪装",
                "缺少正文内容"
            ]
        },
        {
            "id": "malicious_002",
            "from": "document@share-file.org",
            "to": "employee@company.com",
            "subject": "共享文档 - 请查看",
            "body": "有人与您共享了文档。",
            "attachments": [
                {"filename": "shared_document.scr", "size": 1048576},
                {"filename": "readme.txt", "size": 1024}
            ],
            "category": "恶意附件",
            "threat_indicators": [
                "危险扩展名 (.scr)",
                "可疑文件大小",
                "模糊的正文描述"
            ]
        }
    ]
}


# ============================================================
# 邮件处理示例函数
# ============================================================

def process_single_email(email: Dict) -> Dict:
    """
    处理单封邮件的完整流程
    
    Args:
        email: 邮件数据字典
        
    Returns:
        处理结果字典
    """
    # 初始化检测引擎
    threat_engine = ThreatDetectionEngine()
    phishing_detector = PhishingDetector()
    link_detector = MaliciousLinkDetector()
    attachment_scanner = AttachmentScanner()
    
    # 结果字典
    result = {
        "email_id": email["id"],
        "from": email["from"],
        "subject": email["subject"],
        "analysis": {},
        "threats": [],
        "recommendation": "",
        "action": ""
    }
    
    print(f"\n{'='*60}")
    print(f"处理邮件: {email['subject']}")
    print(f"发件人: {email['from']}")
    print(f"{'='*60}")
    
    # 1. 威胁检测
    print("\n[步骤1] 威胁检测...")
    threat_result = threat_engine.analyze_email(email)
    result["analysis"]["threat_level"] = threat_result.threat_level.value
    result["analysis"]["risk_score"] = threat_result.risk_score
    
    print(f"  威胁等级: {threat_result.threat_level.value}")
    print(f"  风险分数: {threat_result.risk_score}")
    
    if threat_result.threats:
        print(f"  检测到 {len(threat_result.threats)} 个威胁:")
        for t in threat_result.threats[:5]:
            print(f"    - {t.threat_type}: {t.description}")
            result["threats"].append({
                "type": t.threat_type,
                "description": t.description,
                "severity": t.severity
            })
    
    # 2. 钓鱼检测
    print("\n[步骤2] 钓鱼邮件检测...")
    is_phishing, confidence, evidence = phishing_detector.detect(email)
    result["analysis"]["phishing_confidence"] = confidence
    result["analysis"]["is_phishing"] = is_phishing
    
    print(f"  钓鱼概率: {confidence*100:.1f}%")
    if is_phishing:
        print(f"  结论: 可能是钓鱼邮件")
        if evidence:
            print(f"  证据:")
            for e in evidence[:3]:
                print(f"    - {e}")
    
    # 3. 链接检测
    print("\n[步骤3] 链接安全检测...")
    links = re.findall(r'http[s]?://[^\s<>"]+', email.get("body", ""))
    if links:
        print(f"  发现 {len(links)} 个链接:")
        for link in links[:3]:
            is_safe, threats, analysis = link_detector.check_url(link)
            print(f"    - {link}")
            print(f"      安全: {'是' if is_safe else '否'}")
            if threats:
                print(f"      威胁: {', '.join(threats[:2])}")
            result["analysis"]["link_safety"] = "safe" if is_safe else "unsafe"
    else:
        print("  未发现链接")
        result["analysis"]["link_safety"] = "none"
    
    # 4. 附件检测
    print("\n[步骤4] 附件安全扫描...")
    if email.get("attachments"):
        print(f"  发现 {len(email['attachments'])} 个附件:")
        for att in email["attachments"]:
            att_result = attachment_scanner.scan_attachment(att)
            print(f"    - {att['filename']}")
            print(f"      安全: {'是' if att_result.is_safe else '否'}")
            if not att_result.is_safe:
                print(f"      威胁: {att_result.threat_type}")
                result["threats"].append({
                    "type": "malicious_attachment",
                    "filename": att["filename"],
                    "threat": att_result.threat_type
                })
    else:
        print("  无附件")
    
    # 5. 生成建议和决策
    print("\n[步骤5] 生成处理建议...")
    
    if threat_result.threat_level in [ThreatLevel.CRITICAL, ThreatLevel.HIGH] or is_phishing:
        result["action"] = "拦截"
        result["recommendation"] = "检测到高风险威胁，建议拦截并通知安全团队"
    elif threat_result.threat_level == ThreatLevel.MEDIUM:
        result["action"] = "隔离审核"
        result["recommendation"] = "存在中等风险，建议隔离后人工审核"
    else:
        result["action"] = "放行"
        result["recommendation"] = "未检测到明显威胁，可以正常处理"
    
    print(f"  决策: {result['action']}")
    print(f"  建议: {result['recommendation']}")
    
    return result


def process_batch_emails(emails: List[Dict]) -> List[Dict]:
    """
    批量处理邮件
    
    Args:
        emails: 邮件列表
        
    Returns:
        处理结果列表
    """
    print(f"\n{'#'*60}")
    print(f"# 批量处理 {len(emails)} 封邮件")
    print(f"{'#'*60}")
    
    results = []
    for email in emails:
        result = process_single_email(email)
        results.append(result)
    
    # 统计
    print(f"\n{'='*60}")
    print("处理结果统计:")
    print(f"{'='*60}")
    
    actions = {}
    for r in results:
        action = r["action"]
        actions[action] = actions.get(action, 0) + 1
    
    for action, count in actions.items():
        print(f"  {action}: {count} 封")
    
    return results


# ============================================================
# 演示场景
# ============================================================

def demo_normal_emails():
    """演示正常邮件处理"""
    print("\n" + "#"*70)
    print("# 演示场景1: 正常邮件处理")
    print("#"*70)
    
    results = process_batch_emails(REAL_EMAIL_SAMPLES["normal"])
    return results


def demo_phishing_detection():
    """演示钓鱼邮件检测"""
    print("\n" + "#"*70)
    print("# 演示场景2: 钓鱼邮件检测")
    print("#"*70)
    
    results = process_batch_emails(REAL_EMAIL_SAMPLES["phishing"])
    return results


def demo_spam_detection():
    """演示垃圾邮件检测"""
    print("\n" + "#"*70)
    print("# 演示场景3: 垃圾邮件检测")
    print("#"*70)
    
    results = process_batch_emails(REAL_EMAIL_SAMPLES["spam"])
    return results


def demo_malicious_attachment():
    """演示恶意附件检测"""
    print("\n" + "#"*70)
    print("# 演示场景4: 恶意附件检测")
    print("#"*70)
    
    results = process_batch_emails(REAL_EMAIL_SAMPLES["malicious_attachment"])
    return results


def demo_mixed_emails():
    """演示混合邮件处理"""
    print("\n" + "#"*70)
    print("# 演示场景5: 混合邮件处理（模拟真实收件箱）")
    print("#"*70)
    
    # 模拟真实收件箱：正常邮件占大多数，夹杂少量恶意邮件
    mixed_emails = (
        REAL_EMAIL_SAMPLES["normal"] * 3 +  # 正常邮件占多数
        REAL_EMAIL_SAMPLES["phishing"][:2] +  # 少量钓鱼
        REAL_EMAIL_SAMPLES["spam"][:1] +  # 少量垃圾
        REAL_EMAIL_SAMPLES["malicious_attachment"][:1]  # 少量恶意附件
    )
    
    results = process_batch_emails(mixed_emails)
    
    # 详细统计
    print(f"\n{'='*60}")
    print("详细分析报告:")
    print(f"{'='*60}")
    
    total = len(results)
    blocked = len([r for r in results if r["action"] == "拦截"])
    quarantined = len([r for r in results if r["action"] == "隔离审核"])
    passed = len([r for r in results if r["action"] == "放行"])
    
    print(f"\n总邮件数: {total}")
    print(f"已拦截: {blocked} ({blocked/total*100:.1f}%)")
    print(f"待审核: {quarantined} ({quarantined/total*100:.1f}%)")
    print(f"已放行: {passed} ({passed/total*100:.1f}%)")
    
    # 威胁类型统计
    all_threats = []
    for r in results:
        all_threats.extend(r.get("threats", []))
    
    if all_threats:
        print(f"\n检测到的威胁类型:")
        threat_types = {}
        for t in all_threats:
            t_type = t.get("type", "unknown")
            threat_types[t_type] = threat_types.get(t_type, 0) + 1
        
        for t_type, count in sorted(threat_types.items(), key=lambda x: -x[1]):
            print(f"  - {t_type}: {count} 次")
    
    return results


# ============================================================
# 与其他工具集成示例
# ============================================================

def example_integration_with_email_client():
    """
    与邮件客户端集成示例
    
    说明：本技能提供邮件处理能力，实际邮件收发需要配合邮件客户端。
    支持的集成方式：
    1. IMAP/POP3 接收邮件 → 使用本技能处理
    2. SMTP 发送邮件 → 使用本技能生成邮件内容
    3. API集成 (Gmail API, Outlook API等)
    """
    print("\n" + "#"*70)
    print("# 与邮件客户端集成说明")
    print("#"*70)
    
    print("""
本技能专注于邮件处理逻辑，实际邮件收发需要配合邮件客户端。

支持的集成方式：

1. IMAP/POP3 接收 → 本技能处理
   ```python
   # 伪代码示例
   import imaplib
   
   # 连接邮件服务器
   mail = imaplib.IMAP4_SSL('imap.gmail.com')
   mail.login('user@gmail.com', 'password')
   mail.select('inbox')
   
   # 获取邮件
   _, messages = mail.search(None, 'UNSEEN')
   for num in messages[0].split():
       # 获取邮件内容
       email_data = parse_email(mail.fetch(num, '(RFC822)'))
       
       # 使用本技能处理
       result = process_single_email(email_data)
       
       # 根据结果执行操作
       if result['action'] == '拦截':
           # 移动到垃圾邮件文件夹
           mail.copy(num, 'Spam')
   ```

2. SMTP 发送 → 本技能生成内容
   ```python
   # 伪代码示例
   import smtplib
   from email.mime.text import MIMEText
   
   # 使用本技能生成邮件内容
   from mail_functions import MailCore
   
   mail_core = MailCore()
   mail_core.create_template('welcome', '欢迎加入', '您好 {name}，欢迎加入我们团队！')
   template_result = mail_core.use_template('welcome', {'name': '张三'})
   email_content = template_result.get('body', '')
   
   # 发送邮件
   msg = MIMEText(email_content)
   msg['Subject'] = '欢迎加入'
   msg['From'] = 'hr@company.com'
   msg['To'] = 'newemployee@company.com'
   
   with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
       server.login('hr@company.com', 'password')
       server.send_message(msg)
   ```

3. Gmail API 集成
   ```python
   # 需要安装 google-api-python-client
   # pip install google-api-python-client
   
   from google.oauth2.credentials import Credentials
   from googleapiclient.discovery import build
   
   # 认证
   creds = Credentials.from_authorized_user_file('token.json')
   service = build('gmail', 'v1', credentials=creds)
   
   # 获取邮件
   results = service.users().messages().list(userId='me').execute()
   messages = results.get('messages', [])
   
   for msg in messages:
       # 获取邮件详情
       email_data = service.users().messages().get(
           userId='me', id=msg['id']
       ).execute()
       
       # 使用本技能处理
       result = process_single_email(parse_gmail(email_data))
   ```

注意：以上代码仅为集成示例，实际使用需要：
1. 配置正确的邮件服务器地址和端口
2. 获取相应的认证凭证
3. 遵守邮件服务商的使用条款
""")
    
    return True


# ============================================================
# 运行所有演示
# ============================================================

def run_all_demos():
    """运行所有演示场景"""
    print("\n" + "="*70)
    print("="*70)
    print("  企业级智能邮件助手 - 真实邮件处理演示")
    print("  Enterprise Mail Assistant - Real Email Processing Demo")
    print("="*70)
    print("="*70)
    
    demo_normal_emails()
    demo_phishing_detection()
    demo_spam_detection()
    demo_malicious_attachment()
    demo_mixed_emails()
    example_integration_with_email_client()
    
    print("\n" + "="*70)
    print("  所有演示运行完成")
    print("="*70)


if __name__ == '__main__':
    run_all_demos()
