"""
企业级智能邮件助手 - 企业级用例示例
Enterprise Mail Assistant - Enterprise Use Cases Examples

本文件提供真实企业场景下的使用示例，帮助Agent快速应用到实际业务中。
"""

from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import json

# 导入技能模块
from mail_functions import MailCore, Email, EmailAddress
from advanced_mail_features import MailTracker, MailEncryptor, MailApprovalSystem, MailCollaboration
from mail_queue_notification import MailQueue, NotificationSystem
from security_defense import ThreatDetectionEngine, PhishingDetector, AttachmentScanner
from compliance_checker import ComplianceRuleEngine, AuditTrailTracker


# ============================================================
# 用例 1: 企业邮件安全监控中心
# ============================================================

def example_security_monitoring_center():
    """
    企业邮件安全监控中心
    
    场景：企业需要实时监控所有进出邮件，拦截钓鱼邮件和恶意附件。
    """
    print("\n" + "="*60)
    print("用例 1: 企业邮件安全监控中心")
    print("="*60)
    
    # 初始化安全引擎
    threat_engine = ThreatDetectionEngine()
    phishing_detector = PhishingDetector()
    attachment_scanner = AttachmentScanner()
    
    # 模拟企业收到的一批邮件
    incoming_emails = [
        {
            'id': 'email_001',
            'from': 'hr@company-internal.com',
            'to': 'employee@company.com',
            'subject': '2024年度绩效考核通知',
            'body': '请查看附件中的绩效考核表格...',
            'attachments': [{'filename': '绩效考核表.xlsx', 'size': 51200}]
        },
        {
            'id': 'email_002',
            'from': 'security@bank-alert.xyz',
            'to': 'finance@company.com',
            'subject': '紧急：您的银行账户存在风险',
            'body': '您的账户已被冻结，请立即点击链接验证：http://192.168.1.100/verify',
            'attachments': [{'filename': 'account_verify.exe', 'size': 1048576}]
        },
        {
            'id': 'email_003',
            'from': 'partner@trusted-supplier.com',
            'to': 'procurement@company.com',
            'subject': '订单确认 - PO-2024-001',
            'body': '附件为订单确认书，请查收。',
            'attachments': [{'filename': '订单确认书.pdf', 'size': 204800}]
        }
    ]
    
    # 处理结果
    results = []
    for email in incoming_emails:
        print(f"\n处理邮件: {email['subject']}")
        print(f"发件人: {email['from']}")
        
        # 1. 威胁检测
        threat_result = threat_engine.analyze_email(email)
        print(f"  威胁等级: {threat_result.threat_level.value}")
        
        # 2. 钓鱼检测
        is_phishing, confidence, evidence = phishing_detector.detect(email)
        print(f"  钓鱼概率: {confidence*100:.1f}%")
        
        # 3. 附件扫描
        if email['attachments']:
            for att in email['attachments']:
                att_result = attachment_scanner.scan_attachment(att)
                print(f"  附件 '{att['filename']}': {'安全' if att_result.is_safe else '危险'}")
        
        # 4. 决策
        if threat_result.threat_level.value in ['critical', 'high'] or is_phishing:
            action = "拦截"
            reason = "检测到威胁或钓鱼特征"
        else:
            action = "放行"
            reason = "安全"
        
        results.append({
            'email_id': email['id'],
            'action': action,
            'reason': reason,
            'threat_level': threat_result.threat_level.value,
            'phishing_confidence': confidence
        })
        print(f"  决策: {action} ({reason})")
    
    # 生成安全报告
    print("\n" + "-"*40)
    print("安全监控报告:")
    blocked = [r for r in results if r['action'] == '拦截']
    passed = [r for r in results if r['action'] == '放行']
    print(f"  总邮件数: {len(results)}")
    print(f"  已拦截: {len(blocked)}")
    print(f"  已放行: {len(passed)}")
    
    return results


# ============================================================
# 用例 2: 合规审计自动化
# ============================================================

def example_compliance_audit_automation():
    """
    合规审计自动化
    
    场景：企业需要定期检查邮件系统是否符合ISO27001、GDPR等合规要求。
    """
    print("\n" + "="*60)
    print("用例 2: 合规审计自动化")
    print("="*60)
    
    # 初始化合规引擎
    from compliance_checker import ComplianceFramework
    compliance_engine = ComplianceRuleEngine()
    audit_tracker = AuditTrailTracker()
    
    # 模拟企业邮件系统配置
    mail_system_config = {
        'configurations': {
            'encryption': {
                'enabled': True,
                'algorithm': 'AES-256',
                'key_rotation_days': 90
            },
            'access_control': {
                'mfa_enabled': True,
                'password_policy': {
                    'min_length': 12,
                    'require_special': True,
                    'expiry_days': 90
                }
            },
            'data_retention': {
                'enabled': True,
                'retention_days': 365,
                'auto_delete': True
            },
            'backup': {
                'enabled': True,
                'frequency': 'daily',
                'encryption': True,
                'offsite': True
            },
            'logging': {
                'enabled': True,
                'log_level': 'INFO',
                'retention_days': 90
            },
            'gdpr_specific': {
                'consent_management': True,
                'data_portability': True,
                'right_to_deletion': True
            }
        }
    }
    
    # 执行合规检查
    frameworks = [ComplianceFramework.ISO27001, ComplianceFramework.GDPR, ComplianceFramework.PCI_DSS]
    
    print("\n检查合规框架:")
    for framework in frameworks:
        print(f"\n  {framework.value} 检查中...")
        report = compliance_engine.check_compliance(mail_system_config, [framework])
        
        if report:
            print(f"    总体合规率: {report.overall_compliance*100:.1f}%")
            print(f"    通过规则: {len(report.passed_rules)}/{len(report.checked_rules)}")
            
            if report.violations:
                print(f"    违规项 ({len(report.violations)}):")
                for v in report.violations[:3]:
                    print(f"      - {v.rule_id}: {v.description}")
    
    # 记录审计日志
    audit_tracker.record_action(
        action='compliance_check',
        user='system',
        target='mail_system',
        result='success',
        details={'frameworks': [f.value for f in frameworks]}
    )
    
    # 生成审计报告
    print("\n" + "-"*40)
    print("审计追踪摘要:")
    activities = audit_tracker.get_user_activity_report('system', days=30)
    print(f"  近30天审计记录: {len(activities)} 条")
    
    return audit_tracker.export_logs(format='json')


# ============================================================
# 用例 3: 邮件审批工作流
# ============================================================

def example_approval_workflow():
    """
    邮件审批工作流
    
    场景：企业对外发送重要邮件需要经过审批流程。
    """
    print("\n" + "="*60)
    print("用例 3: 邮件审批工作流")
    print("="*60)
    
    # 初始化审批系统
    approval_wf = MailApprovalSystem()
    
    # 创建审批规则
    approval_wf.add_approval_rule({
        'rule_id': 'rule_external_payment',
        'name': '对外付款邮件审批',
        'conditions': {
            'keywords': ['付款', '转账', '汇款', '打款'],
            'recipients': ['external']
        },
        'approvers': ['finance_manager@company.com', 'ceo@company.com'],
        'require_all': True,
        'timeout_hours': 24
    })
    
    approval_wf.add_approval_rule({
        'rule_id': 'rule_contract',
        'name': '合同邮件审批',
        'conditions': {
            'keywords': ['合同', '协议', '签约'],
            'attachments': ['.pdf', '.doc', '.docx']
        },
        'approvers': ['legal@company.com'],
        'require_all': False,
        'timeout_hours': 48
    })
    
    # 模拟待审批邮件
    pending_mail = {
        'id': 'mail_out_001',
        'from': 'sales@company.com',
        'to': 'client@external.com',
        'subject': '关于合同签订及付款事宜',
        'body': '附件为我们的合作协议，请查收。确认后请安排付款...',
        'attachments': [{'filename': '合作协议.pdf'}]
    }
    
    # 提交审批
    print("\n提交邮件审批:")
    approval_request = approval_wf.submit_for_approval(pending_mail)
    print(f"  审批ID: {approval_request.request_id}")
    print(f"  触发规则: {approval_request.matched_rules}")
    print(f"  需要审批人: {approval_request.required_approvers}")
    
    # 模拟审批流程
    print("\n审批流程模拟:")
    
    # 法务审批通过
    result = approval_wf.process_approval(
        request_id=approval_request.request_id,
        approver='legal@company.com',
        decision='approved',
        comment='合同条款已审核，无法律风险。'
    )
    print(f"  法务审批: 通过")
    print(f"  当前状态: {result['status']}")
    
    # 财务审批
    result = approval_wf.process_approval(
        request_id=approval_request.request_id,
        approver='finance_manager@company.com',
        decision='approved',
        comment='付款条款符合公司财务规定。'
    )
    print(f"  财务审批: 通过")
    print(f"  当前状态: {result['status']}")
    
    # CEO审批
    result = approval_wf.process_approval(
        request_id=approval_request.request_id,
        approver='ceo@company.com',
        decision='approved',
        comment='同意发送。'
    )
    print(f"  CEO审批: 通过")
    print(f"  最终状态: {result['status']}")
    
    return result


# ============================================================
# 用例 4: 邮件分类与智能路由
# ============================================================

def example_smart_routing():
    """
    邮件分类与智能路由
    
    场景：企业收到大量邮件，需要自动分类并路由到正确的部门。
    """
    print("\n" + "="*60)
    print("用例 4: 邮件分类与智能路由")
    print("="*60)
    
    # 初始化邮件管理器
    mail_core = MailCore()
    rule_engine = mail_core  # MailCore 包含规则引擎功能
    
    # 配置分类规则
    routing_rules = [
        {
            'rule_id': 'route_hr',
            'name': 'HR邮件路由',
            'conditions': {'keywords': ['招聘', '面试', '入职', '离职', '薪资', '考勤']},
            'actions': {'forward_to': 'hr@company.com', 'tag': 'HR'}
        },
        {
            'rule_id': 'route_finance',
            'name': '财务邮件路由',
            'conditions': {'keywords': ['发票', '报销', '付款', '账单', '财务']},
            'actions': {'forward_to': 'finance@company.com', 'tag': '财务'}
        },
        {
            'rule_id': 'route_support',
            'name': '客服邮件路由',
            'conditions': {'keywords': ['问题', '投诉', '退款', '售后', '客服']},
            'actions': {'forward_to': 'support@company.com', 'tag': '客服', 'priority': 'high'}
        },
        {
            'rule_id': 'route_legal',
            'name': '法务邮件路由',
            'conditions': {'keywords': ['合同', '法律', '律师', '诉讼', '知识产权']},
            'actions': {'forward_to': 'legal@company.com', 'tag': '法务', 'priority': 'urgent'}
        }
    ]
    
    for rule in routing_rules:
        rule_engine.add_rule(rule)
    
    # 模拟收件箱
    inbox_emails = [
        {'subject': '关于明天面试安排', 'from': 'candidate@email.com', 'body': '您好，我想确认明天的面试时间...'},
        {'subject': '发票开具申请', 'from': 'client@partner.com', 'body': '请帮忙开具上月服务的发票...'},
        {'subject': '产品使用问题咨询', 'from': 'user@customer.com', 'body': '我在使用时遇到了问题...'},
        {'subject': '合同审核请求', 'from': 'sales@company.com', 'body': '请法务同事帮忙审核这份合同...'},
        {'subject': '年终奖发放时间', 'from': 'employee@company.com', 'body': '请问今年年终奖什么时候发...'}
    ]
    
    # 智能路由
    print("\n邮件智能路由:")
    routing_results = []
    for email in inbox_emails:
        result = rule_engine.process(email)
        routing_results.append(result)
        
        print(f"\n  邮件: {email['subject']}")
        print(f"    发件人: {email['from']}")
        print(f"    路由到: {result.get('forward_to', '收件人')}")
        print(f"    标签: {result.get('tag', '无')}")
        print(f"    优先级: {result.get('priority', 'normal')}")
    
    # 统计
    print("\n" + "-"*40)
    print("路由统计:")
    route_counts = {}
    for r in routing_results:
        dept = r.get('tag', '未分类')
        route_counts[dept] = route_counts.get(dept, 0) + 1
    
    for dept, count in route_counts.items():
        print(f"  {dept}: {count} 封")
    
    return routing_results


# ============================================================
# 用例 5: 邮件安全事件响应
# ============================================================

def example_security_incident_response():
    """
    邮件安全事件响应
    
    场景：检测到钓鱼邮件后，自动化响应流程。
    """
    print("\n" + "="*60)
    print("用例 5: 邮件安全事件响应")
    print("="*60)
    
    # 初始化组件
    threat_engine = ThreatDetectionEngine()
    mail_queue = MailQueue()
    notification = NotificationSystem()
    
    # 模拟检测到的钓鱼邮件
    phishing_email = {
        'id': 'phish_001',
        'from': 'admin@paypa1.com',  # 伪装域名
        'to': 'victim@company.com',
        'subject': '您的PayPal账户需要验证',
        'body': '您的账户存在异常，请立即点击链接验证：http://paypa1-verify.xyz/confirm',
        'received_at': datetime.now().isoformat()
    }
    
    print("\n检测到可疑邮件:")
    print(f"  发件人: {phishing_email['from']}")
    print(f"  主题: {phishing_email['subject']}")
    
    # 威胁分析
    print("\n威胁分析:")
    threat_result = threat_engine.analyze_email(phishing_email)
    print(f"  威胁等级: {threat_result.threat_level.value}")
    print(f"  风险分数: {threat_result.risk_score}")
    
    if threat_result.threats:
        print(f"  检测到的威胁:")
        for t in threat_result.threats[:5]:
            print(f"    - {t.threat_type}: {t.description}")
    
    # 自动化响应
    print("\n自动化响应:")
    
    # 1. 隔离邮件
    mail_queue.quarantine_email(phishing_email['id'], reason='钓鱼邮件')
    print("  [√] 邮件已隔离")
    
    # 2. 标记发件人
    print(f"  [√] 发件人 {phishing_email['from']} 已加入黑名单")
    
    # 3. 通知安全团队
    notification.send_alert(
        level='high',
        title='检测到钓鱼邮件',
        message=f"发件人: {phishing_email['from']}, 收件人: {phishing_email['to']}",
        recipients=['security@company.com', 'soc@company.com']
    )
    print("  [√] 安全团队已通知")
    
    # 4. 通知受害者
    notification.send_notification(
        to=phishing_email['to'],
        subject='安全提醒：您收到一封钓鱼邮件已被拦截',
        body='我们检测到您收到一封钓鱼邮件，已自动拦截。请勿点击可疑链接。'
    )
    print(f"  [√] 受害者 {phishing_email['to']} 已收到安全提醒")
    
    # 5. 记录事件
    incident_record = {
        'incident_id': f"INC-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        'type': 'phishing',
        'severity': threat_result.threat_level.value,
        'email_id': phishing_email['id'],
        'sender': phishing_email['from'],
        'target': phishing_email['to'],
        'detected_at': datetime.now().isoformat(),
        'actions_taken': ['quarantine', 'blacklist', 'alert_security', 'notify_victim']
    }
    print(f"  [√] 事件已记录: {incident_record['incident_id']}")
    
    return incident_record


# ============================================================
# 用例 6: 与邮件安全守门员协作
# ============================================================

def example_collaboration_with_gatekeeper():
    """
    与邮件安全守门员协作
    
    场景：企业级智能邮件助手与邮件安全守门员配合工作。
    """
    print("\n" + "="*60)
    print("用例 6: 与邮件安全守门员协作")
    print("="*60)
    
    # 模拟邮件安全守门员的输出
    gatekeeper_result = {
        'email_id': 'email_123',
        'security_status': 'safe',  # safe, suspicious, needs_confirmation
        'risk_level': 'low',
        'threats': [],
        'recommendations': '可以正常处理'
    }
    
    print("\n邮件安全守门员检查结果:")
    print(f"  安全状态: {gatekeeper_result['security_status']}")
    print(f"  风险等级: {gatekeeper_result['risk_level']}")
    print(f"  建议: {gatekeeper_result['recommendations']}")
    
    # 根据安全检查结果执行不同操作
    if gatekeeper_result['security_status'] == 'safe':
        print("\n[安全邮件] 执行邮件助手处理流程:")
        
        # 初始化邮件管理器
        mail_core = MailCore()
        rule_engine = mail_core  # MailCore 包含规则引擎功能
        
        # 模拟安全邮件
        safe_email = {
            'id': 'email_123',
            'from': 'partner@trusted.com',
            'to': 'sales@company.com',
            'subject': 'Q2合作方案讨论',
            'body': '您好，附件是我们Q2的合作方案...'
        }
        
        # 1. 自动分类
        print("  [√] 自动分类: 商务合作")
        
        # 2. 规则处理
        result = rule_engine.process(safe_email)
        print(f"  [√] 应用规则: {result.get('applied_rules', [])}")
        
        # 3. 智能归档
        print("  [√] 归档到: 商务邮件/合作意向")
        
        # 4. 生成回复建议
        print("  [√] 生成回复建议: 感谢您的来信，我们将尽快安排会议讨论...")
    
    elif gatekeeper_result['security_status'] == 'suspicious':
        print("\n[可疑邮件] 执行隔离流程:")
        print("  [√] 邮件已移入隔离区")
        print("  [√] 已通知管理员审核")
    
    elif gatekeeper_result['security_status'] == 'needs_confirmation':
        print("\n[需确认] 等待主人决策:")
        print("  [!] 该邮件需要主人确认后才能处理")
        print("  [√] 已发送通知给主人")
    
    return gatekeeper_result


# ============================================================
# 运行所有示例
# ============================================================

def run_all_examples():
    """运行所有企业级用例示例"""
    print("\n" + "#"*70)
    print("# 企业级智能邮件助手 - 企业级用例示例")
    print("# Enterprise Mail Assistant - Enterprise Use Cases Examples")
    print("#"*70)
    
    # 运行示例
    example_security_monitoring_center()
    example_compliance_audit_automation()
    example_approval_workflow()
    example_smart_routing()
    example_security_incident_response()
    example_collaboration_with_gatekeeper()
    
    print("\n" + "#"*70)
    print("# 所有示例运行完成")
    print("#"*70)


if __name__ == '__main__':
    run_all_examples()
