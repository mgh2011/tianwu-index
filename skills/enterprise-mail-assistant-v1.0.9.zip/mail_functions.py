"""
企业级智能邮件助手 - 完整邮件功能模块
Enterprise Mail Assistant - Comprehensive Mail Functions Module

包含所有邮件相关功能
"""

import json
import time
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import re


# ==================== 枚举定义 ====================

class MailPriority(Enum):
    """邮件优先级"""
    HIGHEST = 1  # 最高优先级
    HIGH = 2     # 高优先级
    NORMAL = 3   # 普通优先级
    LOW = 4      # 低优先级
    LOWEST = 5   # 最低优先级


class MailStatus(Enum):
    """邮件状态"""
    DRAFT = "draft"           # 草稿
    QUEUED = "queued"         # 队列中
    SENDING = "sending"       # 发送中
    SENT = "sent"             # 已发送
    DELIVERED = "delivered"   # 已送达
    READ = "read"             # 已读
    REPLIED = "replied"       # 已回复
    FORWARDED = "forwarded"   # 已转发
    FAILED = "failed"         # 发送失败
    WITHDRAWN = "withdrawn"   # 已撤回
    SPAM = "spam"             # 垃圾邮件
    DELETED = "deleted"       # 已删除


class EncryptionType(Enum):
    """加密类型"""
    NONE = "none"
    TLS = "tls"
    SSL = "ssl"
    PGP = "pgp"
    S_MIME = "s/mime"


# ==================== 数据类定义 ====================

@dataclass
class EmailAddress:
    """邮件地址"""
    address: str
    name: str = ""
    
    def to_dict(self) -> Dict:
        return {"address": self.address, "name": self.name}
    
    @classmethod
    def from_string(cls, addr_str: str) -> 'EmailAddress':
        """从字符串解析，支持 'Name <email@example.com>' 格式"""
        match = re.match(r'(?:(.+?)\s*<)?([^>]+)>?', addr_str.strip())
        if match:
            name = match.group(1) or ""
            address = match.group(2)
            return cls(address=address, name=name)
        return cls(address=addr_str)


@dataclass
class Attachment:
    """邮件附件"""
    filename: str
    content: bytes
    content_type: str = "application/octet-stream"
    size: int = 0
    checksum: str = ""
    
    def __post_init__(self):
        if not self.size:
            self.size = len(self.content)
        if not self.checksum:
            self.checksum = hashlib.md5(self.content).hexdigest()


@dataclass
class Email:
    """邮件对象"""
    id: str
    subject: str
    body: str
    from_addr: EmailAddress
    to_addrs: List[EmailAddress]
    cc_addrs: List[EmailAddress] = field(default_factory=list)
    bcc_addrs: List[EmailAddress] = field(default_factory=list)
    reply_to: Optional[EmailAddress] = None
    attachments: List[Attachment] = field(default_factory=list)
    priority: MailPriority = MailPriority.NORMAL
    status: MailStatus = MailStatus.DRAFT
    tags: List[str] = field(default_factory=list)
    labels: List[str] = field(default_factory=list)
    folder: str = "inbox"
    is_read: bool = False
    is_starred: bool = False
    is_important: bool = False
    is_encrypted: bool = False
    encryption_type: EncryptionType = EncryptionType.NONE
    created_at: datetime = field(default_factory=datetime.now)
    sent_at: Optional[datetime] = None
    read_at: Optional[datetime] = None
    headers: Dict[str, str] = field(default_factory=dict)
    thread_id: Optional[str] = None
    in_reply_to: Optional[str] = None
    references: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "subject": self.subject,
            "body": self.body,
            "from": self.from_addr.to_dict(),
            "to": [a.to_dict() for a in self.to_addrs],
            "cc": [a.to_dict() for a in self.cc_addrs],
            "bcc": [a.to_dict() for a in self.bcc_addrs],
            "priority": self.priority.name,
            "status": self.status.value,
            "tags": self.tags,
            "labels": self.labels,
            "folder": self.folder,
            "is_read": self.is_read,
            "is_starred": self.is_starred,
            "attachments": [{"filename": a.filename, "size": a.size} for a in self.attachments],
            "created_at": self.created_at.isoformat(),
            "sent_at": self.sent_at.isoformat() if self.sent_at else None
        }


# ==================== 核心邮件功能类 ====================

class MailCore:
    """邮件核心功能"""
    
    def __init__(self):
        self.emails: Dict[str, Email] = {}
        self.templates: Dict[str, Dict] = {}
        self.signatures: Dict[str, str] = {}
        self.rules: List[Dict] = []
        self.blacklist: set = set()
        self.whitelist: set = set()
    
    # ==================== 发送相关功能 ====================
    
    def send_email(self, email: Email) -> Dict[str, Any]:
        """发送邮件"""
        email.status = MailStatus.SENDING
        email.sent_at = datetime.now()
        
        # 模拟发送过程
        result = {
            "success": True,
            "message_id": email.id,
            "sent_at": email.sent_at.isoformat(),
            "status": "sent"
        }
        
        email.status = MailStatus.SENT
        self.emails[email.id] = email
        
        return result
    
    def send_later(self, email: Email, scheduled_time: datetime) -> Dict[str, Any]:
        """定时发送邮件"""
        email.status = MailStatus.QUEUED
        self.emails[email.id] = email
        
        return {
            "success": True,
            "message_id": email.id,
            "scheduled_time": scheduled_time.isoformat(),
            "status": "scheduled"
        }
    
    def send_with_delay(self, email: Email, delay_minutes: int) -> Dict[str, Any]:
        """延迟发送邮件"""
        scheduled_time = datetime.now() + timedelta(minutes=delay_minutes)
        return self.send_later(email, scheduled_time)
    
    def withdraw_email(self, email_id: str) -> Dict[str, Any]:
        """撤回邮件"""
        if email_id in self.emails:
            email = self.emails[email_id]
            if email.status in [MailStatus.SENT, MailStatus.DELIVERED]:
                email.status = MailStatus.WITHDRAWN
                return {"success": True, "message": "邮件已撤回"}
        return {"success": False, "message": "无法撤回该邮件"}
    
    def resend_email(self, email_id: str) -> Dict[str, Any]:
        """重发邮件"""
        if email_id in self.emails:
            email = self.emails[email_id]
            if email.status == MailStatus.FAILED:
                return self.send_email(email)
        return {"success": False, "message": "无法重发该邮件"}
    
    # ==================== 接收相关功能 ====================
    
    def receive_email(self, email: Email) -> Dict[str, Any]:
        """接收邮件"""
        email.status = MailStatus.DELIVERED
        email.folder = "inbox"
        self.emails[email.id] = email
        
        return {
            "success": True,
            "message_id": email.id,
            "received_at": datetime.now().isoformat()
        }
    
    def mark_as_read(self, email_id: str) -> Dict[str, Any]:
        """标记为已读"""
        if email_id in self.emails:
            self.emails[email_id].is_read = True
            self.emails[email_id].read_at = datetime.now()
            return {"success": True}
        return {"success": False}
    
    def mark_as_unread(self, email_id: str) -> Dict[str, Any]:
        """标记为未读"""
        if email_id in self.emails:
            self.emails[email_id].is_read = False
            return {"success": True}
        return {"success": False}
    
    def mark_as_starred(self, email_id: str) -> Dict[str, Any]:
        """添加星标"""
        if email_id in self.emails:
            self.emails[email_id].is_starred = True
            return {"success": True}
        return {"success": False}
    
    def mark_as_important(self, email_id: str) -> Dict[str, Any]:
        """标记为重要"""
        if email_id in self.emails:
            self.emails[email_id].is_important = True
            return {"success": True}
        return {"success": False}
    
    # ==================== 组织管理功能 ====================
    
    def move_to_folder(self, email_id: str, folder: str) -> Dict[str, Any]:
        """移动到文件夹"""
        if email_id in self.emails:
            self.emails[email_id].folder = folder
            return {"success": True, "folder": folder}
        return {"success": False}
    
    def add_label(self, email_id: str, label: str) -> Dict[str, Any]:
        """添加标签"""
        if email_id in self.emails:
            if label not in self.emails[email_id].labels:
                self.emails[email_id].labels.append(label)
            return {"success": True}
        return {"success": False}
    
    def remove_label(self, email_id: str, label: str) -> Dict[str, Any]:
        """移除标签"""
        if email_id in self.emails:
            if label in self.emails[email_id].labels:
                self.emails[email_id].labels.remove(label)
            return {"success": True}
        return {"success": False}
    
    def add_tag(self, email_id: str, tag: str) -> Dict[str, Any]:
        """添加标记"""
        if email_id in self.emails:
            if tag not in self.emails[email_id].tags:
                self.emails[email_id].tags.append(tag)
            return {"success": True}
        return {"success": False}
    
    def archive_email(self, email_id: str) -> Dict[str, Any]:
        """归档邮件"""
        return self.move_to_folder(email_id, "archive")
    
    def trash_email(self, email_id: str) -> Dict[str, Any]:
        """移至垃圾箱"""
        return self.move_to_folder(email_id, "trash")
    
    def delete_email(self, email_id: str) -> Dict[str, Any]:
        """永久删除邮件"""
        if email_id in self.emails:
            del self.emails[email_id]
            return {"success": True}
        return {"success": False}
    
    # ==================== 搜索功能 ====================
    
    def search_by_subject(self, keyword: str) -> List[Email]:
        """按主题搜索"""
        return [e for e in self.emails.values() if keyword.lower() in e.subject.lower()]
    
    def search_by_sender(self, sender: str) -> List[Email]:
        """按发件人搜索"""
        return [e for e in self.emails.values() if sender.lower() in e.from_addr.address.lower()]
    
    def search_by_content(self, keyword: str) -> List[Email]:
        """按内容搜索"""
        return [e for e in self.emails.values() if keyword.lower() in e.body.lower()]
    
    def search_by_date_range(self, start: datetime, end: datetime) -> List[Email]:
        """按日期范围搜索"""
        return [e for e in self.emails.values() if start <= e.created_at <= end]
    
    def search_by_label(self, label: str) -> List[Email]:
        """按标签搜索"""
        return [e for e in self.emails.values() if label in e.labels]
    
    def advanced_search(self, criteria: Dict[str, Any]) -> List[Email]:
        """高级搜索"""
        results = list(self.emails.values())
        
        if 'subject' in criteria:
            results = [e for e in results if criteria['subject'].lower() in e.subject.lower()]
        if 'sender' in criteria:
            results = [e for e in results if criteria['sender'].lower() in e.from_addr.address.lower()]
        if 'folder' in criteria:
            results = [e for e in results if e.folder == criteria['folder']]
        if 'is_read' in criteria:
            results = [e for e in results if e.is_read == criteria['is_read']]
        if 'is_starred' in criteria:
            results = [e for e in results if e.is_starred == criteria['is_starred']]
        if 'has_attachment' in criteria and criteria['has_attachment']:
            results = [e for e in results if e.attachments]
        if 'priority' in criteria:
            results = [e for e in results if e.priority == MailPriority[criteria['priority']]]
        
        return results
    
    # ==================== 模板管理 ====================
    
    def create_template(self, name: str, subject: str, body: str, 
                       variables: List[str] = None) -> Dict[str, Any]:
        """创建邮件模板"""
        template_id = hashlib.md5(name.encode()).hexdigest()[:8]
        self.templates[template_id] = {
            "id": template_id,
            "name": name,
            "subject": subject,
            "body": body,
            "variables": variables or [],
            "created_at": datetime.now().isoformat()
        }
        return {"success": True, "template_id": template_id}
    
    def use_template(self, template_id: str, variables: Dict[str, str] = None) -> Dict[str, Any]:
        """使用模板创建邮件"""
        if template_id not in self.templates:
            return {"success": False, "message": "模板不存在"}
        
        template = self.templates[template_id]
        subject = template['subject']
        body = template['body']
        
        # 替换变量（支持两种格式：{变量名} 和 {{变量名}}）
        if variables:
            for key, value in variables.items():
                # 支持 {{变量名}} 格式
                subject = subject.replace(f"{{{{{key}}}}}", value)
                body = body.replace(f"{{{{{key}}}}}", value)
                # 支持 {变量名} 格式
                subject = subject.replace(f"{{{key}}}", value)
                body = body.replace(f"{{{key}}}", value)
        
        return {
            "success": True,
            "subject": subject,
            "body": body
        }
    
    def list_templates(self) -> List[Dict]:
        """列出所有模板"""
        return list(self.templates.values())
    
    def delete_template(self, template_id: str) -> Dict[str, Any]:
        """删除模板"""
        if template_id in self.templates:
            del self.templates[template_id]
            return {"success": True}
        return {"success": False}
    
    # ==================== 签名管理 ====================
    
    def create_signature(self, name: str, content: str) -> Dict[str, Any]:
        """创建签名"""
        self.signatures[name] = content
        return {"success": True, "signature_name": name}
    
    def get_signature(self, name: str) -> Optional[str]:
        """获取签名"""
        return self.signatures.get(name)
    
    def list_signatures(self) -> List[str]:
        """列出所有签名"""
        return list(self.signatures.keys())
    
    def apply_signature(self, email: Email, signature_name: str) -> Email:
        """应用签名到邮件"""
        signature = self.get_signature(signature_name)
        if signature:
            email.body += f"\n\n--\n{signature}"
        return email
    
    # ==================== 规则管理 ====================
    
    def create_rule(self, name: str, conditions: Dict, actions: List[Dict]) -> Dict[str, Any]:
        """创建过滤规则"""
        rule = {
            "id": hashlib.md5(name.encode()).hexdigest()[:8],
            "name": name,
            "conditions": conditions,
            "actions": actions,
            "enabled": True,
            "created_at": datetime.now().isoformat()
        }
        self.rules.append(rule)
        return {"success": True, "rule": rule}
    
    def apply_rules(self, email: Email) -> Email:
        """应用规则到邮件"""
        for rule in self.rules:
            if not rule['enabled']:
                continue
            
            # 检查条件
            matched = True
            conditions = rule['conditions']
            
            if 'sender' in conditions:
                if conditions['sender'] not in email.from_addr.address:
                    matched = False
            if 'subject_contains' in conditions:
                if conditions['subject_contains'] not in email.subject:
                    matched = False
            if 'has_attachments' in conditions and conditions['has_attachments']:
                if not email.attachments:
                    matched = False
            
            # 执行动作
            if matched:
                for action in rule['actions']:
                    if action['type'] == 'move_to_folder':
                        email.folder = action['folder']
                    elif action['type'] == 'add_label':
                        if action['label'] not in email.labels:
                            email.labels.append(action['label'])
                    elif action['type'] == 'mark_as_read':
                        email.is_read = True
                    elif action['type'] == 'forward':
                        # 标记需要转发
                        pass
        
        return email
    
    def list_rules(self) -> List[Dict]:
        """列出所有规则"""
        return self.rules
    
    def toggle_rule(self, rule_id: str) -> Dict[str, Any]:
        """启用/禁用规则"""
        for rule in self.rules:
            if rule['id'] == rule_id:
                rule['enabled'] = not rule['enabled']
                return {"success": True, "enabled": rule['enabled']}
        return {"success": False}
    
    # ==================== 黑白名单 ====================
    
    def add_to_blacklist(self, address: str) -> Dict[str, Any]:
        """添加到黑名单"""
        self.blacklist.add(address.lower())
        return {"success": True, "address": address}
    
    def remove_from_blacklist(self, address: str) -> Dict[str, Any]:
        """从黑名单移除"""
        self.blacklist.discard(address.lower())
        return {"success": True}
    
    def add_to_whitelist(self, address: str) -> Dict[str, Any]:
        """添加到白名单"""
        self.whitelist.add(address.lower())
        return {"success": True, "address": address}
    
    def remove_from_whitelist(self, address: str) -> Dict[str, Any]:
        """从白名单移除"""
        self.whitelist.discard(address.lower())
        return {"success": True}
    
    def check_sender_reputation(self, address: str) -> str:
        """检查发件人信誉"""
        addr_lower = address.lower()
        if addr_lower in self.whitelist:
            return "trusted"
        if addr_lower in self.blacklist:
            return "blocked"
        return "unknown"
    
    # ==================== 回复转发 ====================
    
    def reply(self, email_id: str, body: str, reply_all: bool = False) -> Dict[str, Any]:
        """回复邮件"""
        if email_id not in self.emails:
            return {"success": False, "message": "邮件不存在"}
        
        original = self.emails[email_id]
        
        reply_email = Email(
            id=f"re_{email_id}",
            subject=f"Re: {original.subject}",
            body=body,
            from_addr=EmailAddress(address="me@example.com"),
            to_addrs=[original.from_addr],
            in_reply_to=email_id,
            thread_id=original.thread_id or email_id
        )
        
        if reply_all:
            reply_email.cc_addrs = original.cc_addrs
        
        original.status = MailStatus.REPLIED
        return self.send_email(reply_email)
    
    def forward(self, email_id: str, to_addrs: List[str], body: str = "") -> Dict[str, Any]:
        """转发邮件"""
        if email_id not in self.emails:
            return {"success": False, "message": "邮件不存在"}
        
        original = self.emails[email_id]
        
        forward_body = f"\n\n---------- 转发的邮件 ----------\n"
        forward_body += f"发件人: {original.from_addr.address}\n"
        forward_body += f"日期: {original.created_at}\n"
        forward_body += f"主题: {original.subject}\n\n"
        forward_body += original.body
        
        forward_email = Email(
            id=f"fw_{email_id}",
            subject=f"Fwd: {original.subject}",
            body=body + forward_body,
            from_addr=EmailAddress(address="me@example.com"),
            to_addrs=[EmailAddress(address=a) for a in to_addrs],
            attachments=original.attachments
        )
        
        original.status = MailStatus.FORWARDED
        return self.send_email(forward_email)
    
    # ==================== 批量操作 ====================
    
    def batch_mark_read(self, email_ids: List[str]) -> Dict[str, Any]:
        """批量标记已读"""
        success_count = 0
        for email_id in email_ids:
            if self.mark_as_read(email_id)['success']:
                success_count += 1
        return {"success": True, "count": success_count}
    
    def batch_move(self, email_ids: List[str], folder: str) -> Dict[str, Any]:
        """批量移动"""
        success_count = 0
        for email_id in email_ids:
            if self.move_to_folder(email_id, folder)['success']:
                success_count += 1
        return {"success": True, "count": success_count}
    
    def batch_delete(self, email_ids: List[str]) -> Dict[str, Any]:
        """批量删除"""
        success_count = 0
        for email_id in email_ids:
            if self.delete_email(email_id)['success']:
                success_count += 1
        return {"success": True, "count": success_count}
    
    def batch_add_label(self, email_ids: List[str], label: str) -> Dict[str, Any]:
        """批量添加标签"""
        success_count = 0
        for email_id in email_ids:
            if self.add_label(email_id, label)['success']:
                success_count += 1
        return {"success": True, "count": success_count}
    
    # ==================== 统计分析 ====================
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取邮件统计"""
        emails = list(self.emails.values())
        
        stats = {
            "total": len(emails),
            "unread": len([e for e in emails if not e.is_read]),
            "starred": len([e for e in emails if e.is_starred]),
            "important": len([e for e in emails if e.is_important]),
            "with_attachments": len([e for e in emails if e.attachments]),
            "by_folder": {},
            "by_priority": {},
            "by_status": {},
            "senders": {}
        }
        
        for email in emails:
            # 按文件夹统计
            folder = email.folder
            stats['by_folder'][folder] = stats['by_folder'].get(folder, 0) + 1
            
            # 按优先级统计
            priority = email.priority.name
            stats['by_priority'][priority] = stats['by_priority'].get(priority, 0) + 1
            
            # 按状态统计
            status = email.status.value
            stats['by_status'][status] = stats['by_status'].get(status, 0) + 1
            
            # 按发件人统计
            sender = email.from_addr.address
            stats['senders'][sender] = stats['senders'].get(sender, 0) + 1
        
        return stats
    
    def get_unread_count(self) -> int:
        """获取未读邮件数量"""
        return len([e for e in self.emails.values() if not e.is_read])
    
    def get_folder_count(self, folder: str) -> int:
        """获取指定文件夹邮件数量"""
        return len([e for e in self.emails.values() if e.folder == folder])
    
    # ==================== 导入导出 ====================
    
    def export_emails(self, email_ids: List[str], format: str = "json") -> str:
        """导出邮件"""
        emails_data = []
        for email_id in email_ids:
            if email_id in self.emails:
                emails_data.append(self.emails[email_id].to_dict())
        
        if format == "json":
            return json.dumps(emails_data, indent=2, ensure_ascii=False)
        else:
            # 其他格式支持
            return str(emails_data)
    
    def import_emails(self, data: str, format: str = "json") -> Dict[str, Any]:
        """导入邮件"""
        if format == "json":
            emails_data = json.loads(data)
            count = 0
            for email_data in emails_data:
                email = Email(
                    id=email_data['id'],
                    subject=email_data['subject'],
                    body=email_data['body'],
                    from_addr=EmailAddress(**email_data['from']),
                    to_addrs=[EmailAddress(**a) for a in email_data['to']]
                )
                self.emails[email.id] = email
                count += 1
            return {"success": True, "count": count}
        return {"success": False}


# ==================== 使用示例 ====================

if __name__ == "__main__":
    print("="*60)
    print("企业级智能邮件助手 - 完整功能演示")
    print("="*60)
    
    mail = MailCore()
    
    # 1. 创建并发送邮件
    print("\n📧 1. 发送邮件")
    email = Email(
        id="mail_001",
        subject="项目进度报告",
        body="请查看附件中的项目进度报告。",
        from_addr=EmailAddress(address="sender@example.com", name="发件人"),
        to_addrs=[EmailAddress(address="receiver@example.com", name="收件人")],
        priority=MailPriority.HIGH
    )
    result = mail.send_email(email)
    print(f"   发送结果: {result}")
    
    # 2. 创建模板
    print("\n📝 2. 创建邮件模板")
    result = mail.create_template(
        name="周报模板",
        subject="{{week}} 周报 - {{name}}",
        body="本周工作内容:\n{{content}}\n\n下周计划:\n{{plan}}",
        variables=["week", "name", "content", "plan"]
    )
    print(f"   模板创建: {result}")
    
    # 3. 使用模板
    print("\n📋 3. 使用模板创建邮件")
    template_result = mail.use_template(
        "周报模板",
        {"week": "第15周", "name": "张三", "content": "完成功能开发", "plan": "测试上线"}
    )
    print(f"   模板应用: {template_result}")
    
    # 4. 创建过滤规则
    print("\n⚙️ 4. 创建过滤规则")
    rule = mail.create_rule(
        name="自动归档通知邮件",
        conditions={"subject_contains": "通知"},
        actions=[{"type": "move_to_folder", "folder": "notifications"}]
    )
    print(f"   规则创建: {rule}")
    
    # 5. 黑白名单管理
    print("\n🚫 5. 黑名单管理")
    mail.add_to_blacklist("spam@example.com")
    mail.add_to_whitelist("trusted@company.com")
    print(f"   黑名单: {mail.blacklist}")
    print(f"   白名单: {mail.whitelist}")
    
    # 6. 搜索功能
    print("\n🔍 6. 搜索邮件")
    results = mail.search_by_subject("项目")
    print(f"   搜索结果: {len(results)} 封")
    
    # 7. 统计分析
    print("\n📊 7. 邮件统计")
    stats = mail.get_statistics()
    print(f"   总邮件数: {stats['total']}")
    print(f"   未读邮件: {stats['unread']}")
    
    print("\n" + "="*60)
    print("演示完成！所有邮件功能已就绪")
    print("="*60)
