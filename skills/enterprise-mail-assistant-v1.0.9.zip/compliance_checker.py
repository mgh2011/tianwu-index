#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级合规检查系统 v5.1.0
包含：合规规则引擎、审计追踪器、合规报告生成
"""

import json
import hashlib
import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import re


class ComplianceFramework(Enum):
    """合规框架"""
    ISO27001 = "iso27001"
    GDPR = "gdpr"
    PCI_DSS = "pci_dss"
    HIPAA = "hipaa"
    SOC2 = "soc2"
    NIST = "nist"
    CUSTOM = "custom"


class ComplianceStatus(Enum):
    """合规状态"""
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    PARTIALLY_COMPLIANT = "partially_compliant"
    NOT_APPLICABLE = "not_applicable"
    NOT_ASSESSED = "not_assessed"


class ViolationSeverity(Enum):
    """违规严重程度"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class ComplianceRule:
    """合规规则"""
    rule_id: str
    framework: ComplianceFramework
    control_id: str
    title: str
    description: str
    severity: ViolationSeverity
    check_function: str  # 检查函数名
    remediation: str
    references: List[str] = field(default_factory=list)


@dataclass
class Violation:
    """违规记录"""
    violation_id: str
    rule_id: str
    severity: ViolationSeverity
    description: str
    affected_resource: str
    detected_at: str
    remediation: str
    status: str = "open"  # open, in_progress, resolved, accepted


@dataclass
class AuditRecord:
    """审计记录"""
    record_id: str
    action: str
    actor: str
    resource: str
    result: str
    timestamp: str
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComplianceReport:
    """合规报告"""
    framework: ComplianceFramework
    assessment_date: str
    overall_status: ComplianceStatus
    compliance_score: float
    total_rules: int
    compliant_count: int
    non_compliant_count: int
    violations: List[Violation]
    recommendations: List[str]


class ComplianceRuleEngine:
    """合规规则引擎"""
    
    def __init__(self):
        self.rules: Dict[str, ComplianceRule] = {}
        self.violations: List[Violation] = []
        self.assessment_history: List[ComplianceReport] = []
        
        # 初始化内置规则
        self._init_default_rules()
    
    def _init_default_rules(self):
        """初始化默认规则"""
        # ISO27001 规则
        self.add_rule(ComplianceRule(
            rule_id="ISO-001",
            framework=ComplianceFramework.ISO27001,
            control_id="A.9.4.1",
            title="访问控制策略",
            description="必须实施访问控制策略，限制对信息和信息处理设施的访问",
            severity=ViolationSeverity.HIGH,
            check_function="check_access_control",
            remediation="实施基于角色的访问控制(RBAC)，定期审查访问权限"
        ))
        
        self.add_rule(ComplianceRule(
            rule_id="ISO-002",
            framework=ComplianceFramework.ISO27001,
            control_id="A.10.1.1",
            title="加密控制",
            description="敏感信息必须使用加密技术进行保护",
            severity=ViolationSeverity.HIGH,
            check_function="check_encryption",
            remediation="对敏感数据实施AES-256加密，传输使用TLS 1.2+"
        ))
        
        self.add_rule(ComplianceRule(
            rule_id="ISO-003",
            framework=ComplianceFramework.ISO27001,
            control_id="A.12.3.1",
            title="信息备份",
            description="必须按照商定的备份策略备份信息、软件和系统映像",
            severity=ViolationSeverity.MEDIUM,
            check_function="check_backup",
            remediation="实施每日增量备份和每周全量备份，异地存储"
        ))
        
        # GDPR 规则
        self.add_rule(ComplianceRule(
            rule_id="GDPR-001",
            framework=ComplianceFramework.GDPR,
            control_id="Art.5(1)(f)",
            title="数据安全原则",
            description="个人数据必须以安全方式处理，防止未经授权的处理",
            severity=ViolationSeverity.CRITICAL,
            check_function="check_data_security",
            remediation="实施技术措施保护个人数据，包括加密和访问控制"
        ))
        
        self.add_rule(ComplianceRule(
            rule_id="GDPR-002",
            framework=ComplianceFramework.GDPR,
            control_id="Art.17",
            title="被遗忘权",
            description="数据主体有权要求删除其个人数据",
            severity=ViolationSeverity.HIGH,
            check_function="check_data_deletion",
            remediation="建立数据删除流程，确保可在30天内完成删除请求"
        ))
        
        # PCI-DSS 规则
        self.add_rule(ComplianceRule(
            rule_id="PCI-001",
            framework=ComplianceFramework.PCI_DSS,
            control_id="3.4",
            title="持卡人数据保护",
            description="必须使用强加密保护存储的持卡人数据",
            severity=ViolationSeverity.CRITICAL,
            check_function="check_card_data_protection",
            remediation="使用AES-256加密所有持卡人数据，安全存储密钥"
        ))
    
    def add_rule(self, rule: ComplianceRule):
        """添加合规规则"""
        self.rules[rule.rule_id] = rule
    
    def check_compliance(self, target: Dict, frameworks: List[ComplianceFramework] = None) -> ComplianceReport:
        """
        检查合规性
        
        Args:
            target: 待检查目标，包含:
                - configurations: 配置信息
                - policies: 策略信息
                - systems: 系统信息
            frameworks: 要检查的框架列表，为空则检查所有
        
        Returns:
            合规报告
        """
        violations = []
        compliant_count = 0
        non_compliant_count = 0
        
        # 过滤要检查的规则
        rules_to_check = [
            r for r in self.rules.values()
            if frameworks is None or r.framework in frameworks
        ]
        
        for rule in rules_to_check:
            result = self._check_rule(rule, target)
            
            if result['compliant']:
                compliant_count += 1
            else:
                non_compliant_count += 1
                violations.append(Violation(
                    violation_id=f"VIO-{hashlib.md5(f'{rule.rule_id}{datetime.datetime.now().isoformat()}'.encode()).hexdigest()[:8]}",
                    rule_id=rule.rule_id,
                    severity=rule.severity,
                    description=result['reason'],
                    affected_resource=result.get('resource', 'N/A'),
                    detected_at=datetime.datetime.now().isoformat(),
                    remediation=rule.remediation
                ))
        
        # 计算合规分数
        total = len(rules_to_check)
        score = (compliant_count / total * 100) if total > 0 else 0
        
        # 确定整体状态
        if score >= 90:
            status = ComplianceStatus.COMPLIANT
        elif score >= 70:
            status = ComplianceStatus.PARTIALLY_COMPLIANT
        else:
            status = ComplianceStatus.NON_COMPLIANT
        
        # 生成建议
        recommendations = []
        critical_violations = [v for v in violations if v.severity == ViolationSeverity.CRITICAL]
        if critical_violations:
            recommendations.append(f"立即处理{len(critical_violations)}个严重违规项")
        
        high_violations = [v for v in violations if v.severity == ViolationSeverity.HIGH]
        if high_violations:
            recommendations.append(f"优先修复{len(high_violations)}个高危违规项")
        
        # 创建报告
        report = ComplianceReport(
            framework=frameworks[0] if frameworks and len(frameworks) == 1 else ComplianceFramework.CUSTOM,
            assessment_date=datetime.datetime.now().isoformat(),
            overall_status=status,
            compliance_score=score,
            total_rules=total,
            compliant_count=compliant_count,
            non_compliant_count=non_compliant_count,
            violations=violations,
            recommendations=recommendations
        )
        
        self.assessment_history.append(report)
        self.violations.extend(violations)
        
        return report
    
    def _check_rule(self, rule: ComplianceRule, target: Dict) -> Dict:
        """检查单条规则"""
        check_functions = {
            'check_access_control': self._check_access_control,
            'check_encryption': self._check_encryption,
            'check_backup': self._check_backup,
            'check_data_security': self._check_data_security,
            'check_data_deletion': self._check_data_deletion,
            'check_card_data_protection': self._check_card_data_protection
        }
        
        check_func = check_functions.get(rule.check_function)
        if check_func:
            return check_func(target)
        
        return {'compliant': True, 'reason': 'No check function defined'}
    
    def _check_access_control(self, target: Dict) -> Dict:
        """检查访问控制"""
        configs = target.get('configurations', {})
        
        # 检查是否有访问控制策略
        if not configs.get('access_control_policy'):
            return {'compliant': False, 'reason': '未找到访问控制策略文档'}
        
        # 检查是否有权限审计记录
        if not configs.get('access_audit_enabled', False):
            return {'compliant': False, 'reason': '访问审计未启用'}
        
        return {'compliant': True, 'reason': '访问控制配置符合要求'}
    
    def _check_encryption(self, target: Dict) -> Dict:
        """检查加密配置"""
        configs = target.get('configurations', {})
        
        encryption_config = configs.get('encryption', {})
        
        if not encryption_config.get('enabled', False):
            return {'compliant': False, 'reason': '加密未启用'}
        
        algorithm = encryption_config.get('algorithm', '')
        if 'AES' not in algorithm and 'RSA' not in algorithm:
            return {'compliant': False, 'reason': f'加密算法不符合要求: {algorithm}'}
        
        return {'compliant': True, 'reason': '加密配置符合要求'}
    
    def _check_backup(self, target: Dict) -> Dict:
        """检查备份配置"""
        configs = target.get('configurations', {})
        
        backup_config = configs.get('backup', {})
        
        if not backup_config.get('enabled', False):
            return {'compliant': False, 'reason': '备份未配置'}
        
        # 检查备份频率
        frequency = backup_config.get('frequency', '')
        if frequency not in ['daily', 'weekly']:
            return {'compliant': False, 'reason': f'备份频率不符合要求: {frequency}'}
        
        return {'compliant': True, 'reason': '备份配置符合要求'}
    
    def _check_data_security(self, target: Dict) -> Dict:
        """检查数据安全"""
        return self._check_encryption(target)
    
    def _check_data_deletion(self, target: Dict) -> Dict:
        """检查数据删除流程"""
        policies = target.get('policies', {})
        
        if not policies.get('data_retention_policy'):
            return {'compliant': False, 'reason': '未找到数据保留策略'}
        
        if not policies.get('deletion_procedure'):
            return {'compliant': False, 'reason': '未建立数据删除流程'}
        
        return {'compliant': True, 'reason': '数据删除流程已建立'}
    
    def _check_card_data_protection(self, target: Dict) -> Dict:
        """检查持卡人数据保护"""
        systems = target.get('systems', {})
        
        # 检查是否有存储持卡人数据
        if systems.get('stores_card_data', False):
            configs = target.get('configurations', {})
            encryption = configs.get('encryption', {})
            
            if not encryption.get('enabled'):
                return {'compliant': False, 'reason': '持卡人数据未加密存储', 'resource': 'card_data_storage'}
            
            if encryption.get('algorithm') not in ['AES-256', 'AES-256-GCM']:
                return {'compliant': False, 'reason': f'加密算法不符合PCI-DSS: {encryption.get("algorithm")}'}
        
        return {'compliant': True, 'reason': '持卡人数据保护符合要求'}
    
    def get_violations(self, severity: ViolationSeverity = None, status: str = None) -> List[Violation]:
        """获取违规列表"""
        violations = self.violations
        
        if severity:
            violations = [v for v in violations if v.severity == severity]
        
        if status:
            violations = [v for v in violations if v.status == status]
        
        return violations
    
    def generate_report(self, framework: ComplianceFramework = None, format: str = 'json') -> str:
        """生成合规报告"""
        reports = self.assessment_history
        
        if framework:
            reports = [r for r in reports if r.framework == framework]
        
        if not reports:
            return "{}"
        
        latest = reports[-1]
        
        if format == 'json':
            return json.dumps({
                'framework': latest.framework.value,
                'assessment_date': latest.assessment_date,
                'overall_status': latest.overall_status.value,
                'compliance_score': latest.compliance_score,
                'summary': {
                    'total_rules': latest.total_rules,
                    'compliant': latest.compliant_count,
                    'non_compliant': latest.non_compliant_count
                },
                'violations': [
                    {
                        'id': v.violation_id,
                        'rule': v.rule_id,
                        'severity': v.severity.value,
                        'description': v.description
                    }
                    for v in latest.violations
                ],
                'recommendations': latest.recommendations
            }, indent=2, ensure_ascii=False)
        
        elif format == 'markdown':
            lines = [
                f"# 合规检查报告",
                f"",
                f"**框架**: {latest.framework.value}",
                f"**检查日期**: {latest.assessment_date}",
                f"**合规状态**: {latest.overall_status.value}",
                f"**合规分数**: {latest.compliance_score:.1f}%",
                f"",
                f"## 检查摘要",
                f"",
                f"- 总规则数: {latest.total_rules}",
                f"- 符合数: {latest.compliant_count}",
                f"- 不符合数: {latest.non_compliant_count}",
                f"",
                f"## 违规项",
                f""
            ]
            
            for v in latest.violations:
                lines.append(f"### {v.violation_id} ({v.severity.value})")
                lines.append(f"- 描述: {v.description}")
                lines.append(f"- 修复建议: {v.remediation}")
                lines.append(f"")
            
            return '\n'.join(lines)
        
        return ""


class AuditTrailTracker:
    """审计追踪器"""
    
    def __init__(self):
        self.audit_records: List[AuditRecord] = []
        self.change_log: List[Dict] = []
    
    def record_action(self, action: str, actor: str, resource: str, 
                     result: str, ip_address: str = None,
                     user_agent: str = None, details: Dict = None) -> AuditRecord:
        """记录操作"""
        record_id = hashlib.md5(f"{action}{actor}{datetime.datetime.now().isoformat()}".encode()).hexdigest()[:12]
        
        record = AuditRecord(
            record_id=record_id,
            action=action,
            actor=actor,
            resource=resource,
            result=result,
            timestamp=datetime.datetime.now().isoformat(),
            ip_address=ip_address,
            user_agent=user_agent,
            details=details or {}
        )
        
        self.audit_records.append(record)
        
        # 保持最近10000条记录
        if len(self.audit_records) > 10000:
            self.audit_records = self.audit_records[-5000:]
        
        return record
    
    def record_change(self, resource: str, field: str, old_value: Any, 
                     new_value: Any, changed_by: str, reason: str = None):
        """记录变更"""
        self.change_log.append({
            'change_id': hashlib.md5(f"{resource}{field}{datetime.datetime.now().isoformat()}".encode()).hexdigest()[:12],
            'resource': resource,
            'field': field,
            'old_value': str(old_value),
            'new_value': str(new_value),
            'changed_by': changed_by,
            'reason': reason,
            'timestamp': datetime.datetime.now().isoformat()
        })
    
    def query_trail(self, filters: Dict) -> List[AuditRecord]:
        """查询审计记录"""
        results = self.audit_records
        
        if filters.get('action'):
            results = [r for r in results if r.action == filters['action']]
        
        if filters.get('actor'):
            results = [r for r in results if r.actor == filters['actor']]
        
        if filters.get('resource'):
            results = [r for r in results if filters['resource'] in r.resource]
        
        if filters.get('start_time'):
            results = [r for r in results if r.timestamp >= filters['start_time']]
        
        if filters.get('end_time'):
            results = [r for r in results if r.timestamp <= filters['end_time']]
        
        return results
    
    def export_audit_log(self, start: str, end: str, format: str = 'json') -> str:
        """导出审计日志"""
        records = [
            r for r in self.audit_records
            if start <= r.timestamp <= end
        ]
        
        if format == 'json':
            return json.dumps([
                {
                    'record_id': r.record_id,
                    'action': r.action,
                    'actor': r.actor,
                    'resource': r.resource,
                    'result': r.result,
                    'timestamp': r.timestamp,
                    'ip_address': r.ip_address,
                    'details': r.details
                }
                for r in records
            ], indent=2, ensure_ascii=False)
        
        elif format == 'csv':
            lines = ['record_id,action,actor,resource,result,timestamp']
            lines.extend(f"{r.record_id},{r.action},{r.actor},{r.resource},{r.result},{r.timestamp}" for r in records)
            return '\n'.join(lines)
        
        return ""
    
    def get_user_activity_report(self, actor: str, days: int = 7) -> Dict:
        """获取用户活动报告"""
        start = (datetime.datetime.now() - datetime.timedelta(days=days)).isoformat()
        
        user_records = [r for r in self.audit_records if r.actor == actor and r.timestamp >= start]
        
        action_counts = defaultdict(int)
        for r in user_records:
            action_counts[r.action] += 1
        
        return {
            'actor': actor,
            'period': f'{days} days',
            'total_actions': len(user_records),
            'by_action': dict(action_counts),
            'last_activity': user_records[-1].timestamp if user_records else None
        }


if __name__ == '__main__':
    print("=" * 60)
    print("合规检查系统演示")
    print("=" * 60)
    
    # 合规检查
    engine = ComplianceRuleEngine()
    
    # 检查目标
    target = {
        'configurations': {
            'access_control_policy': True,
            'access_audit_enabled': True,
            'encryption': {
                'enabled': True,
                'algorithm': 'AES-256'
            },
            'backup': {
                'enabled': True,
                'frequency': 'daily'
            }
        },
        'policies': {
            'data_retention_policy': True,
            'deletion_procedure': True
        },
        'systems': {
            'stores_card_data': False
        }
    }
    
    # 执行检查
    report = engine.check_compliance(target, [ComplianceFramework.ISO27001, ComplianceFramework.GDPR])
    
    print(f"\n合规检查报告:")
    print(f"  整体状态: {report.overall_status.value}")
    print(f"  合规分数: {report.compliance_score:.1f}%")
    print(f"  符合规则: {report.compliant_count}/{report.total_rules}")
    
    if report.violations:
        print(f"\n违规项 ({len(report.violations)}个):")
        for v in report.violations[:5]:
            print(f"  - {v.violation_id}: {v.description} ({v.severity.value})")
    
    # 审计追踪
    tracker = AuditTrailTracker()
    
    tracker.record_action('login', 'admin', 'system', 'success', ip_address='192.168.1.100')
    tracker.record_action('config_change', 'admin', 'firewall', 'success')
    tracker.record_change('firewall', 'rules', 'old_rules', 'new_rules', 'admin', '安全更新')
    
    activities = tracker.get_user_activity_report('admin')
    print(f"\n用户活动报告:")
    print(f"  用户: {activities['actor']}")
    print(f"  总操作数: {activities['total_actions']}")
    
    print("\n" + "=" * 60)
