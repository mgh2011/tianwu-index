# 故障排查指南 (Troubleshooting Guide)

## 📋 目录
- [常见错误及解决方案](#常见错误及解决方案)
- [错误代码对照表](#错误代码对照表)
- [调试技巧](#调试技巧)
- [性能优化建议](#性能优化建议)
- [常见问题 FAQ](#常见问题-faq)

---

## 🚨 常见错误及解决方案

### 1. 配置错误

#### 错误: `ConfigError: 配置文件不存在`
```
❌ 错误提示: ConfigError: 配置文件 ./config/settings.yaml 不存在
```

**原因**: 首次使用未初始化配置文件

**解决方案**:
```python
# 方法1: 运行快速启动脚本自动生成配置
python quick_start.py

# 方法2: 手动创建配置文件
from config.settings import Settings
settings = Settings()
settings.save_to_file('./config/settings.yaml')
```

---

#### 错误: `ConfigError: 无效的配置值`
```
❌ 错误提示: ConfigError: security_level 必须是 'low', 'medium', 'high' 之一，当前值: ultra
```

**原因**: 配置项值不在允许范围内

**解决方案**:
```python
# 检查配置文件中 security_level 的值
# 修改为有效值: low, medium, high
security_level: medium
```

---

### 2. 邮件处理错误

#### 错误: `MailProcessingError: 无法解析邮件格式`
```
❌ 错误提示: MailProcessingError: 邮件格式不支持，仅支持 JSON/YAML/Text 格式
```

**原因**: 邮件数据格式不正确

**解决方案**:
```python
# 确保邮件数据是有效的 JSON 格式
{
  "from": "sender@example.com",
  "to": "recipient@example.com",
  "subject": "测试邮件",
  "body": "邮件内容",
  "timestamp": "2026-04-09T17:00:00"
}
```

---

#### 错误: `ClassificationError: 分类规则不完整`
```
❌ 错误提示: ClassificationError: 缺少必要的分类规则: categories 或 rules
```

**原因**: 分类配置缺失必要字段

**解决方案**:
```python
# 确保分类配置包含必要字段
classification_config = {
    "categories": ["工作", "个人", "促销", "垃圾邮件"],
    "rules": {
        "工作": ["@company.com", "会议", "报告", "项目"],
        "个人": ["家人", "朋友", "@gmail.com"],
        "促销": ["优惠", "折扣", "促销"],
        "垃圾邮件": ["中奖", "免费", "点击领取"]
    }
}
```

---

### 3. 安全检测错误

#### 错误: `SecurityCheckError: 威胁签名库过期`
```
❌ 错误提示: SecurityCheckError: 威胁签名库已过期 (上次更新: 2025-01-01)
```

**原因**: 本地威胁数据库过期

**解决方案**:
```python
# 方法1: 使用内置的更新功能（离线）
from scripts.security.logging.audit_system import AuditSystem
audit = AuditSystem()
audit.update_local_threat_db()

# 方法2: 重新下载最新的威胁样本
# 参考 test_data/threat_samples.json 更新本地库
```

---

### 4. 备份恢复错误

#### 错误: `BackupError: 备份文件损坏`
```
❌ 错误提示: BackupError: 无法读取备份文件，文件可能已损坏
```

**原因**: 备份文件不完整或损坏

**解决方案**:
```python
# 1. 检查备份文件完整性
import json
try:
    with open('backup.json', 'r') as f:
        data = json.load(f)
    print("✅ 备份文件完整")
except json.JSONDecodeError:
    print("❌ 备份文件损坏，需要重新备份")

# 2. 查找最近的完整备份
# 备份文件命名格式: backup_YYYYMMDD_HHMMSS.json
```

---

### 5. 自动化脚本错误

#### 错误: `AutomationError: 脚本执行超时`
```
❌ 错误提示: AutomationError: 脚本执行超时 (超过 300 秒)
```

**原因**: 脚本执行时间过长

**解决方案**:
```python
# 方法1: 增加超时时间
python cli.py --timeout 600

# 方法2: 分批处理大数据
# 将大数据集分割成小批次处理
batch_size = 100
for i in range(0, len(data), batch_size):
    batch = data[i:i+batch_size]
    process_batch(batch)
```

---

## 📊 错误代码对照表

| 错误代码 | 错误类型 | 说明 | 解决方案 |
|---------|---------|------|---------|
| E001 | ConfigError | 配置文件不存在 | 运行 quick_start.py 初始化 |
| E002 | ConfigError | 配置值无效 | 检查配置项取值范围 |
| E003 | MailProcessingError | 邮件格式错误 | 使用 JSON/YAML 格式 |
| E004 | ClassificationError | 分类规则缺失 | 补充 categories 和 rules |
| E005 | SecurityCheckError | 威胁库过期 | 更新本地威胁数据库 |
| E006 | BackupError | 备份文件损坏 | 重新创建备份 |
| E007 | AutomationError | 脚本执行超时 | 增加超时时间或分批处理 |
| E008 | ImportError | 依赖缺失 | 运行 install_dependencies.py |
| E009 | PermissionError | 权限不足 | 检查文件读写权限 |
| E010 | ValidationError | 数据验证失败 | 检查数据格式和约束 |

---

## 🔧 调试技巧

### 1. 启用详细日志

```python
# 在脚本开头添加日志配置
import logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='debug.log'
)

# 或者使用 CLI 启用调试模式
python cli.py --debug --verbose
```

### 2. 使用断点调试

```python
# 在关键位置添加断点
import pdb; pdb.set_trace()

# 或者使用更友好的 ipdb
# pip install ipdb
import ipdb; ipdb.set_trace()
```

### 3. 检查中间结果

```python
# 打印中间变量
print(f"[DEBUG] 当前处理邮件数量: {len(emails)}")
print(f"[DEBUG] 分类结果: {classification_result}")

# 保存中间结果到文件
import json
with open('debug_output.json', 'w') as f:
    json.dump(intermediate_result, f, indent=2, ensure_ascii=False)
```

### 4. 性能分析

```python
# 使用 timeit 测量执行时间
import time

start = time.time()
# 你的代码
end = time.time()
print(f"执行时间: {end - start:.2f} 秒")

# 使用 cProfile 进行性能分析
import cProfile
cProfile.run('your_function()')
```

---

## ⚡ 性能优化建议

### 1. 批量处理优化

```python
# ❌ 低效: 逐个处理
for email in emails:
    process_email(email)

# ✅ 高效: 批量处理
batch_size = 100
for i in range(0, len(emails), batch_size):
    batch = emails[i:i+batch_size]
    process_batch(batch)
```

### 2. 缓存优化

```python
# 使用缓存避免重复计算
from functools import lru_cache

@lru_cache(maxsize=1000)
def classify_email_cached(content_hash):
    # 只对相同内容计算一次
    return classify_email(content)
```

### 3. 异步处理

```python
# 使用异步提高并发性能
import asyncio

async def process_emails_async(emails):
    tasks = [process_single_email(email) for email in emails]
    results = await asyncio.gather(*tasks)
    return results

# 运行
asyncio.run(process_emails_async(emails))
```

---

## ❓ 常见问题 FAQ

### Q1: 如何检查技能是否正确安装？

```bash
# 运行快速测试
python quick_start.py --test

# 或者检查演示脚本
python demos/demo_mail_classification.py --check
```

### Q2: 支持哪些邮件格式？

```
支持的格式:
✅ JSON (.json)
✅ YAML (.yaml, .yml)
✅ 纯文本 (.txt)
❌ EML (.eml) - 需要转换
❌ MSG (.msg) - 需要转换
```

### Q3: 如何自定义分类规则？

```python
# 编辑 config/settings.yaml
classification:
  categories:
    - "自定义分类1"
    - "自定义分类2"
  rules:
    "自定义分类1":
      - "关键词1"
      - "关键词2"
```

### Q4: 如何查看安全检测日志？

```bash
# 查看最近的安全检测日志
cat logs/security_check.log

# 或者使用 CLI
python cli.py --show-logs security
```

### Q5: 如何恢复误删的邮件？

```python
# 从备份恢复
from demos.demo_backup_restore import BackupManager

backup = BackupManager()
backup.restore('backup_20260409_170000.json', target_folder='recovered')
```

---

## 📞 获取帮助

如果以上方法都无法解决您的问题：

1. **查看文档**: 阅读 [QUICKSTART.md](QUICKSTART.md) 和 [EXAMPLES.md](EXAMPLES.md)
2. **检查日志**: 查看 `logs/` 目录下的日志文件
3. **提交问题**: 在虾评平台技能页面留言反馈
4. **联系作者**: 在 Agent World 或 InStreet 平台联系 @comma-dot

---

*最后更新: 2026-04-09*
