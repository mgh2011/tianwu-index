"""
企业级智能邮件助手 - 邮件队列与通知模块
Enterprise Mail Assistant - Mail Queue & Notification Module

包含队列管理、通知系统、线程管理等功能
"""

import json
import time
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from queue import PriorityQueue
import threading


# ==================== 邮件队列系统 ====================

class QueuePriority(Enum):
    """队列优先级"""
    URGENT = 1      # 紧急
    HIGH = 2        # 高
    NORMAL = 3      # 普通
    LOW = 4         # 低
    BATCH = 5       # 批量


@dataclass
class QueueItem:
    """队列项"""
    item_id: str
    email_id: str
    action: str  # send, retry, forward, reply
    priority: QueuePriority
    data: Dict
    created_at: datetime = field(default_factory=datetime.now)
    attempts: int = 0
    max_attempts: int = 3
    last_error: Optional[str] = None


class MailQueue:
    """邮件队列管理器"""
    
    def __init__(self):
        self.queue: PriorityQueue = PriorityQueue()
        self.processing: Dict[str, QueueItem] = {}
        self.completed: List[QueueItem] = []
        self.failed: List[QueueItem] = []
        self.handlers: Dict[str, Callable] = {}
        self.queue_stats = {
            "total_processed": 0,
            "total_failed": 0,
            "total_retries": 0
        }
    
    def enqueue(self, email_id: str, action: str, data: Dict,
                priority: QueuePriority = QueuePriority.NORMAL) -> Dict:
        """加入队列"""
        item_id = f"qi_{hashlib.md5(f'{email_id}{time.time()}'.encode()).hexdigest()[:8]}"
        
        item = QueueItem(
            item_id=item_id,
            email_id=email_id,
            action=action,
            priority=priority,
            data=data
        )
        
        self.queue.put((priority.value, item))
        
        return {
            "success": True,
            "item_id": item_id,
            "queue_position": self.queue.qsize(),
            "estimated_wait": f"{self.queue.qsize() * 2}秒"
        }
    
    def dequeue(self) -> Optional[QueueItem]:
        """出队"""
        if not self.queue.empty():
            priority, item = self.queue.get()
            self.processing[item.item_id] = item
            return item
        return None
    
    def complete(self, item_id: str) -> Dict:
        """完成处理"""
        if item_id in self.processing:
            item = self.processing.pop(item_id)
            self.completed.append(item)
            self.queue_stats["total_processed"] += 1
            
            return {"success": True, "item_id": item_id}
        return {"success": False}
    
    def fail(self, item_id: str, error: str, retry: bool = True) -> Dict:
        """处理失败"""
        if item_id in self.processing:
            item = self.processing[item_id]
            item.last_error = error
            item.attempts += 1
            
            if retry and item.attempts < item.max_attempts:
                # 重新入队
                self.queue.put((item.priority.value + 1, item))
                self.queue_stats["total_retries"] += 1
                del self.processing[item_id]
                return {"success": True, "retried": True, "attempt": item.attempts}
            else:
                # 彻底失败
                self.failed.append(item)
                del self.processing[item_id]
                self.queue_stats["total_failed"] += 1
                return {"success": True, "retried": False, "error": error}
        
        return {"success": False}
    
    def get_queue_status(self) -> Dict:
        """获取队列状态"""
        return {
            "waiting": self.queue.qsize(),
            "processing": len(self.processing),
            "completed": len(self.completed),
            "failed": len(self.failed),
            "stats": self.queue_stats
        }
    
    def quarantine_email(self, email_id: str, reason: str = "") -> Dict[str, Any]:
        """
        隔离邮件
        
        Args:
            email_id: 邮件ID
            reason: 隔离原因
        
        Returns:
            操作结果
        """
        quarantine_id = f"q_{hashlib.md5(f'{email_id}{time.time()}'.encode()).hexdigest()[:8]}"
        
        # 添加到隔离队列
        item = QueueItem(
            item_id=quarantine_id,
            email_id=email_id,
            action='quarantine',
            priority=QueuePriority.HIGH,
            data={'reason': reason, 'quarantine_time': datetime.now().isoformat()}
        )
        
        self.queue.put((QueuePriority.HIGH.value, item))
        
        return {
            "success": True,
            "quarantine_id": quarantine_id,
            "email_id": email_id,
            "reason": reason,
            "message": f"邮件 {email_id} 已隔离"
        }
    
    def get_queue_length(self) -> int:
        """获取队列长度"""
        return self.queue.qsize()
    
    def register_handler(self, action: str, handler: Callable) -> None:
        """注册处理器"""
        self.handlers[action] = handler
    
    def process_next(self) -> Dict:
        """处理下一个"""
        item = self.dequeue()
        if not item:
            return {"success": False, "message": "队列为空"}
        
        if item.action in self.handlers:
            try:
                result = self.handlers[item.action](item)
                self.complete(item.item_id)
                return {"success": True, "result": result}
            except Exception as e:
                return self.fail(item.item_id, str(e))
        
        return {"success": False, "message": "未找到处理器"}


# ==================== 邮件通知系统 ====================

class NotificationType(Enum):
    """通知类型"""
    NEW_EMAIL = "new_email"
    REMINDER = "reminder"
    APPROVAL_REQUEST = "approval_request"
    MENTION = "mention"
    SYSTEM = "system"
    ALERT = "alert"


@dataclass
class Notification:
    """通知"""
    notification_id: str
    notification_type: NotificationType
    title: str
    message: str
    user_id: str
    email_id: Optional[str] = None
    read: bool = False
    created_at: datetime = field(default_factory=datetime.now)
    action_url: Optional[str] = None
    priority: str = "normal"


class NotificationSystem:
    """通知系统"""
    
    def __init__(self):
        self.notifications: Dict[str, List[Notification]] = {}
        self.notification_rules: List[Dict] = []
        self.dnd_schedules: Dict[str, Dict] = {}
    
    def send_notification(self, user_id: str, notification_type: NotificationType,
                          title: str, message: str, email_id: str = None,
                          priority: str = "normal") -> Dict:
        """发送通知"""
        # 检查免打扰
        if self._is_dnd_active(user_id):
            if priority != "urgent":
                return {"success": False, "message": "免打扰模式中"}
        
        notification_id = f"notif_{hashlib.md5(f'{user_id}{time.time()}'.encode()).hexdigest()[:8]}"
        
        notification = Notification(
            notification_id=notification_id,
            notification_type=notification_type,
            title=title,
            message=message,
            user_id=user_id,
            email_id=email_id,
            priority=priority
        )
        
        if user_id not in self.notifications:
            self.notifications[user_id] = []
        self.notifications[user_id].append(notification)
        
        return {
            "success": True,
            "notification_id": notification_id,
            "sent_at": datetime.now().isoformat()
        }
    
    def get_notifications(self, user_id: str, unread_only: bool = False) -> List[Dict]:
        """获取通知列表"""
        if user_id not in self.notifications:
            return []
        
        notifications = self.notifications[user_id]
        
        if unread_only:
            notifications = [n for n in notifications if not n.read]
        
        return [{
            "id": n.notification_id,
            "type": n.notification_type.value,
            "title": n.title,
            "message": n.message,
            "read": n.read,
            "created_at": n.created_at.isoformat(),
            "email_id": n.email_id
        } for n in notifications]
    
    def mark_as_read(self, notification_id: str, user_id: str) -> Dict:
        """标记已读"""
        if user_id in self.notifications:
            for n in self.notifications[user_id]:
                if n.notification_id == notification_id:
                    n.read = True
                    return {"success": True}
        return {"success": False}
    
    def mark_all_read(self, user_id: str) -> Dict:
        """全部标记已读"""
        if user_id in self.notifications:
            for n in self.notifications[user_id]:
                n.read = True
            return {"success": True, "count": len(self.notifications[user_id])}
        return {"success": False}
    
    def set_dnd(self, user_id: str, start_time: str, end_time: str,
                allow_urgent: bool = True) -> Dict:
        """设置免打扰"""
        self.dnd_schedules[user_id] = {
            "start": start_time,  # "22:00"
            "end": end_time,      # "08:00"
            "allow_urgent": allow_urgent
        }
        return {"success": True, "dnd": self.dnd_schedules[user_id]}
    
    def _is_dnd_active(self, user_id: str) -> bool:
        """检查是否在免打扰时段"""
        if user_id not in self.dnd_schedules:
            return False
        
        dnd = self.dnd_schedules[user_id]
        now = datetime.now().strftime("%H:%M")
        
        start = dnd['start']
        end = dnd['end']
        
        if start < end:
            return start <= now < end
        else:  # 跨午夜
            return now >= start or now < end
    
    def create_notification_rule(self, user_id: str, conditions: Dict,
                                  actions: Dict) -> Dict:
        """创建通知规则"""
        rule = {
            "id": hashlib.md5(f"{user_id}{time.time()}".encode()).hexdigest()[:8],
            "user_id": user_id,
            "conditions": conditions,
            "actions": actions,
            "enabled": True
        }
        self.notification_rules.append(rule)
        return {"success": True, "rule": rule}


# ==================== 邮件线程管理 ====================

@dataclass
class MailThread:
    """邮件线程"""
    thread_id: str
    subject: str
    participants: List[str]
    emails: List[str]  # email_ids
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)
    status: str = "active"  # active, resolved, closed


class ThreadManager:
    """线程管理器"""
    
    def __init__(self):
        self.threads: Dict[str, MailThread] = {}
        self.email_to_thread: Dict[str, str] = {}
    
    def create_thread(self, email_id: str, subject: str,
                      participants: List[str]) -> Dict:
        """创建线程"""
        thread_id = f"th_{hashlib.md5(f'{email_id}{time.time()}'.encode()).hexdigest()[:8]}"
        
        thread = MailThread(
            thread_id=thread_id,
            subject=subject,
            participants=participants,
            emails=[email_id]
        )
        
        self.threads[thread_id] = thread
        self.email_to_thread[email_id] = thread_id
        
        return {
            "success": True,
            "thread_id": thread_id,
            "email_count": 1
        }
    
    def add_to_thread(self, thread_id: str, email_id: str) -> Dict:
        """添加邮件到线程"""
        if thread_id not in self.threads:
            return {"success": False, "message": "线程不存在"}
        
        thread = self.threads[thread_id]
        thread.emails.append(email_id)
        thread.last_updated = datetime.now()
        self.email_to_thread[email_id] = thread_id
        
        return {
            "success": True,
            "thread_id": thread_id,
            "email_count": len(thread.emails)
        }
    
    def get_thread(self, thread_id: str) -> Optional[Dict]:
        """获取线程"""
        if thread_id in self.threads:
            thread = self.threads[thread_id]
            return {
                "thread_id": thread.thread_id,
                "subject": thread.subject,
                "participants": thread.participants,
                "email_count": len(thread.emails),
                "emails": thread.emails,
                "created_at": thread.created_at.isoformat(),
                "last_updated": thread.last_updated.isoformat(),
                "status": thread.status
            }
        return None
    
    def get_thread_by_email(self, email_id: str) -> Optional[Dict]:
        """通过邮件ID获取线程"""
        if email_id in self.email_to_thread:
            thread_id = self.email_to_thread[email_id]
            return self.get_thread(thread_id)
        return None
    
    def close_thread(self, thread_id: str) -> Dict:
        """关闭线程"""
        if thread_id in self.threads:
            self.threads[thread_id].status = "closed"
            return {"success": True}
        return {"success": False}
    
    def get_active_threads(self, user: str = None) -> List[Dict]:
        """获取活跃线程"""
        active = []
        for thread in self.threads.values():
            if thread.status == "active":
                if user is None or user in thread.participants:
                    active.append({
                        "thread_id": thread.thread_id,
                        "subject": thread.subject,
                        "last_updated": thread.last_updated.isoformat(),
                        "email_count": len(thread.emails)
                    })
        return sorted(active, key=lambda x: x['last_updated'], reverse=True)


# ==================== 邮件标签系统 ====================

class LabelManager:
    """标签管理器"""
    
    def __init__(self):
        self.labels: Dict[str, Dict] = {}
        self.email_labels: Dict[str, List[str]] = {}
        self._init_default_labels()
    
    def _init_default_labels(self):
        """初始化默认标签"""
        default_labels = [
            {"id": "important", "name": "重要", "color": "#FF0000"},
            {"id": "work", "name": "工作", "color": "#0000FF"},
            {"id": "personal", "name": "个人", "color": "#00FF00"},
            {"id": "todo", "name": "待办", "color": "#FFA500"},
            {"id": "later", "name": "稍后", "color": "#800080"},
        ]
        
        for label in default_labels:
            self.labels[label['id']] = label
    
    def create_label(self, name: str, color: str = "#808080") -> Dict:
        """创建标签"""
        label_id = hashlib.md5(name.encode()).hexdigest()[:8]
        
        self.labels[label_id] = {
            "id": label_id,
            "name": name,
            "color": color,
            "created_at": datetime.now().isoformat()
        }
        
        return {"success": True, "label": self.labels[label_id]}
    
    def get_labels(self) -> List[Dict]:
        """获取所有标签"""
        return list(self.labels.values())
    
    def add_label_to_email(self, email_id: str, label_id: str) -> Dict:
        """给邮件添加标签"""
        if label_id not in self.labels:
            return {"success": False, "message": "标签不存在"}
        
        if email_id not in self.email_labels:
            self.email_labels[email_id] = []
        
        if label_id not in self.email_labels[email_id]:
            self.email_labels[email_id].append(label_id)
        
        return {"success": True, "labels": self.email_labels[email_id]}
    
    def remove_label_from_email(self, email_id: str, label_id: str) -> Dict:
        """移除邮件标签"""
        if email_id in self.email_labels:
            if label_id in self.email_labels[email_id]:
                self.email_labels[email_id].remove(label_id)
                return {"success": True}
        return {"success": False}
    
    def get_emails_by_label(self, label_id: str) -> List[str]:
        """获取标签下的所有邮件"""
        return [email_id for email_id, labels in self.email_labels.items()
                if label_id in labels]
    
    def delete_label(self, label_id: str) -> Dict:
        """删除标签"""
        if label_id in self.labels:
            del self.labels[label_id]
            
            # 从所有邮件中移除
            for email_id in self.email_labels:
                if label_id in self.email_labels[email_id]:
                    self.email_labels[email_id].remove(label_id)
            
            return {"success": True}
        return {"success": False}


# ==================== 使用示例 ====================

if __name__ == "__main__":
    print("="*60)
    print("邮件队列与通知功能演示")
    print("="*60)
    
    # 1. 队列系统
    print("\n📬 1. 邮件队列")
    queue = MailQueue()
    result = queue.enqueue("mail_001", "send", {"to": "test@example.com"})
    print(f"   入队结果: {result}")
    print(f"   队列状态: {queue.get_queue_status()}")
    
    # 2. 通知系统
    print("\n🔔 2. 通知系统")
    notif = NotificationSystem()
    result = notif.send_notification(
        "user_001", NotificationType.NEW_EMAIL,
        "新邮件", "您有一封新邮件"
    )
    print(f"   发送通知: {result}")
    print(f"   通知列表: {len(notif.get_notifications('user_001'))} 条")
    
    # 3. 线程管理
    print("\n🧵 3. 邮件线程")
    thread_mgr = ThreadManager()
    result = thread_mgr.create_thread("mail_001", "项目讨论", ["张三", "李四"])
    print(f"   创建线程: {result}")
    
    # 4. 标签系统
    print("\n🏷️ 4. 标签系统")
    label_mgr = LabelManager()
    labels = label_mgr.get_labels()
    print(f"   默认标签: {len(labels)} 个")
    label_mgr.add_label_to_email("mail_001", "important")
    print(f"   邮件标签: {label_mgr.email_labels.get('mail_001', [])}")
    
    print("\n" + "="*60)
    print("队列与通知功能演示完成！")
    print("="*60)
