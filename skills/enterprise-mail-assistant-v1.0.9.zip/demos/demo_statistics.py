#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统计报告演示
邮件数据统计分析

功能：
- 收发统计
- 分类统计
- 安全统计
- 可视化报告
"""

import time
import json
from datetime import datetime, timedelta
from collections import Counter

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class MailStatistics:
    """邮件统计"""
    
    def __init__(self):
        self.data = self._load_demo_data()
    
    def _load_demo_data(self):
        """加载演示数据"""
        try:
            with open("test_data/sample_emails.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            # 如果文件不存在，使用内置数据
            return [
                {"subject": "财务报告", "category": "财务", "is_read": True},
                {"subject": "会议邀请", "category": "会议", "is_read": False},
                {"subject": "促销", "category": "推广", "is_read": True},
                {"subject": "安全警告", "category": "安全", "is_read": False},
                {"subject": "周报", "category": "工作", "is_read": True},
            ]
    
    def get_overview(self):
        """获取概览统计"""
        total = len(self.data)
        read = sum(1 for e in self.data if e.get("is_read", False))
        unread = total - read
        
        return {
            "total": total,
            "read": read,
            "unread": unread,
            "read_rate": read / total * 100 if total > 0 else 0
        }
    
    def get_category_stats(self):
        """获取分类统计"""
        categories = [e.get("category", "未分类") for e in self.data]
        counter = Counter(categories)
        total = len(categories)
        
        result = []
        for cat, count in counter.most_common():
            result.append({
                "category": cat,
                "count": count,
                "percentage": count / total * 100 if total > 0 else 0
            })
        
        return result
    
    def get_daily_stats(self, days=7):
        """获取每日统计"""
        stats = []
        now = datetime.now()
        
        for i in range(days):
            date = (now - timedelta(days=i)).strftime("%m-%d")
            received = 10 + i * 3 + (i % 3) * 5  # 模拟数据
            sent = 5 + i * 2
            
            stats.append({
                "date": date,
                "received": received,
                "sent": sent
            })
        
        return list(reversed(stats))

def print_overview(stats):
    """打印概览"""
    print(f"""
{Colors.CYAN}{'═'*50}{Colors.ENDC}
{Colors.BOLD}📊 邮件统计概览{Colors.ENDC}
{'═'*50}

{Colors.GREEN}📬 总收件: {stats['total']} 封{Colors.ENDC}
   ✓ 已读: {stats['read']} 封
   ✗ 未读: {stats['unread']} 封
   📈 阅读率: {stats['read_rate']:.1f}%
    """)

def print_category_stats(stats):
    """打印分类统计"""
    print(f"{Colors.CYAN}{'─'*50}{Colors.ENDC}")
    print(f"{Colors.BOLD}📂 分类分布{Colors.ENDC}\n")
    
    icons = {
        "工作": "📁", "会议": "📅", "财务": "💰", "安全": "🔒",
        "推广": "📢", "个人": "👤", "新闻": "📰", "垃圾": "🚫"
    }
    
    max_count = max(s["count"] for s in stats) if stats else 1
    
    for s in stats:
        cat = s["category"]
        icon = icons.get(cat, "📧")
        bar_len = int(s["count"] / max_count * 20)
        bar = "█" * bar_len + "░" * (20 - bar_len)
        
        print(f"   {icon} {cat:8} {bar} {s['count']:3}封 ({s['percentage']:5.1f}%)")

def print_daily_chart(stats):
    """打印每日图表"""
    print(f"\n{Colors.CYAN}{'─'*50}{Colors.ENDC}")
    print(f"{Colors.BOLD}📈 近7天收发趋势{Colors.ENDC}\n")
    
    print(f"   日期       收件      发件")
    print(f"   {'─'*30}")
    
    for s in stats:
        received_bar = "▓" * min(s["received"] // 3, 15)
        sent_bar = "▓" * min(s["sent"] // 2, 15)
        print(f"   {s['date']}   {received_bar:15} {s['received']:3}   {sent_bar:15} {s['sent']:3}")

def print_security_summary():
    """打印安全摘要"""
    print(f"""
{Colors.CYAN}{'─'*50}{Colors.ENDC}
{Colors.BOLD}🔒 安全统计{Colors.ENDC}

   🛡️ 垃圾邮件拦截: 89 封
   🚨 威胁邮件拦截: 3 封
   ✅ 安全检测通过: 97.8%
   📧 钓鱼攻击检测: 2 次 (已拦截)
    """)

def main():
    print(f"""
{Colors.CYAN}╔════════════════════════════════════════════════════════════╗
║    📊 企业级智能邮件助手 - 统计报告演示            ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)
    
    stats = MailStatistics()
    
    # 模拟加载
    print(f"{Colors.YELLOW}正在分析邮件数据...{Colors.ENDC}\n")
    time.sleep(0.5)
    
    # 概览
    overview = stats.get_overview()
    print_overview(overview)
    
    # 分类统计
    category_stats = stats.get_category_stats()
    print_category_stats(category_stats)
    
    # 每日趋势
    daily_stats = stats.get_daily_stats(7)
    print_daily_chart(daily_stats)
    
    # 安全摘要
    print_security_summary()
    
    # 导出选项
    print(f"""
{Colors.CYAN}{'═'*50}{Colors.ENDC}

{Colors.GREEN}✅ 统计报告生成完成！{Colors.ENDC}

您可以：
1. 查看详细的统计图表
2. 导出PDF报告
3. 设置定时统计任务
    """)

if __name__ == "__main__":
    main()
