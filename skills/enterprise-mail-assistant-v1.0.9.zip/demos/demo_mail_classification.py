#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮件分类完整演示
基于规则的智能邮件分类系统

功能：
- 关键词分类
- 发件人分类
- 主题/内容分析
- 批量分类处理
"""

import re
import time
from datetime import datetime
from typing import Dict, List, Tuple

class Colors:
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class MailCategory:
    """邮件分类定义"""
    WORK = ("工作", "📁")
    MEETING = ("会议", "📅")
    PERSONAL = ("个人", "👤")
    MARKETING = ("推广", "📢")
    SPAM = ("垃圾", "🚫")
    SECURITY = ("安全", "🔒")
    FINANCIAL = ("财务", "💰")
    UNKNOWN = ("未分类", "❓")

class MailClassifier:
    """邮件分类器"""
    
    def __init__(self):
        self.rules = {
            MailCategory.WORK: {
                "keywords": ["工作", "项目", "报告", "方案", "任务", "周报", "月报"],
                "domains": ["company.com", "enterprise.com"]
            },
            MailCategory.MEETING: {
                "keywords": ["会议", "邀请", "meeting", "时间", "地点", "参会"]
            },
            MailCategory.MARKETING: {
                "keywords": ["优惠", "促销", "打折", "限时", "免费", "折扣", "sale", "offer"]
            },
            MailCategory.SECURITY: {
                "keywords": ["安全", "警告", "威胁", "钓鱼", "异常", "security", "alert"]
            },
            MailCategory.FINANCIAL: {
                "keywords": ["发票", "账单", "付款", "财务", "报销", "invoice", "payment"]
            }
        }
        
        self.sender_map = {
            "finance@": MailCategory.FINANCIAL,
            "security-": MailCategory.SECURITY,
            "noreply@": MailCategory.WORK
        }
    
    def classify(self, email: Dict) -> Tuple[str, str, float]:
        """分类单封邮件"""
        sender = email.get("sender", "")
        subject = email.get("subject", "")
        body = email.get("body", "")
        
        scores = {}
        
        # 发件人匹配
        for pattern, cat in self.sender_map.items():
            if pattern in sender:
                scores[cat] = scores.get(cat, 0) + 1.5
        
        # 关键词匹配
        text = (subject + " " + body).lower()
        for cat, rule in self.rules.items():
            for kw in rule.get("keywords", []):
                if kw.lower() in text:
                    scores[cat] = scores.get(cat, 0) + 1
        
        if not scores:
            return MailCategory.UNKNOWN
        
        best = max(scores.items(), key=lambda x: x[1])
        cat = best[0]
        confidence = min(best[1] / 5, 1.0)
        
        return cat, cat[1], confidence
    
    def batch_classify(self, emails: List[Dict]) -> List[Dict]:
        """批量分类"""
        results = []
        for email in emails:
            cat, icon, conf = self.classify(email)
            results.append({
                "email": email,
                "category": cat[0],
                "icon": icon,
                "confidence": conf
            })
        return results

def main():
    print(f"""
{Colors.CYAN}╔════════════════════════════════════════════════════════════╗
║    📧 企业级智能邮件助手 - 邮件分类演示            ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)
    
    classifier = MailClassifier()
    
    test_emails = [
        {"subject": "【重要】2024年度财务审计报告", "sender": "finance@company.com", 
         "body": "请查收年度财务审计报告，包含Q4各项财务数据。"},
        {"subject": "会议邀请：项目启动会 - 1月20日", "sender": "manager@company.com",
         "body": "下周一上午10点召开项目启动会，地点在会议室A。"},
        {"subject": "【限时优惠】云服务器低至5折", "sender": "promo@cloud-vendor.com",
         "body": "新年优惠！购买2年送1年，限时折扣不容错过！"},
        {"subject": "【安全警告】检测到异常登录", "sender": "security-alert@company.com",
         "body": "您的账号在非常用地点登录，请立即修改密码。"}
    ]
    
    print(f"\n{Colors.YELLOW}开始分类 {len(test_emails)} 封邮件...{Colors.ENDC}\n")
    
    results = classifier.batch_classify(test_emails)
    
    for i, r in enumerate(results):
        e = r["email"]
        print(f"{Colors.BLUE}{'─'*50}{Colors.ENDC}")
        print(f"📌 {e['subject']}")
        print(f"👤 {e['sender']}")
        print(f"{Colors.GREEN}{r['icon']} 分类: {r['category']}{Colors.ENDC}")
        print(f"{Colors.YELLOW}📊 置信度: {r['confidence']*100:.0f}%{Colors.ENDC}")
        time.sleep(0.3)
    
    # 统计
    print(f"\n{Colors.CYAN}{'─'*50}{Colors.ENDC}")
    print(f"{Colors.BOLD}📊 分类统计:{Colors.ENDC}")
    
    stats = {}
    for r in results:
        cat = r["category"]
        stats[cat] = stats.get(cat, 0) + 1
    
    for cat, count in stats.items():
        print(f"   • {cat}: {count} 封")
    
    print(f"\n{Colors.GREEN}✅ 演示完成！{Colors.ENDC}")
    print(f"将此代码集成到您的邮件系统即可使用自动分类功能。")

if __name__ == "__main__":
    main()
