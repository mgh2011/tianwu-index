#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动回复生成演示
智能邮件自动回复系统

功能：
- 场景识别
- 自动生成回复
- 多种回复模板
"""

import time
from datetime import datetime
from typing import Dict, List

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class AutoReplyGenerator:
    """自动回复生成器"""
    
    def __init__(self):
        # 回复模板
        self.templates = {
            "inquiry": {
                "keywords": ["咨询", "询问", "请问", "了解一下", "想知道"],
                "template": "感谢您的咨询！{info}如有其他问题，请随时联系我们。"
            },
            "meeting": {
                "keywords": ["会议", "meeting", "时间", "地点", "参加"],
                "template": "好的，{confirmation}我会准时参加。如有变化会提前通知您。"
            },
            "task": {
                "keywords": ["任务", "处理", "完成", "工作", "安排"],
                "template": "收到，我将{action}并尽快完成。如有问题会及时反馈。"
            },
            "vacation": {
                "keywords": ["休假", "请假", "度假", "离开", "不在"],
                "template": "您好，我目前{status}，将于{return_date}返回，届时会处理您的邮件。"
            },
            "thanks": {
                "keywords": ["谢谢", "感谢", "帮忙", "感谢您"],
                "template": "不客气！很高兴能帮到您。如有需要随时联系。"
            },
            "default": {
                "keywords": [],
                "template": "感谢您的来信，我已收到，会尽快处理并回复您。"
            }
        }
    
    def generate(self, email: Dict) -> str:
        """生成自动回复"""
        subject = email.get("subject", "")
        body = email.get("body", "")
        sender = email.get("sender", "")
        text = (subject + " " + body).lower()
        
        # 识别场景
        scene = self._detect_scene(text)
        
        # 获取模板
        template = self.templates.get(scene, self.templates["default"])
        
        # 填充变量
        reply = self._fill_template(template, email, scene)
        
        return reply
    
    def _detect_scene(self, text: str) -> str:
        """检测邮件场景"""
        scores = {}
        
        for scene, data in self.templates.items():
            if scene == "default":
                continue
            score = sum(1 for kw in data["keywords"] if kw.lower() in text)
            if score > 0:
                scores[scene] = score
        
        if not scores:
            return "default"
        
        return max(scores.items(), key=lambda x: x[1])[0]
    
    def _fill_template(self, template: str, email: Dict, scene: str) -> str:
        """填充模板变量"""
        reply = template["template"]
        
        # 根据场景填充不同内容
        replacements = {
            "info": "您的相关资料已发送到邮箱，请查收",
            "confirmation": "周三下午的时间可以",
            "action": "按要求处理",
            "status": "暂时离开办公室",
            "return_date": "下周一"
        }
        
        for key, value in replacements.items():
            reply = reply.replace(f"{{{key}}}", value)
        
        return reply

def main():
    print(f"""
{Colors.CYAN}╔════════════════════════════════════════════════════════════╗
║    📤 企业级智能邮件助手 - 自动回复演示            ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)
    
    generator = AutoReplyGenerator()
    
    test_emails = [
        {
            "subject": "产品报价咨询",
            "sender": "customer@example.com",
            "body": "您好，我想了解一下贵公司产品的价格和功能..."
        },
        {
            "subject": "会议时间确认",
            "sender": "colleague@company.com",
            "body": "周三下午的周会您能参加吗？"
        },
        {
            "subject": "合同盖章事宜",
            "sender": "partner@vendor.com",
            "body": "请尽快处理这份合同盖章"
        },
        {
            "subject": "下周休假通知",
            "sender": "boss@company.com",
            "body": "我下周要去度假，可能无法及时回复"
        },
        {
            "subject": "感谢帮助",
            "sender": "friend@email.com",
            "body": "谢谢你的帮忙，真的太感谢了！"
        }
    ]
    
    print(f"\n{Colors.YELLOW}生成自动回复...{Colors.ENDC}\n")
    
    for i, email in enumerate(test_emails):
        print(f"{Colors.BLUE}{'─'*50}{Colors.ENDC}")
        print(f"📩 收到邮件 {i+1}:")
        print(f"   主题: {email['subject']}")
        print(f"   内容: {email['body'][:30]}...")
        
        time.sleep(0.3)
        
        reply = generator.generate(email)
        print(f"\n{Colors.GREEN}📤 自动回复:{Colors.ENDC}")
        print(f"   {reply}")
    
    print(f"\n{Colors.GREEN}✅ 自动回复演示完成！{Colors.ENDC}")

if __name__ == "__main__":
    main()
