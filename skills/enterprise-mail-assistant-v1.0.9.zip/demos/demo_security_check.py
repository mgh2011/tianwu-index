#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮件安全检查完整演示
本地邮件安全检测系统

功能：
- 发件人验证
- 钓鱼链接检测
- 附件安全扫描
- 威胁等级评估
"""

import re
import time
from datetime import datetime
from typing import Dict, List

class Colors:
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class ThreatLevel:
    """威胁等级"""
    SAFE = ("安全", "✅", Colors.GREEN)
    LOW = ("低风险", "⚠️", Colors.YELLOW)
    MEDIUM = ("中风险", "🔶", Colors.YELLOW)
    HIGH = ("高风险", "🔴", Colors.RED)
    CRITICAL = ("严重", "🚨", Colors.RED)

class SecurityChecker:
    """邮件安全检查器"""
    
    def __init__(self):
        # 本地威胁库
        self.known_phishing = [
            "fake-bank", "secure-verify", "account-lock",
            "paypal-secure", "钓鱼"
        ]
        self.suspicious_tlds = [".tk", ".ml", ".ga", ".cf"]
        self.malware_extensions = [".exe", ".scr", ".bat", ".vbs", ".ps1"]
        
        # 钓鱼关键词
        self.phishing_keywords = [
            "账户异常", "立即验证", "账户已锁定", "点击此处",
            "验证身份", "修改密码", "紧急", "限时"
        ]
    
    def check(self, email: Dict) -> Dict:
        """检查邮件安全性"""
        sender = email.get("sender", "")
        subject = email.get("subject", "")
        body = email.get("body", "")
        attachments = email.get("attachments", [])
        
        report = {
            "subject": subject,
            "sender": sender,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "checks": [],
            "warnings": [],
            "risk_score": 0,
            "threat_level": ThreatLevel.SAFE
        }
        
        # 1. 发件人检查
        sender_result = self._check_sender(sender)
        report["checks"].append(sender_result)
        
        # 2. 钓鱼检测
        phishing_result = self._check_phishing(subject + " " + body)
        report["checks"].append(phishing_result)
        
        # 3. 链接检查
        link_result = self._check_links(body)
        report["checks"].append(link_result)
        
        # 4. 附件检查
        attach_result = self._check_attachments(attachments)
        report["checks"].append(attach_result)
        
        # 计算风险
        report["risk_score"] = max(c["risk"] for c in report["checks"])
        report["threat_level"] = self._get_threat_level(report["risk_score"])
        
        # 收集警告
        for check in report["checks"]:
            if check["risk"] >= 50:
                report["warnings"].extend(check.get("details", []))
        
        return report
    
    def _check_sender(self, sender: str) -> Dict:
        """检查发件人"""
        result = {"name": "发件人验证", "status": "通过", "risk": 0, "details": []}
        
        domain = sender.split("@")[-1] if "@" in sender else ""
        
        # 检查钓鱼域名
        for phish in self.known_phishing:
            if phish in domain.lower():
                result["status"] = "危险"
                result["risk"] = 100
                result["details"].append(f"发件人域名可疑: {domain}")
                return result
        
        # 检查可疑TLD
        for tld in self.suspicious_tlds:
            if domain.endswith(tld):
                result["status"] = "警告"
                result["risk"] = max(result["risk"], 40)
                result["details"].append(f"使用可疑域名后缀: {tld}")
        
        return result
    
    def _check_phishing(self, text: str) -> Dict:
        """检测钓鱼"""
        result = {"name": "钓鱼检测", "status": "通过", "risk": 0, "details": []}
        
        text_lower = text.lower()
        matched = [kw for kw in self.phishing_keywords if kw.lower() in text_lower]
        
        result["risk"] = len(matched) * 15
        
        if matched:
            result["details"].append(f"发现钓鱼关键词: {', '.join(matched[:3])}")
        
        # 紧急性诱导
        if any(word in text for word in ["紧急", "立即", "立刻", "限时"]):
            result["risk"] += 20
            result["details"].append("使用紧急性诱导语言")
        
        if result["risk"] >= 80:
            result["status"] = "危险"
        elif result["risk"] >= 40:
            result["status"] = "警告"
        
        return result
    
    def _check_links(self, body: str) -> Dict:
        """检查链接"""
        result = {"name": "链接安全", "status": "通过", "risk": 0, "details": []}
        
        urls = re.findall(r'https?://[^\s<>"\']+', body)
        result["links_found"] = len(urls)
        
        for url in urls:
            # IP直连
            if re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url):
                result["risk"] = max(result["risk"], 80)
                result["details"].append("发现IP直连URL")
            
            # 短链接
            if any(s in url for s in ['bit.ly', 't.co', 'goo.gl']):
                result["risk"] = max(result["risk"], 30)
            
            # 钓鱼域名
            for phish in self.known_phishing:
                if phish in url.lower():
                    result["risk"] = 100
                    result["details"].append("发现钓鱼链接")
        
        if result["risk"] >= 80:
            result["status"] = "危险"
        elif result["risk"] >= 30:
            result["status"] = "警告"
        
        return result
    
    def _check_attachments(self, attachments: List[Dict]) -> Dict:
        """检查附件"""
        result = {"name": "附件安全", "status": "通过", "risk": 0, "details": []}
        
        if not attachments:
            result["details"].append("无附件")
            return result
        
        for att in attachments:
            name = att.get("filename", "")
            
            # 危险扩展名
            for ext in self.malware_extensions:
                if name.lower().endswith(ext):
                    result["status"] = "危险"
                    result["risk"] = 100
                    result["details"].append(f"危险附件: {name}")
            
            # 双扩展名
            if re.search(r'\..*\.(doc|xls|pdf)', name, re.I):
                result["risk"] = max(result["risk"], 40)
                result["details"].append(f"可疑附件: {name}")
        
        return result
    
    def _get_threat_level(self, risk: int):
        if risk >= 80: return ThreatLevel.CRITICAL
        if risk >= 60: return ThreatLevel.HIGH
        if risk >= 40: return ThreatLevel.MEDIUM
        if risk >= 20: return ThreatLevel.LOW
        return ThreatLevel.SAFE

def print_report(report: Dict):
    """打印报告"""
    level = report["threat_level"]
    
    print(f"""
{Colors.CYAN}{'═'*60}{Colors.ENDC}
{Colors.BOLD}🔒 安全检查报告{Colors.ENDC}
{'═'*60}

📧 主题: {report['subject']}
👤 发件人: {report['sender']}
⏰ 时间: {report['timestamp']}

🎯 威胁等级: {level[2]}{level[1]} {level[0]}{Colors.ENDC}
📊 风险评分: {level[2]}{report['risk_score']}/100{Colors.ENDC}
    """)
    
    print(f"📋 详细检查:")
    for check in report["checks"]:
        icon = "✅" if check["status"] == "通过" else "⚠️" if "警告" in check["status"] else "🚨"
        color = Colors.GREEN if check["status"] == "通过" else Colors.RED
        print(f"   {icon} {check['name']}: {color}{check['status']}{Colors.ENDC} (风险:{check['risk']})")
        for d in check.get("details", [])[:2]:
            print(f"      └─ {d}")
    
    if report["warnings"]:
        print(f"\n{Colors.RED}⚠️  警告事项:{Colors.ENDC}")
        for w in report["warnings"][:3]:
            print(f"   • {w}")
    
    print(f"{Colors.CYAN}{'═'*60}{Colors.ENDC}")

def main():
    print(f"""
{Colors.CYAN}╔════════════════════════════════════════════════════════════╗
║    🔒 企业级智能邮件助手 - 安全检查演示            ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)
    
    checker = SecurityChecker()
    
    test_emails = [
        {
            "subject": "项目进度汇报",
            "sender": "colleague@company.com",
            "body": "本周项目进度汇报：已完成模块A开发。",
            "attachments": []
        },
        {
            "subject": "【紧急】您的账户存在异常",
            "sender": "security@fake-bank-secure.com",
            "body": "您的账户检测到异常，请立即点击验证：https://192.168.1.100/verify",
            "attachments": []
        },
        {
            "subject": "【促销】iPhone限时优惠",
            "sender": "promo@apple-sale.net",
            "body": "iPhone 15 Pro限时优惠！点击: https://bit.ly/xyz123",
            "attachments": []
        }
    ]
    
    print(f"\n{Colors.YELLOW}开始检查 {len(test_emails)} 封邮件...{Colors.ENDC}\n")
    
    for i, email in enumerate(test_emails):
        print(f"{Colors.BLUE}检查 {i+1}/{len(test_emails)}...{Colors.ENDC}")
        time.sleep(0.4)
        report = checker.check(email)
        print_report(report)
    
    print(f"\n{Colors.GREEN}✅ 安全检查演示完成！{Colors.ENDC}")

if __name__ == "__main__":
    main()
