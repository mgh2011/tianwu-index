# 高级示例文档 (Advanced Examples)

本文档提供完整的使用示例，包括输入、输出和详细说明。

---

## 📧 示例1: 邮件智能分类

### 输入数据

```json
{
  "emails": [
    {
      "id": "email_001",
      "from": "boss@company.com",
      "to": "employee@company.com",
      "subject": "关于Q2季度项目报告",
      "body": "请在本周五前提交Q2季度项目进度报告，包括预算执行情况和下一步计划。",
      "timestamp": "2026-04-09T09:30:00",
      "priority": "high"
    },
    {
      "id": "email_002",
      "from": "newsletter@amazon.com",
      "to": "user@company.com",
      "subject": "限时优惠！全场5折起",
      "body": "亲爱的会员，我们为您准备了专属优惠，点击查看详情...",
      "timestamp": "2026-04-09T10:15:00",
      "priority": "normal"
    },
    {
      "id": "email_003",
      "from": "suspicious@unknown-domain.xyz",
      "to": "victim@company.com",
      "subject": "恭喜您中奖100万！",
      "body": "点击链接立即领取奖金：http://malicious-link.xyz/prize",
      "timestamp": "2026-04-09T11:00:00",
      "priority": "normal"
    }
  ]
}
```

### 执行脚本

```python
from demos.demo_mail_classification import MailClassifier

# 初始化分类器
classifier = MailClassifier()

# 加载邮件数据
emails = load_emails_from_json('input_emails.json')

# 执行分类
results = classifier.classify_batch(emails)

# 输出结果
print(json.dumps(results, indent=2, ensure_ascii=False))
```

### 输出结果

```json
{
  "summary": {
    "total": 3,
    "classified": 3,
    "failed": 0
  },
  "results": [
    {
      "email_id": "email_001",
      "category": "工作",
      "confidence": 0.95,
      "reason": "包含工作关键词: 项目报告, 预算, 计划",
      "priority": "high",
      "suggested_action": "需要在本周五前回复",
      "tags": ["工作", "报告", "紧急"]
    },
    {
      "email_id": "email_002",
      "category": "促销",
      "confidence": 0.92,
      "reason": "来自促销发件人，包含优惠关键词",
      "priority": "low",
      "suggested_action": "可以稍后查看或归档",
      "tags": ["促销", "优惠", "可忽略"]
    },
    {
      "email_id": "email_003",
      "category": "垃圾邮件",
      "confidence": 0.98,
      "reason": "可疑发件人域名，包含诈骗关键词，恶意链接",
      "priority": "danger",
      "suggested_action": "建议删除并标记为垃圾邮件",
      "tags": ["垃圾邮件", "诈骗", "危险"],
      "security_alert": {
        "level": "high",
        "threats": ["钓鱼链接", "中奖诈骗"],
        "recommendation": "请勿点击链接"
      }
    }
  ]
}
```

---

## 🛡️ 示例2: 安全检测与威胁分析

### 输入数据

```json
{
  "mail_content": {
    "from": "attacker@phishing-site.com",
    "subject": "紧急：您的账户存在安全风险",
    "body": "尊敬的用户，我们检测到您的账户存在异常登录，请立即点击以下链接验证身份：https://fake-bank.com/verify?id=xxx",
    "attachments": ["invoice.exe", "document.pdf.exe"],
    "links": [
      "https://fake-bank.com/verify",
      "http://bit.ly/suspicious-link"
    ]
  }
}
```

### 执行脚本

```python
from demos.demo_security_check import SecurityChecker

checker = SecurityChecker()
result = checker.analyze(mail_content)
```

### 输出结果

```json
{
  "security_status": "dangerous",
  "risk_score": 95,
  "threats": [
    {
      "type": "phishing",
      "severity": "critical",
      "description": "检测到钓鱼链接",
      "details": {
        "url": "https://fake-bank.com/verify",
        "domain_age": "2天",
        "ssl_valid": false,
        "reputation": "恶意"
      },
      "recommendation": "请勿点击该链接"
    },
    {
      "type": "malware",
      "severity": "high",
      "description": "可疑附件",
      "details": {
        "filename": "document.pdf.exe",
        "extension": ".exe",
        "disguise": "伪装成PDF文件",
        "signature_match": "Trojan.GenericKD"
      },
      "recommendation": "请勿打开该附件"
    },
    {
      "type": "social_engineering",
      "severity": "high",
      "description": "社会工程攻击",
      "details": {
        "tactics": ["紧迫感", "恐惧", "权威冒充"],
        "keywords": ["紧急", "安全风险", "立即"]
      },
      "recommendation": "通过官方渠道验证"
    }
  ],
  "overall_recommendation": "这是一封高风险钓鱼邮件，建议立即删除并报告给安全团队",
  "safe_actions": [
    "删除邮件",
    "标记为垃圾邮件",
    "报告给 IT 安全部门"
  ]
}
```

---

## 🔄 示例3: 自动回复生成

### 输入数据

```json
{
  "incoming_email": {
    "from": "client@partner-company.com",
    "to": "support@our-company.com",
    "subject": "产品使用问题咨询",
    "body": "您好，我们在使用贵司产品时遇到以下问题：1. 导出功能无法使用 2. 页面加载速度较慢。请问如何解决？",
    "timestamp": "2026-04-09T14:30:00"
  },
  "response_config": {
    "tone": "professional",
    "language": "zh-CN",
    "include_signature": true
  }
}
```

### 执行脚本

```python
from demos.demo_auto_reply import AutoReplyGenerator

generator = AutoReplyGenerator()
reply = generator.generate(incoming_email, response_config)
```

### 输出结果

```json
{
  "reply": {
    "to": "client@partner-company.com",
    "subject": "Re: 产品使用问题咨询",
    "body": "尊敬的客户：\n\n感谢您的来信。关于您反馈的问题，我们已记录并转交技术团队处理。\n\n针对您提到的问题：\n\n1. **导出功能问题**：请检查浏览器是否安装了广告拦截插件，或尝试清除浏览器缓存后重试。\n\n2. **页面加载速度问题**：我们正在进行系统优化，预计本周内完成升级。\n\n如有其他问题，请随时联系我们。\n\n此致\n敬礼\n\n---\n技术支持团队\nsupport@our-company.com\n工作时间：周一至周五 9:00-18:00",
    "priority": "normal",
    "suggested_send_time": "立即发送"
  },
  "analysis": {
    "intent": "技术支持请求",
    "urgency": "medium",
    "sentiment": "中性",
    "category": "客户服务"
  }
}
```

---

## 💾 示例4: 数据备份与恢复

### 备份操作

```python
from demos.demo_backup_restore import BackupManager

backup_mgr = BackupManager()

# 创建完整备份
backup_result = backup_mgr.create_full_backup(
    data_source='./mail_data/',
    backup_path='./backups/',
    compression='gzip'
)

print(backup_result)
```

### 备份输出

```json
{
  "backup_id": "backup_20260409_170500",
  "status": "success",
  "files_backed_up": 1523,
  "total_size": "45.2 MB",
  "compressed_size": "12.8 MB",
  "compression_ratio": "71.7%",
  "duration": "2.3 秒",
  "backup_file": "./backups/backup_20260409_170500.tar.gz",
  "checksum": "sha256:a1b2c3d4e5f6...",
  "included": {
    "emails": 1523,
    "attachments": 89,
    "configurations": 5,
    "templates": 12
  }
}
```

### 恢复操作

```python
# 从备份恢复
restore_result = backup_mgr.restore_from_backup(
    backup_file='./backups/backup_20260409_170500.tar.gz',
    target_path='./restored_data/'
)
```

### 恢复输出

```json
{
  "restore_id": "restore_20260409_171000",
  "status": "success",
  "backup_source": "backup_20260409_170500",
  "files_restored": 1523,
  "duration": "1.8 秒",
  "checksum_verified": true,
  "restore_location": "./restored_data/",
  "summary": {
    "emails_restored": 1523,
    "attachments_restored": 89,
    "configurations_restored": 5,
    "templates_restored": 12
  }
}
```

---

## 📊 示例5: 统计分析报告

### 执行脚本

```python
from demos.demo_statistics import StatisticsAnalyzer

analyzer = StatisticsAnalyzer()
report = analyzer.generate_report(
    data_source='./mail_data/',
    time_range='last_30_days',
    report_type='comprehensive'
)
```

### 统计报告输出

```json
{
  "report_metadata": {
    "generated_at": "2026-04-09T17:15:00",
    "time_range": "2026-03-10 ~ 2026-04-09",
    "total_emails": 15420
  },
  "classification_breakdown": {
    "工作": 6235,
    "个人": 3120,
    "促销": 4520,
    "垃圾邮件": 1545
  },
  "security_metrics": {
    "threats_blocked": 234,
    "phishing_attempts": 89,
    "malware_detected": 12,
    "suspicious_links": 133
  },
  "response_metrics": {
    "auto_replied": 567,
    "manual_replied": 2341,
    "average_response_time": "2.5小时"
  },
  "trends": {
    "daily_volume": "稳定",
    "spam_ratio": "下降 15%",
    "security_incidents": "上升 8%"
  },
  "recommendations": [
    "建议加强对钓鱼邮件的过滤",
    "考虑更新威胁签名库",
    "优化自动回复模板"
  ]
}
```

---

## 🎯 完整工作流示例

### 场景：新邮件处理完整流程

```python
# 完整的新邮件处理流程
from demos.demo_mail_classification import MailClassifier
from demos.demo_security_check import SecurityChecker
from demos.demo_auto_reply import AutoReplyGenerator

def process_incoming_email(email_data):
    """完整的邮件处理流程"""
    
    print(f"📥 收到新邮件: {email_data['subject']}")
    
    # 步骤1: 安全检测
    checker = SecurityChecker()
    security_result = checker.analyze(email_data)
    
    if security_result['security_status'] == 'dangerous':
        print("⚠️ 检测到安全威胁，已拦截")
        return {"status": "blocked", "reason": security_result}
    
    # 步骤2: 邮件分类
    classifier = MailClassifier()
    classification = classifier.classify(email_data)
    print(f"📁 分类结果: {classification['category']}")
    
    # 步骤3: 自动回复（如适用）
    if classification['category'] in ['工作', '客户服务']:
        generator = AutoReplyGenerator()
        reply = generator.generate(email_data)
        print(f"✉️ 已生成自动回复")
    
    # 步骤4: 归档存储
    archive_email(email_data, classification)
    print(f"💾 邮件已归档")
    
    return {
        "status": "processed",
        "classification": classification,
        "security": security_result,
        "auto_reply": reply if classification['category'] in ['工作', '客户服务'] else None
    }

# 使用示例
result = process_incoming_email(incoming_email)
print(json.dumps(result, indent=2, ensure_ascii=False))
```

---

*更多示例请参考 `demos/` 目录下的演示脚本*
