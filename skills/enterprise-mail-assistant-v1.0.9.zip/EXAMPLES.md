# 使用示例

## 示例1：邮件分类

```python
from demos.demo_mail_classification import MailClassifier

# 创建分类器
classifier = MailClassifier()

# 测试邮件
email = {
    "subject": "【紧急】项目进度汇报",
    "sender": "colleague@company.com",
    "body": "本周完成了模块A的开发工作..."
}

# 分类
category, icon, confidence = classifier.classify(email)
print(f"分类: {category[0]} ({icon})")
print(f"置信度: {confidence*100:.0f}%")
```

**输出:**
```
分类: 工作 (📁)
置信度: 80%
```

---

## 示例2：安全检查

```python
from demos.demo_security_check import SecurityChecker

# 创建检查器
checker = SecurityChecker()

# 测试邮件
email = {
    "subject": "【安全警告】账户异常",
    "sender": "security@fake-bank123.com",
    "body": "请立即点击链接验证: https://192.168.1.1/verify",
    "attachments": []
}

# 检查
report = checker.check(email)
print(f"威胁等级: {report['threat_level'][0]}")
print(f"风险评分: {report['risk_score']}/100")

if report['warnings']:
    print("警告:")
    for w in report['warnings']:
        print(f"  - {w}")
```

**输出:**
```
威胁等级: 严重
风险评分: 100/100
警告:
  - 发件人域名可疑: fake-bank123.com
  - 发现IP直连URL
  - 发现钓鱼关键词
```

---

## 示例3：自动回复

```python
from demos.demo_auto_reply import AutoReplyGenerator

# 创建生成器
generator = AutoReplyGenerator()

# 原始邮件
email = {
    "subject": "产品报价咨询",
    "sender": "customer@example.com",
    "body": "您好，我想了解一下贵公司产品的价格..."
}

# 生成回复
reply = generator.generate(email)
print(reply)
```

**输出:**
```
感谢您的咨询！您的相关资料已发送到邮箱，请查收。如有其他问题，请随时联系我们。
```

---

## 示例4：备份管理

```python
from demos.demo_backup_restore import BackupManager

# 创建管理器
manager = BackupManager()

# 列出备份
backups = manager.list_backups()
for b in backups:
    print(f"{b['name']} - {b['timestamp']} - {b['size']}")

# 创建新备份
new_backup = manager.create_backup("我的重要备份")
print(f"备份创建成功: {new_backup['id']}")

# 恢复备份
manager.restore("backup_001")
```

---

## 示例5：批量处理

```python
from demos.demo_mail_classification import MailClassifier

classifier = MailClassifier()

# 批量邮件
emails = [
    {"subject": "周报", "sender": "a@co.com", "body": "本周工作..."},
    {"subject": "会议", "sender": "b@co.com", "body": "明天下午..."},
    {"subject": "发票", "sender": "c@co.com", "body": "请开发票..."},
]

# 批量分类
results = classifier.batch_classify(emails)

for r in results:
    print(f"{r['icon']} {r['category']}: {r['email']['subject']}")
```

**输出:**
```
📁 工作: 周报
📅 会议: 会议
💰 财务: 发票
```

---

## 示例6：命令行使用

```bash
# 分类邮件
python cli.py classify -s "项目启动" -f "manager@company.com" -b "明天开会"

# 安全检查
python cli.py security -s "重要" -f "unknown@bad.com" -b "点击链接"

# 生成回复
python cli.py reply -s "咨询" -b "请问产品多少钱"

# 查看备份
python cli.py backup --list
```
