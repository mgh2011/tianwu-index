#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业级高级安全系统 v5.1.0
包含：联合决策引擎、威胁情报管理器、安全态势感知系统
"""

import json
import hashlib
import datetime
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import statistics


class DecisionAction(Enum):
    ALLOW = "allow"
    BLOCK = "block"
    QUARANTINE = "quarantine"
    WARN = "warn"
    INVESTIGATE = "investigate"

class IOCType(Enum):
    IP = "ip"
    DOMAIN = "domain"
    URL = "url"
    EMAIL = "email"
    HASH = "hash"
    FILENAME = "filename"

class SeverityLevel(Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class IOCRecord:
    ioc_type: IOCType
    value: str
    confidence: float
    severity: SeverityLevel
    source: str
    description: str
    first_seen: str
    last_seen: str
    ttl_hours: int
    expires_at: str
    tags: List[str] = field(default_factory=list)


@dataclass
class Decision:
    action: DecisionAction
    confidence: float
    sources: List[str]
    reasoning: str
    risk_score: float
    timestamp: str = field(default_factory=lambda: datetime.datetime.now().isoformat())


@dataclass
class SecurityEvent:
    event_id: str
    event_type: str
    severity: SeverityLevel
    source: str
    description: str
    timestamp: str
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Anomaly:
    anomaly_type: str
    severity: SeverityLevel
    description: str
    detected_at: str
    metrics: Dict[str, float] = field(default_factory=dict)


class JointDecisionEngine:
    """联合决策引擎 - 多源情报融合"""
    
    def __init__(self):
        self.sources: Dict[str, Dict[str, Any]] = {}
        self.analysis_results: Dict[str, Dict] = {}
        self.decision_history: List[Dict] = []
        self.conflict_resolution = "weighted_voting"
    
    def add_source(self, source_name: str, weight: float = 1.0, 
                   confidence_threshold: float = 0.5, enabled: bool = True):
        self.sources[source_name] = {
            'weight': max(0.0, min(1.0, weight)),
            'confidence_threshold': confidence_threshold,
            'enabled': enabled,
            'total_decisions': 0,
            'correct_decisions': 0
        }
    
    def submit_analysis(self, source_name: str, result: Dict) -> bool:
        if source_name not in self.sources or not self.sources[source_name]['enabled']:
            return False
        
        self.analysis_results[source_name] = {
            'action': result.get('action', 'investigate'),
            'confidence': max(0.0, min(1.0, result.get('confidence', 0.5))),
            'risk_score': max(0, min(100, result.get('risk_score', 50))),
            'reasoning': result.get('reasoning', ''),
            'timestamp': datetime.datetime.now().isoformat()
        }
        return True
    
    def make_decision(self) -> Decision:
        if not self.analysis_results:
            return Decision(DecisionAction.ALLOW, 0.0, [], "No results", 0.0)
        
        valid_results = []
        for source_name, result in self.analysis_results.items():
            config = self.sources.get(source_name, {})
            if result['confidence'] >= config.get('confidence_threshold', 0.5):
                valid_results.append({'source': source_name, 'weight': config.get('weight', 1.0), **result})
        
        if not valid_results:
            return Decision(DecisionAction.WARN, 0.0, list(self.analysis_results.keys()), "Below threshold", 50.0)
        
        # 加权投票
        action_scores = defaultdict(float)
        total_weight = 0.0
        risk_scores = []
        sources = []
        
        for r in valid_results:
            action_scores[r['action']] += r['weight'] * r['confidence']
            total_weight += r['weight']
            risk_scores.append(r['risk_score'])
            sources.append(r['source'])
        
        best_action = max(action_scores.items(), key=lambda x: x[1])[0]
        confidence = action_scores[best_action] / total_weight if total_weight > 0 else 0.0
        avg_risk = statistics.mean(risk_scores) if risk_scores else 50.0
        
        if avg_risk >= 80:
            best_action = 'block'
        elif avg_risk >= 60 and best_action == 'allow':
            best_action = 'warn'
        
        decision = Decision(DecisionAction(best_action), confidence, sources, 
                           f"Weighted voting from {len(valid_results)} sources", avg_risk)
        
        self.decision_history.append({'decision': decision.action.value, 'confidence': decision.confidence, 'timestamp': decision.timestamp})
        self.analysis_results.clear()
        
        return decision
    
    def get_confidence_score(self) -> float:
        if not self.decision_history:
            return 0.0
        recent = self.decision_history[-10:]
        return statistics.mean([d['confidence'] for d in recent])


class ThreatIntelligenceManager:
    """威胁情报管理器 - 本地IOC库"""
    
    def __init__(self):
        self.ioc_database: Dict[str, Dict[str, IOCRecord]] = defaultdict(dict)
        self.stats = {'total_iocs': 0, 'queries': 0, 'matches': 0}
    
    def add_ioc(self, ioc_type: str, value: str, confidence: float = 0.8,
                severity: str = "medium", source: str = "local",
                description: str = "", ttl_hours: int = 720,
                tags: List[str] = None) -> bool:
        try:
            ioc_enum = IOCType(ioc_type.lower())
            sev_enum = SeverityLevel(severity.lower())
        except ValueError:
            return False
        
        now = datetime.datetime.now()
        expires = (now + datetime.timedelta(hours=ttl_hours)).isoformat()
        
        record = IOCRecord(ioc_enum, value, min(1.0, max(0.0, confidence)), sev_enum,
                          source, description, now.isoformat(), now.isoformat(),
                          ttl_hours, expires, tags or [])
        
        self.ioc_database[ioc_type.lower()][value.lower()] = record
        self.stats['total_iocs'] += 1
        return True
    
    def query_ioc(self, ioc_type: str, value: str) -> Optional[IOCRecord]:
        self.stats['queries'] += 1
        record = self.ioc_database.get(ioc_type.lower(), {}).get(value.lower())
        
        if record and datetime.datetime.now().isoformat() <= record.expires_at:
            record.last_seen = datetime.datetime.now().isoformat()
            self.stats['matches'] += 1
            return record
        return None
    
    def batch_query(self, indicators: List[Dict[str, str]]) -> List[Tuple[str, Optional[IOCRecord]]]:
        return [(f"{i.get('type','')}:{i.get('value','')}", self.query_ioc(i.get('type',''), i.get('value',''))) for i in indicators]
    
    def cleanup_expired(self) -> int:
        now = datetime.datetime.now().isoformat()
        cleaned = 0
        for ioc_type in list(self.ioc_database.keys()):
            for value in list(self.ioc_database[ioc_type].keys()):
                if now > self.ioc_database[ioc_type][value].expires_at:
                    del self.ioc_database[ioc_type][value]
                    cleaned += 1
                    self.stats['total_iocs'] -= 1
        return cleaned
    
    def export_intelligence(self, format: str = 'json') -> str:
        all_iocs = []
        for ioc_type in self.ioc_database:
            for r in self.ioc_database[ioc_type].values():
                all_iocs.append({'type': r.ioc_type.value, 'value': r.value, 'confidence': r.confidence,
                                'severity': r.severity.value, 'source': r.source, 'description': r.description})
        
        if format == 'json':
            return json.dumps(all_iocs, indent=2, ensure_ascii=False)
        elif format == 'csv':
            lines = ['type,value,confidence,severity,source']
            lines.extend(f"{i['type']},{i['value']},{i['confidence']},{i['severity']},{i['source']}" for i in all_iocs)
            return '\n'.join(lines)
        return ""
    
    def get_stats(self) -> Dict[str, Any]:
        return {**self.stats, 'by_type': {t: len(r) for t, r in self.ioc_database.items()}}


class SecuritySituationAwareness:
    """安全态势感知系统"""
    
    def __init__(self):
        self.events: List[SecurityEvent] = []
        self.posture_history: List[Dict] = []
        self.anomaly_thresholds = {'event_rate': 100, 'critical_rate': 10, 'repeat_source': 50}
    
    def record_event_simple(self, event_type: str, severity: str, source: str, 
                           description: str, details: Dict = None) -> str:
        event_id = hashlib.md5(f"{event_type}{datetime.datetime.now().isoformat()}".encode()).hexdigest()[:12]
        event = SecurityEvent(event_id, event_type, SeverityLevel(severity.lower()),
                             source, description, datetime.datetime.now().isoformat(), details or {})
        self.events.append(event)
        if len(self.events) > 10000:
            self.events = self.events[-5000:]
        return event_id
    
    def calculate_posture_score(self) -> float:
        if not self.events:
            return 100.0
        
        now = datetime.datetime.now()
        last_24h = (now - datetime.timedelta(hours=24)).isoformat()
        recent = [e for e in self.events if e.timestamp >= last_24h]
        
        if not recent:
            return 100.0
        
        base_score = 100.0
        count = len(recent)
        
        if count > 1000: base_score -= 20
        elif count > 500: base_score -= 10
        elif count > 100: base_score -= 5
        
        severity_weights = {SeverityLevel.CRITICAL: 5.0, SeverityLevel.HIGH: 3.0, 
                          SeverityLevel.MEDIUM: 1.0, SeverityLevel.LOW: 0.5, SeverityLevel.INFO: 0.1}
        base_score -= min(30, sum(severity_weights.get(e.severity, 0) for e in recent))
        
        score = max(0.0, min(100.0, base_score))
        self.posture_history.append({'score': score, 'timestamp': now.isoformat(), 'count': count})
        
        return score
    
    def get_trend_analysis(self, days: int = 7) -> Dict:
        now = datetime.datetime.now()
        start = (now - datetime.timedelta(days=days)).isoformat()
        period_events = [e for e in self.events if e.timestamp >= start]
        
        daily = defaultdict(lambda: {'total': 0, 'types': defaultdict(int)})
        for e in period_events:
            day = e.timestamp.split('T')[0]
            daily[day]['total'] += 1
            daily[day]['types'][e.event_type] += 1
        
        daily_breakdown = [{'date': d, 'count': s['total']} for d, s in sorted(daily.items())]
        
        if len(daily_breakdown) >= 3:
            recent = statistics.mean([d['count'] for d in daily_breakdown[-3:]])
            earlier = statistics.mean([d['count'] for d in daily_breakdown[:3]])
            trend = "increasing" if recent > earlier * 1.2 else ("decreasing" if recent < earlier * 0.8 else "stable")
        else:
            trend = "insufficient_data"
        
        type_counts = defaultdict(int)
        for e in period_events:
            type_counts[e.event_type] += 1
        
        return {
            'period': f'{days} days',
            'total_events': len(period_events),
            'trend_direction': trend,
            'top_types': sorted(type_counts.items(), key=lambda x: x[1], reverse=True)[:10],
            'daily_breakdown': daily_breakdown
        }
    
    def detect_anomalies(self) -> List[Anomaly]:
        anomalies = []
        now = datetime.datetime.now()
        last_hour = (now - datetime.timedelta(hours=1)).isoformat()
        recent = [e for e in self.events if e.timestamp >= last_hour]
        
        if len(recent) > self.anomaly_thresholds['event_rate']:
            anomalies.append(Anomaly("high_event_rate", SeverityLevel.HIGH,
                f"事件速率异常: {len(recent)}/hour", now.isoformat(), {'rate': len(recent)}))
        
        critical = len([e for e in recent if e.severity == SeverityLevel.CRITICAL])
        if critical > self.anomaly_thresholds['critical_rate']:
            anomalies.append(Anomaly("high_critical_rate", SeverityLevel.CRITICAL,
                f"严重事件过多: {critical}/hour", now.isoformat(), {'count': critical}))
        
        return anomalies
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        score = self.calculate_posture_score()
        now = datetime.datetime.now()
        last_24h = (now - datetime.timedelta(hours=24)).isoformat()
        recent = [e for e in self.events if e.timestamp >= last_24h]
        
        sev_dist = defaultdict(int)
        type_dist = defaultdict(int)
        for e in recent:
            sev_dist[e.severity.value] += 1
            type_dist[e.event_type] += 1
        
        status = "安全" if score >= 90 else ("良好" if score >= 70 else ("一般" if score >= 50 else ("警告" if score >= 30 else "危险")))
        
        return {
            'posture_score': score, 'posture_status': status,
            'total_events_24h': len(recent), 'severity_distribution': dict(sev_dist),
            'type_distribution': dict(type_dist), 'anomaly_count': len(self.detect_anomalies()),
            'last_updated': now.isoformat()
        }


if __name__ == '__main__':
    print("=" * 60)
    print("高级安全系统演示")
    print("=" * 60)
    
    # 联合决策引擎
    engine = JointDecisionEngine()
    engine.add_source("威胁检测", weight=0.4)
    engine.add_source("钓鱼识别", weight=0.3)
    engine.submit_analysis("威胁检测", {'action': 'block', 'confidence': 0.85, 'risk_score': 75})
    engine.submit_analysis("钓鱼识别", {'action': 'block', 'confidence': 0.9, 'risk_score': 85})
    decision = engine.make_decision()
    print(f"\n决策: {decision.action.value}, 置信度: {decision.confidence:.2f}")
    
    # 威胁情报
    ti = ThreatIntelligenceManager()
    ti.add_ioc("ip", "192.168.1.100", severity="high", description="恶意IP")
    result = ti.query_ioc("ip", "192.168.1.100")
    print(f"\nIOC查询: {result.value if result else '未找到'}")
    
    # 态势感知
    ssa = SecuritySituationAwareness()
    ssa.record_event_simple("phishing", "high", "gateway", "钓鱼邮件")
    score = ssa.calculate_posture_score()
    print(f"\n态势评分: {score:.1f}")
    
    print("\n" + "=" * 60)
