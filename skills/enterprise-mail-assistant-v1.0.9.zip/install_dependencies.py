#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
依赖检查脚本
检查Python环境和可选依赖（仅检查，不安装）

注意：本技能不需要外部依赖，所有功能使用Python标准库实现。
此脚本仅用于检查环境兼容性。
"""

import sys

class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    ENDC = '\033[0m'

def print_step(msg):
    print(f"\n{Colors.CYAN}➤ {msg}{Colors.ENDC}")

def print_success(msg):
    print(f"{Colors.GREEN}✓ {msg}{Colors.ENDC}")

def print_warning(msg):
    print(f"{Colors.YELLOW}⚠ {msg}{Colors.ENDC}")

def print_info(msg):
    print(f"   {msg}")

def check_python():
    """检查Python版本"""
    print_step("检查Python环境...")
    
    version = sys.version_info
    print(f"   Python版本: {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print_warning("建议使用Python 3.7或更高版本以获得最佳体验")
        return False
    
    print_success("Python版本符合要求")
    return True

def check_dependencies():
    """检查可选依赖"""
    print_step("检查可选依赖包...")
    
    # 本技能不需要外部依赖
    # 这里列出可能用到的可选依赖
    
    print_info("本技能使用Python标准库，无需安装外部依赖")
    print()
    print_info("可选增强功能：")
    print_info("  - colorama: 彩色终端输出（可选）")
    print_info("  - requests: HTTP请求功能（可选，用于邮件追踪API集成）")
    print()
    
    # 检查可选依赖是否存在
    optional_deps = {
        "colorama": "彩色终端输出",
        "requests": "HTTP请求功能（邮件追踪API集成）"
    }
    
    for pkg, desc in optional_deps.items():
        try:
            __import__(pkg)
            print_success(f"{pkg}: 已安装 ({desc})")
        except ImportError:
            print_info(f"{pkg}: 未安装 ({desc}，可选)")

def main():
    print(f"""
{Colors.CYAN}╔════════════════════════════════════════════════════════════╗
║                                                          ║
║    📦 企业级智能邮件助手 - 环境检查                      ║
║                                                          ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)
    
    # 检查Python
    check_python()
    
    # 检查依赖
    check_dependencies()
    
    print(f"""
{Colors.GREEN}╔════════════════════════════════════════════════════════════╗
║                                                          ║
║    ✓ 环境检查完成                                        ║
║                                                          ║
║    本技能无需安装外部依赖，可直接运行。                   ║
║                                                          ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)
    
    return 0

if __name__ == '__main__':
    sys.exit(main())
