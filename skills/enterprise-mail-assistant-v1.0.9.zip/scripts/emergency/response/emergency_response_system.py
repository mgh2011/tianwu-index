# scripts/emergency/response/emergency_response_system.py
"""
应急响应系统 - 企业级安全事件应急响应流程、处置预案、事件管理、资源调度
"""
import asyncio
import json
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict

class IncidentSeverity(Enum):
    """事件严重级别"""
    P1_CRITICAL = 1  # 紧急 - 系统瘫痪
    P2_HIGH = 2      # 高危 - 严重安全事件
    P3_MEDIUM = 3    # 中危 - 一般安全事件
    P4_LOW = 4       # 低危 - 轻微异常
    P5_INFO = 5      # 信息 - 通知级别

class IncidentStatus(Enum):
    """事件状态"""
    NEW = "new"
    INVESTIGATING = "investigating"
    IDENTIFIED = "identified"
    MONITORING = "monitoring"
    RESOLVED = "resolved"
    CLOSED = "closed"

class IncidentCategory(Enum):
    """事件类别"""
    SECURITY_BREACH = "security_breach"
    DATA_LEAK = "data_leak"
    MALWARE_INFECTION = "malware_infection"
    DDOS_ATTACK = "ddos_attack"
    PHISHING = "phishing"
    UNAUTHORIZED_ACCESS = "unauthorized_access"
    SYSTEM_OUTAGE = "system_outage"
    COMPLIANCE_VIOLATION = "compliance_violation"
    OTHER = "other"

class EmergencyResponseSystem:
    """应急响应系统"""
    
    def __init__(self):
        self.incidents = {}
        self.response_templates = {}
        self.escalation_matrix = {}
        self.team_roster = {}
        self.notification_channels = {}
        
        # SLA定义
        self.sla_definitions = {
            IncidentSeverity.P1_CRITICAL: {
                "response_time": 15,      # 分钟
                "resolution_time": 60,     # 分钟
                "notify_levels": [1, 2, 3] # 通知到第3级
            },
            IncidentSeverity.P2_HIGH: {
                "response_time": 30,
                "resolution_time": 240,
                "notify_levels": [1, 2]
            },
            IncidentSeverity.P3_MEDIUM: {
                "response_time": 120,
                "resolution_time": 1440,
                "notify_levels": [1]
            },
            IncidentSeverity.P4_LOW: {
                "response_time": 480,
                "resolution_time": 2880,
                "notify_levels": []
            },
            IncidentSeverity.P5_INFO: {
                "response_time": 1440,
                "resolution_time": 10080,
                "notify_levels": []
            }
        }
        
        # 初始化响应模板
        self._init_response_templates()
    
    def _init_response_templates(self):
        """初始化响应模板"""
        self.response_templates = {
            "security_breach": {
                "name": "安全漏洞响应",
                "steps": [
                    "隔离受影响系统",
                    "收集证据",
                    "评估影响范围",
                    "通知相关方",
                    "实施修复措施",
                    "恢复正常运营",
                    "编写事件报告"
                ],
                "checkpoints": [
                    {"name": "系统隔离完成", "required": True},
                    {"name": "证据收集完成", "required": True},
                    {"name": "影响评估完成", "required": True},
                    {"name": "修复验证通过", "required": True}
                ]
            },
            "data_leak": {
                "name": "数据泄露响应",
                "steps": [
                    "确认泄露范围",
                    "立即切断泄露通道",
                    "评估数据类型和敏感度",
                    "通知法务和合规团队",
                    "通知受影响用户（如需要）",
                    "实施补救措施",
                    "加强数据保护措施",
                    "向监管机构报告（如需要）"
                ],
                "checkpoints": [
                    {"name": "泄露通道切断", "required": True},
                    {"name": "数据分类完成", "required": True},
                    {"name": "监管报告提交", "required": True}
                ]
            },
            "malware_infection": {
                "name": "恶意软件感染响应",
                "steps": [
                    "识别感染主机",
                    "隔离受感染系统",
                    "收集恶意软件样本",
                    "全网扫描确认感染范围",
                    "清除恶意软件",
                    "系统恢复",
                    "加强防护措施"
                ],
                "checkpoints": [
                    {"name": "受感染主机隔离", "required": True},
                    {"name": "样本收集完成", "required": True},
                    {"name": "全网扫描完成", "required": True},
                    {"name": "恶意软件清除完成", "required": True}
                ]
            },
            "ddos_attack": {
                "name": "DDoS攻击响应",
                "steps": [
                    "确认攻击类型和规模",
                    "激活DDoS防护措施",
                    "联系ISP/CDN服务商",
                    "启用流量清洗",
                    "负载均衡调整",
                    "监控攻击趋势",
                    "逐步恢复正常服务"
                ],
                "checkpoints": [
                    {"name": "DDoS防护激活", "required": True},
                    {"name": "服务商协调完成", "required": True},
                    {"name": "流量清洗生效", "required": True},
                    {"name": "服务恢复正常", "required": True}
                ]
            }
        }
    
    async def create_incident(self, incident_report: Dict) -> Dict:
        """
        创建安全事件
        
        Args:
            incident_report: 事件报告
            
        Returns:
            创建的事件信息
        """
        incident_id = f"INC-{datetime.now().strftime('%Y%m%d')}-{len(self.incidents) + 1}"
        
        # 确定严重级别
        severity = self._determine_severity(incident_report)
        
        # 确定事件类别
        category = self._determine_category(incident_report)
        
        incident = {
            "incident_id": incident_id,
            "title": incident_report.get("title", "Untitled Incident"),
            "description": incident_report.get("description", ""),
            "category": category.value,
            "severity": severity.value,
            "status": IncidentStatus.NEW.value,
            "created_at": datetime.now().isoformat(),
            "created_by": incident_report.get("reported_by", "system"),
            "affected_systems": incident_report.get("affected_systems", []),
            "affected_users": incident_report.get("affected_users", []),
            "initial_impact": incident_report.get("impact_estimate", "unknown"),
            "timeline": [
                {
                    "timestamp": datetime.now().isoformat(),
                    "action": "incident_created",
                    "actor": "system",
                    "note": "Incident reported"
                }
            ],
            "assigned_team": None,
            "assigned_to": None,
            "sla": self.sla_definitions[severity],
            "sla_tracking": {
                "response_deadline": (
                    datetime.now() + 
                    timedelta(minutes=self.sla_definitions[severity]["response_time"])
                ).isoformat(),
                "resolution_deadline": (
                    datetime.now() + 
                    timedelta(minutes=self.sla_definitions[severity]["resolution_time"])
                ).isoformat(),
                "response_met": None,
                "resolution_met": None
            },
            "response_progress": 0,
            "checkpoints": [],
            "evidence": [],
            "related_incidents": [],
            "postmortem_required": severity in [
                IncidentSeverity.P1_CRITICAL,
                IncidentSeverity.P2_HIGH
            ]
        }
        
        self.incidents[incident_id] = incident
        
        # 触发自动化响应
        asyncio.create_task(self._trigger_automated_response(incident))
        
        # 发送通知
        await self._send_notifications(incident)
        
        return incident
    
    def _determine_severity(self, report: Dict) -> IncidentSeverity:
        """确定事件严重级别"""
        # 基于影响范围和类型确定
        impact = report.get("impact", "")
        scope = len(report.get("affected_systems", []))
        
        if "data breach" in impact.lower() or scope > 10:
            return IncidentSeverity.P1_CRITICAL
        elif "malware" in impact.lower() or "ransomware" in impact.lower():
            return IncidentSeverity.P2_HIGH
        elif "unauthorized" in impact.lower() or scope > 3:
            return IncidentSeverity.P3_MEDIUM
        elif "suspicious" in impact.lower():
            return IncidentSeverity.P4_LOW
        else:
            return IncidentSeverity.P5_INFO
    
    def _determine_category(self, report: Dict) -> IncidentCategory:
        """确定事件类别"""
        title = report.get("title", "").lower()
        description = report.get("description", "").lower()
        
        combined_text = title + " " + description
        
        if "breach" in combined_text:
            return IncidentCategory.SECURITY_BREACH
        elif "leak" in combined_text or "data loss" in combined_text:
            return IncidentCategory.DATA_LEAK
        elif "malware" in combined_text or "virus" in combined_text:
            return IncidentCategory.MALWARE_INFECTION
        elif "ddos" in combined_text or "dos" in combined_text:
            return IncidentCategory.DDOS_ATTACK
        elif "phishing" in combined_text:
            return IncidentCategory.PHISHING
        elif "unauthorized" in combined_text or "access" in combined_text:
            return IncidentCategory.UNAUTHORIZED_ACCESS
        elif "outage" in combined_text or "down" in combined_text:
            return IncidentCategory.SYSTEM_OUTAGE
        elif "compliance" in combined_text or "policy" in combined_text:
            return IncidentCategory.COMPLIANCE_VIOLATION
        else:
            return IncidentCategory.OTHER
    
    async def _trigger_automated_response(self, incident: Dict):
        """触发自动化响应"""
        category = incident["category"]
        
        if category in self.response_templates:
            template = self.response_templates[category]
            incident["response_template"] = template["name"]
            incident["checkpoints"] = [
                {**cp, "completed": False, "completed_at": None}
                for cp in template["checkpoints"]
            ]
        
        # 根据严重级别自动分配
        if incident["severity"] in [1, 2]:
            incident["assigned_team"] = "security_oncall"
            incident["assigned_to"] = self.team_roster.get("security_oncall", {}).get("primary")
    
    async def _send_notifications(self, incident: Dict):
        """发送通知"""
        severity = IncidentSeverity(incident["severity"])
        sla = self.sla_definitions[severity]
        
        for level in sla["notify_levels"]:
            team = self.team_roster.get(f"level_{level}", {})
            if team.get("primary"):
                await self._notify_user(
                    team["primary"],
                    incident,
                    "critical" if level == 1 else "high"
                )
    
    async def _notify_user(self, user: str, incident: Dict, priority: str):
        """通知用户"""
        # 简化实现
        pass
    
    async def update_incident(self, 
                             incident_id: str, 
                             update: Dict) -> Dict:
        """
        更新事件状态
        
        Args:
            incident_id: 事件ID
            update: 更新内容
            
        Returns:
            更新后的事件
        """
        if incident_id not in self.incidents:
            return {"error": "Incident not found"}
        
        incident = self.incidents[incident_id]
        
        # 记录时间线
        timeline_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": update.get("action"),
            "actor": update.get("updated_by", "unknown"),
            "note": update.get("note", ""),
            "previous_status": incident["status"]
        }
        
        # 应用更新
        if "status" in update:
            new_status = IncidentStatus(update["status"])
            incident["status"] = new_status.value
            timeline_entry["new_status"] = new_status.value
            
            # 检查是否达到关键状态
            if new_status == IncidentStatus.INVESTIGATING:
                await self._mark_response_start(incident)
            elif new_status == IncidentStatus.RESOLVED:
                await self._mark_resolution(incident)
        
        if "assigned_to" in update:
            incident["assigned_to"] = update["assigned_to"]
        
        if "severity" in update:
            incident["severity"] = update["severity"]
        
        if "progress" in update:
            incident["response_progress"] = update["progress"]
        
        if "checkpoints" in update:
            incident["checkpoints"] = update["checkpoints"]
        
        if "evidence" in update:
            incident["evidence"].extend(update["evidence"])
        
        # 添加时间线
        incident["timeline"].append(timeline_entry)
        
        return incident
    
    async def _mark_response_start(self, incident: Dict):
        """标记响应开始"""
        incident["sla_tracking"]["response_start_time"] = datetime.now().isoformat()
        
        # 检查是否在SLA响应时间内
        response_deadline = datetime.fromisoformat(
            incident["sla_tracking"]["response_deadline"]
        )
        if datetime.now() <= response_deadline:
            incident["sla_tracking"]["response_met"] = True
        else:
            incident["sla_tracking"]["response_met"] = False
            incident["sla_breach"] = True
    
    async def _mark_resolution(self, incident: Dict):
        """标记解决"""
        incident["resolved_at"] = datetime.now().isoformat()
        
        # 计算解决时间
        created = datetime.fromisoformat(incident["created_at"])
        resolved = datetime.now()
        resolution_minutes = (resolved - created).total_seconds() / 60
        
        incident["resolution_minutes"] = resolution_minutes
        
        # 检查是否在SLA解决时间内
        resolution_deadline = datetime.fromisoformat(
            incident["sla_tracking"]["resolution_deadline"]
        )
        if resolved <= resolution_deadline:
            incident["sla_tracking"]["resolution_met"] = True
        else:
            incident["sla_tracking"]["resolution_met"] = False
            incident["sla_breach"] = True
    
    async def complete_checkpoint(self, 
                                 incident_id: str, 
                                 checkpoint_name: str) -> Dict:
        """完成检查点"""
        if incident_id not in self.incidents:
            return {"error": "Incident not found"}
        
        incident = self.incidents[incident_id]
        
        for checkpoint in incident["checkpoints"]:
            if checkpoint["name"] == checkpoint_name:
                checkpoint["completed"] = True
                checkpoint["completed_at"] = datetime.now().isoformat()
                checkpoint["completed_by"] = "current_user"
                
                # 更新进度
                completed = sum(1 for cp in incident["checkpoints"] if cp["completed"])
                total = len(incident["checkpoints"])
                incident["response_progress"] = int(completed / total * 100)
                
                break
        
        return incident
    
    async def get_incident_details(self, incident_id: str) -> Dict:
        """获取事件详情"""
        if incident_id not in self.incidents:
            return {"error": "Incident not found"}
        
        incident = self.incidents[incident_id]
        
        # 计算当前SLA状态
        sla_status = await self._calculate_sla_status(incident)
        
        return {
            **incident,
            "sla_status": sla_status
        }
    
    async def _calculate_sla_status(self, incident: Dict) -> Dict:
        """计算SLA状态"""
        status = incident["status"]
        
        if status == IncidentStatus.RESOLVED.value:
            return {
                "response_met": incident["sla_tracking"]["response_met"],
                "resolution_met": incident["sla_tracking"]["resolution_met"],
                "status": "met" if incident["sla_tracking"]["resolution_met"] else "breached"
            }
        
        # 计算剩余时间
        now = datetime.now()
        
        response_deadline = datetime.fromisoformat(
            incident["sla_tracking"]["response_deadline"]
        )
        resolution_deadline = datetime.fromisoformat(
            incident["sla_tracking"]["resolution_deadline"]
        )
        
        response_remaining = (response_deadline - now).total_seconds() / 60
        resolution_remaining = (resolution_deadline - now).total_seconds() / 60
        
        return {
            "response_remaining_minutes": max(0, response_remaining),
            "resolution_remaining_minutes": max(0, resolution_remaining),
            "at_risk": response_remaining < 30 or resolution_remaining < 60
        }
    
    async def get_incident_dashboard(self) -> Dict:
        """获取事件仪表盘"""
        dashboard = {
            "total_incidents": len(self.incidents),
            "by_severity": defaultdict(int),
            "by_status": defaultdict(int),
            "by_category": defaultdict(int),
            "open_incidents": 0,
            "critical_open": 0,
            "sla_breaches": 0,
            "avg_response_time_minutes": 0,
            "avg_resolution_time_minutes": 0
        }
        
        response_times = []
        resolution_times = []
        
        for incident in self.incidents.values():
            dashboard["by_severity"][incident["severity"]] += 1
            dashboard["by_status"][incident["status"]] += 1
            dashboard["by_category"][incident["category"]] += 1
            
            if incident["status"] not in [IncidentStatus.RESOLVED.value, 
                                           IncidentStatus.CLOSED.value]:
                dashboard["open_incidents"] += 1
            
            if incident["severity"] == 1 and incident["status"] != "resolved":
                dashboard["critical_open"] += 1
            
            if incident.get("sla_breach"):
                dashboard["sla_breaches"] += 1
            
            if "response_minutes" in incident:
                response_times.append(incident["response_minutes"])
            
            if "resolution_minutes" in incident:
                resolution_times.append(incident["resolution_minutes"])
        
        if response_times:
            dashboard["avg_response_time_minutes"] = sum(response_times) / len(response_times)
        
        if resolution_times:
            dashboard["avg_resolution_time_minutes"] = sum(resolution_times) / len(resolution_times)
        
        return dict(dashboard)
    
    async def generate_incident_report(self, incident_id: str) -> Dict:
        """生成事件报告"""
        incident = await self.get_incident_details(incident_id)
        
        if "error" in incident:
            return incident
        
        report = {
            "report_id": f"REPORT-{incident_id}-{datetime.now().strftime('%Y%m%d')}",
            "generated_at": datetime.now().isoformat(),
            "incident_summary": {
                "id": incident["incident_id"],
                "title": incident["title"],
                "severity": incident["severity"],
                "category": incident["category"],
                "status": incident["status"],
                "created_at": incident["created_at"],
                "resolved_at": incident.get("resolved_at")
            },
            "timeline": incident["timeline"],
            "impact_assessment": {
                "affected_systems": incident["affected_systems"],
                "affected_users": incident["affected_users"],
                "initial_impact": incident["initial_impact"]
            },
            "sla_compliance": incident.get("sla_tracking", {}),
            "response_summary": {
                "assigned_to": incident.get("assigned_to"),
                "response_progress": incident.get("response_progress"),
                "checkpoints_completed": [
                    cp["name"] for cp in incident.get("checkpoints", [])
                    if cp.get("completed")
                ]
            },
            "evidence": incident.get("evidence", []),
            "postmortem": None
        }
        
        if incident.get("postmortem_required"):
            report["postmortem"] = {
                "required": True,
                "status": "pending"
            }
        
        return report


class ResourceDispatcher:
    """应急资源调度"""
    
    def __init__(self):
        self.available_resources = {}
        self.resource_allocations = {}
    
    async def allocate_resources(self, 
                                 incident_id: str,
                                 resource_requests: List[Dict]) -> Dict:
        """
        分配应急资源
        
        Args:
            incident_id: 事件ID
            resource_requests: 资源请求列表
            
        Returns:
            分配结果
        """
        allocation = {
            "incident_id": incident_id,
            "allocation_id": f"ALLOC-{len(self.resource_allocations) + 1}",
            "requested_at": datetime.now().isoformat(),
            "resources": [],
            "status": "pending"
        }
        
        for request in resource_requests:
            resource_type = request.get("type")
            quantity = request.get("quantity", 1)
            
            # 检查资源可用性
            available = self._check_availability(resource_type, quantity)
            
            if available:
                allocated = {
                    "type": resource_type,
                    "quantity": quantity,
                    "status": "allocated",
                    "allocated_at": datetime.now().isoformat()
                }
            else:
                allocated = {
                    "type": resource_type,
                    "quantity": quantity,
                    "status": "pending",
                    "reason": "Resources not available"
                }
            
            allocation["resources"].append(allocated)
        
        # 更新分配状态
        if all(r["status"] == "allocated" for r in allocation["resources"]):
            allocation["status"] = "allocated"
        elif all(r["status"] == "pending" for r in allocation["resources"]):
            allocation["status"] = "pending"
        else:
            allocation["status"] = "partial"
        
        self.resource_allocations[allocation["allocation_id"]] = allocation
        
        return allocation
    
    def _check_availability(self, resource_type: str, quantity: int) -> bool:
        """检查资源可用性"""
        available = self.available_resources.get(resource_type, 0)
        return available >= quantity
    
    def get_resource_status(self) -> Dict:
        """获取资源状态"""
        return {
            "total_allocated": len(self.resource_allocations),
            "available_resources": self.available_resources,
            "active_allocations": [
                alloc for alloc in self.resource_allocations.values()
                if alloc["status"] == "allocated"
            ]
        }
