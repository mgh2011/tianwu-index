# scripts/security/anti_leak/anti_leak_system.py
"""
防泄密系统 - 数据防泄漏(DLP)、敏感数据识别、外发监控、水印追踪
"""
import asyncio
import hashlib
import re
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from enum import Enum

class DataSensitivity(Enum):
    """数据敏感级别"""
    PUBLIC = 1
    INTERNAL = 2
    CONFIDENTIAL = 3
    SECRET = 4
    TOP_SECRET = 5

class LeakRiskLevel(Enum):
    """泄密风险级别"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class DataLeakPrevention:
    """数据防泄漏系统"""
    
    def __init__(self):
        self.sensitive_patterns = {}
        self.dlp_policies = {}
        self.leak_history = []
        self.watermarks = {}
        
        # 初始化敏感数据模式
        self._init_sensitive_patterns()
    
    def _init_sensitive_patterns(self):
        """初始化敏感数据识别模式"""
        self.sensitive_patterns = {
            "credit_card": {
                "patterns": [
                    r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
                    r"\b\d{16}\b"
                ],
                "sensitivity": DataSensitivity.SECRET,
                "description": "信用卡号码"
            },
            "social_security": {
                "patterns": [
                    r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"
                ],
                "sensitivity": DataSensitivity.TOP_SECRET,
                "description": "社会安全号"
            },
            "phone_number": {
                "patterns": [
                    r"\b1[3-9]\d{9}\b",
                    r"\b\(\d{3}\)\s*\d{3}[-\s]?\d{4}\b"
                ],
                "sensitivity": DataSensitivity.CONFIDENTIAL,
                "description": "电话号码"
            },
            "email": {
                "patterns": [
                    r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b"
                ],
                "sensitivity": DataSensitivity.INTERNAL,
                "description": "邮箱地址"
            },
            "bank_account": {
                "patterns": [
                    r"\b\d{10,20}\b"
                ],
                "sensitivity": DataSensitivity.SECRET,
                "description": "银行账号"
            },
            "api_key": {
                "patterns": [
                    r"[a-zA-Z0-9]{32,}",
                    r"sk-[a-zA-Z0-9]{48}",
                    r"api[_-]?key[a-zA-Z0-9]{20,}"
                ],
                "sensitivity": DataSensitivity.TOP_SECRET,
                "description": "API密钥"
            },
            "password": {
                "patterns": [
                    r"password\s*[=:]\s*\S+",
                    r"pwd\s*[=:]\s*\S+",
                    r"pass\s*[=:]\s*\S+"
                ],
                "sensitivity": DataSensitivity.TOP_SECRET,
                "description": "密码"
            },
            "salary": {
                "patterns": [
                    r"salary\s*[=:]\s*[\$¥]?\d+[,\d]*\.?\d*",
                    r"工资\s*[=:]\s*[\$¥]?\d+"
                ],
                "sensitivity": DataSensitivity.CONFIDENTIAL,
                "description": "薪资信息"
            },
            "medical_record": {
                "patterns": [
                    r"medical\s*id\s*[=:]\s*[a-zA-Z0-9]+",
                    r"diagnosis\s*[=:]\s*[a-zA-Z]+"
                ],
                "sensitivity": DataSensitivity.TOP_SECRET,
                "description": "医疗记录"
            }
        }
    
    async def scan_content(self, content: Dict) -> Dict:
        """
        内容扫描
        
        Args:
            content: 待扫描内容
            
        Returns:
            扫描结果
        """
        scan_result = {
            "scan_id": f"scan_{datetime.now().timestamp()}",
            "content_type": content.get("type"),
            "scan_time": datetime.now().isoformat(),
            "sensitive_data_found": [],
            "overall_risk_level": LeakRiskLevel.LOW,
            "risk_score": 0,
            "action_recommended": "allow"
        }
        
        text_content = self._extract_text(content)
        
        # 扫描敏感数据
        for data_type, pattern_info in self.sensitive_patterns.items():
            matches = self._find_pattern_matches(text_content, pattern_info["patterns"])
            
            if matches:
                sensitive_item = {
                    "data_type": data_type,
                    "description": pattern_info["description"],
                    "sensitivity": pattern_info["sensitivity"].value,
                    "matches_count": len(matches),
                    "matches": matches[:5],  # 只保留前5个匹配示例
                    "risk_boost": self._calculate_risk_boost(
                        pattern_info["sensitivity"],
                        len(matches)
                    )
                }
                
                scan_result["sensitive_data_found"].append(sensitive_item)
                scan_result["risk_score"] += sensitive_item["risk_boost"]
        
        # 确定整体风险级别
        scan_result["overall_risk_level"] = self._determine_risk_level(
            scan_result["risk_score"]
        )
        
        # 推荐行动
        scan_result["action_recommended"] = self._recommend_action(
            scan_result["overall_risk_level"],
            scan_result["sensitive_data_found"]
        )
        
        return scan_result
    
    def _extract_text(self, content: Dict) -> str:
        """从内容中提取文本"""
        if content.get("type") == "email":
            return f"{content.get('subject', '')} {content.get('body', '')}"
        elif content.get("type") == "file":
            return content.get("content", "")
        elif content.get("type") == "message":
            return content.get("text", "")
        else:
            return str(content.get("data", ""))
    
    def _find_pattern_matches(self, text: str, patterns: List[str]) -> List[str]:
        """查找模式匹配"""
        matches = []
        for pattern in patterns:
            found = re.findall(pattern, text, re.IGNORECASE)
            matches.extend(found)
        return list(set(matches))  # 去重
    
    def _calculate_risk_boost(self, 
                             sensitivity: DataSensitivity, 
                             match_count: int) -> float:
        """计算风险增量"""
        base_risk = {
            DataSensitivity.PUBLIC: 0,
            DataSensitivity.INTERNAL: 5,
            DataSensitivity.CONFIDENTIAL: 15,
            DataSensitivity.SECRET: 30,
            DataSensitivity.TOP_SECRET: 50
        }
        
        # 匹配数量加权
        count_multiplier = min(match_count, 10) / 10 + 1
        
        return base_risk.get(sensitivity, 0) * count_multiplier
    
    def _determine_risk_level(self, risk_score: float) -> LeakRiskLevel:
        """确定风险级别"""
        if risk_score >= 100:
            return LeakRiskLevel.CRITICAL
        elif risk_score >= 50:
            return LeakRiskLevel.HIGH
        elif risk_score >= 20:
            return LeakRiskLevel.MEDIUM
        else:
            return LeakRiskLevel.LOW
    
    def _recommend_action(self, 
                         risk_level: LeakRiskLevel,
                         sensitive_items: List[Dict]) -> str:
        """推荐处理行动"""
        if risk_level == LeakRiskLevel.CRITICAL:
            return "block"
        elif risk_level == LeakRiskLevel.HIGH:
            # 检查是否有极高敏感数据
            has_top_secret = any(
                item["sensitivity"] >= DataSensitivity.TOP_SECRET.value
                for item in sensitive_items
            )
            return "block" if has_top_secret else "quarantine"
        elif risk_level == LeakRiskLevel.MEDIUM:
            return "warn_and_log"
        else:
            return "allow"
    
    async def apply_dlp_policy(self, content: Dict, policy: Dict) -> Dict:
        """
        应用DLP策略
        
        Args:
            content: 内容数据
            policy: DLP策略
            
        Returns:
            策略应用结果
        """
        policy_result = {
            "policy_id": policy.get("id"),
            "content_id": content.get("id"),
            "applied_at": datetime.now().isoformat(),
            "matched_rules": [],
            "action_taken": None,
            "justification": None
        }
        
        # 检查策略规则
        for rule in policy.get("rules", []):
            rule_match = await self._evaluate_rule(content, rule)
            
            if rule_match["matched"]:
                policy_result["matched_rules"].append({
                    "rule_id": rule["id"],
                    "rule_name": rule["name"],
                    "match_details": rule_match["details"]
                })
        
        # 根据匹配规则决定行动
        if policy_result["matched_rules"]:
            # 按优先级排序规则
            matched_rules = sorted(
                policy_result["matched_rules"],
                key=lambda x: x["match_details"].get("priority", 0),
                reverse=True
            )
            
            top_rule = matched_rules[0]
            action = policy.get("rules", [{}])[0].get("action", "block")
            
            policy_result["action_taken"] = action
            policy_result["justification"] = (
                f"Matched rule: {top_rule['rule_name']}"
            )
        else:
            policy_result["action_taken"] = "allow"
        
        return policy_result
    
    async def _evaluate_rule(self, content: Dict, rule: Dict) -> Dict:
        """评估规则"""
        # 简化实现
        return {
            "matched": False,
            "details": {
                "priority": rule.get("priority", 0)
            }
        }


class DataWatermarker:
    """数据水印追踪"""
    
    def __init__(self):
        self.watermark_templates = {}
        self.watermarked_documents = {}
    
    async def apply_watermark(self, document: Dict, watermark_config: Dict) -> Dict:
        """
        应用水印
        
        Args:
            document: 文档数据
            watermark_config: 水印配置
            
        Returns:
            水印应用结果
        """
        # 生成唯一水印
        watermark_id = self._generate_watermark_id()
        
        watermark = {
            "watermark_id": watermark_id,
            "document_id": document.get("id"),
            "applied_at": datetime.now().isoformat(),
            "watermark_type": watermark_config.get("type", "visible"),
            "watermark_data": {
                "user_id": watermark_config.get("user_id"),
                "user_email": watermark_config.get("user_email"),
                "timestamp": datetime.now().isoformat(),
                "session_id": watermark_config.get("session_id"),
                "client_info": watermark_config.get("client_info", {})
            },
            "embedded_in": watermark_config.get("embed_locations", ["content"])
        }
        
        # 嵌入水印
        watermarked_doc = await self._embed_watermark(
            document, 
            watermark
        )
        
        self.watermarked_documents[watermark_id] = {
            **watermark,
            "document": watermarked_doc
        }
        
        return {
            "watermark_id": watermark_id,
            "status": "applied",
            "watermark_preview": self._generate_watermark_preview(watermark)
        }
    
    def _generate_watermark_id(self) -> str:
        """生成水印ID"""
        timestamp = datetime.now().isoformat()
        random_suffix = hashlib.md5(
            f"{timestamp}_{id(self)}".encode()
        ).hexdigest()[:8]
        return f"WM-{datetime.now().strftime('%Y%m%d')}-{random_suffix}"
    
    async def _embed_watermark(self, document: Dict, watermark: Dict) -> Dict:
        """嵌入水印到文档"""
        # 简化实现
        watermarked = document.copy()
        watermarked["watermarked"] = True
        watermarked["watermark_id"] = watermark["watermark_id"]
        return watermarked
    
    def _generate_watermark_preview(self, watermark: Dict) -> str:
        """生成水印预览"""
        data = watermark["watermark_data"]
        return (
            f"CONFIDENTIAL | User: {data['user_email']} | "
            f"Time: {data['timestamp']} | ID: {watermark['watermark_id']}"
        )
    
    async def track_document(self, watermark_id: str) -> Dict:
        """追踪文档"""
        if watermark_id not in self.watermarked_documents:
            return {"error": "Watermark not found"}
        
        watermark = self.watermarked_documents[watermark_id]
        
        return {
            "watermark_id": watermark_id,
            "document_id": watermark["document_id"],
            "original_user": watermark["watermark_data"]["user_email"],
            "applied_at": watermark["applied_at"],
            "access_history": await self._get_access_history(watermark_id)
        }
    
    async def _get_access_history(self, watermark_id: str) -> List[Dict]:
        """获取访问历史"""
        # 简化实现
        return [
            {
                "accessed_at": datetime.now().isoformat(),
                "accessed_by": "unknown",
                "action": "view"
            }
        ]
    
    async def trace_leak_source(self, leaked_content: Dict) -> Dict:
        """
        追踪泄密源头
        
        Args:
            leaked_content: 泄露内容
            
        Returns:
            追踪结果
        """
        trace_result = {
            "trace_id": f"TRACE-{datetime.now().timestamp()}",
            "trace_time": datetime.now().isoformat(),
            "leaked_content_hash": self._calculate_content_hash(leaked_content),
            "matched_watermarks": [],
            "potential_sources": [],
            "confidence": 0
        }
        
        # 计算泄露内容哈希
        content_hash = self._calculate_content_hash(leaked_content)
        
        # 搜索匹配的水印
        for watermark_id, watermark_info in self.watermarked_documents.items():
            doc_hash = self._calculate_content_hash(watermark_info["document"])
            
            if self._compare_hashes(content_hash, doc_hash):
                trace_result["matched_watermarks"].append({
                    "watermark_id": watermark_id,
                    "original_user": watermark_info["watermark_data"]["user_email"],
                    "applied_at": watermark_info["applied_at"],
                    "confidence": 0.95
                })
        
        # 识别潜在源头
        for match in trace_result["matched_watermarks"]:
            potential_source = {
                "user_id": match["original_user"],
                "email": match["original_user"],
                "access_time": match["applied_at"],
                "leak_likelihood": "high" if match["confidence"] > 0.9 else "medium"
            }
            trace_result["potential_sources"].append(potential_source)
            trace_result["confidence"] = max(
                trace_result["confidence"],
                match["confidence"]
            )
        
        return trace_result
    
    def _calculate_content_hash(self, content: Dict) -> str:
        """计算内容哈希"""
        content_str = str(content.get("content", ""))
        return hashlib.sha256(content_str.encode()).hexdigest()
    
    def _compare_hashes(self, hash1: str, hash2: str) -> bool:
        """比较哈希"""
        # 允许一定程度的相似性匹配
        # 简化实现
        return hash1 == hash2 or self._calculate_similarity(hash1, hash2) > 0.8
    
    def _calculate_similarity(self, hash1: str, hash2: str) -> float:
        """计算相似度"""
        if len(hash1) != len(hash2):
            return 0.0
        
        matching_chars = sum(c1 == c2 for c1, c2 in zip(hash1, hash2))
        return matching_chars / len(hash1)


class ExternalTransferMonitor:
    """外发监控"""
    
    def __init__(self):
        self.transfer_logs = {}
        self.blocked_transfers = {}
        self.approved_transfers = {}
    
    async def monitor_transfer(self, transfer_request: Dict) -> Dict:
        """
        监控数据传输
        
        Args:
            transfer_request: 传输请求
            
        Returns:
            监控结果
        """
        monitor_result = {
            "transfer_id": transfer_request.get("id"),
            "monitored_at": datetime.now().isoformat(),
            "transfer_type": transfer_request.get("type"),
            "destination": transfer_request.get("destination"),
            "risk_assessment": None,
            "action": "monitor",
            "requires_approval": False
        }
        
        # 评估传输风险
        risk_assessment = await self._assess_transfer_risk(transfer_request)
        monitor_result["risk_assessment"] = risk_assessment
        
        # 确定是否需要审批
        if risk_assessment["level"] in ["high", "critical"]:
            monitor_result["requires_approval"] = True
            monitor_result["approvers"] = self._get_required_approvers(risk_assessment)
        
        # 记录传输日志
        self.transfer_logs[monitor_result["transfer_id"]] = monitor_result
        
        return monitor_result
    
    async def _assess_transfer_risk(self, transfer: Dict) -> Dict:
        """评估传输风险"""
        risk_factors = []
        risk_score = 0
        
        # 检查目的地
        destination = transfer.get("destination", {})
        if destination.get("type") == "external":
            risk_score += 20
            risk_factors.append("External destination")
        
        if destination.get("country") not in ["US", "CA", "home_country"]:
            risk_score += 15
            risk_factors.append(f"Cross-border transfer to {destination.get('country')}")
        
        # 检查数据敏感度
        if transfer.get("contains_sensitive_data"):
            risk_score += 30
            risk_factors.append("Contains sensitive data")
        
        # 检查数据量
        data_size = transfer.get("size_mb", 0)
        if data_size > 100:
            risk_score += 20
            risk_factors.append(f"Large data transfer: {data_size}MB")
        
        # 检查传输方式
        method = transfer.get("method")
        if method in ["email_attachment", "usb", "cloud_storage"]:
            risk_score += 10
            risk_factors.append(f"Method: {method}")
        
        # 确定风险级别
        if risk_score >= 60:
            level = "critical"
        elif risk_score >= 40:
            level = "high"
        elif risk_score >= 20:
            level = "medium"
        else:
            level = "low"
        
        return {
            "score": risk_score,
            "level": level,
            "factors": risk_factors
        }
    
    def _get_required_approvers(self, risk_assessment: Dict) -> List[Dict]:
        """获取需要的审批人"""
        approvers = []
        
        if risk_assessment["level"] == "critical":
            approvers.append({"role": "security_manager", "required": True})
            approvers.append({"role": "data_owner", "required": True})
            approvers.append({"role": "compliance_officer", "required": True})
        elif risk_assessment["level"] == "high":
            approvers.append({"role": "security_manager", "required": True})
            approvers.append({"role": "data_owner", "required": True})
        
        return approvers
    
    async def get_transfer_analytics(self, period_days: int = 30) -> Dict:
        """获取传输分析"""
        cutoff_date = datetime.now() - timedelta(days=period_days)
        
        analytics = {
            "period_days": period_days,
            "total_transfers": 0,
            "blocked_transfers": 0,
            "approved_transfers": 0,
            "by_type": {},
            "by_risk_level": {},
            "top_destinations": []
        }
        
        for transfer in self.transfer_logs.values():
            transfer_time = datetime.fromisoformat(transfer["monitored_at"])
            
            if transfer_time < cutoff_date:
                continue
            
            analytics["total_transfers"] += 1
            
            if transfer["action"] == "blocked":
                analytics["blocked_transfers"] += 1
            
            if transfer.get("approved"):
                analytics["approved_transfers"] += 1
            
            # 统计类型
            transfer_type = transfer["transfer_type"]
            analytics["by_type"][transfer_type] = \
                analytics["by_type"].get(transfer_type, 0) + 1
            
            # 统计风险级别
            risk_level = transfer["risk_assessment"]["level"]
            analytics["by_risk_level"][risk_level] = \
                analytics["by_risk_level"].get(risk_level, 0) + 1
        
        return analytics
