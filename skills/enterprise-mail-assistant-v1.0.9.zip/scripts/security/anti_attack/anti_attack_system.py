# scripts/security/anti_attack/anti_attack_system.py
"""
防攻击系统 - DDoS防护、Web攻击防护、应用层防护、API安全网关
"""
import asyncio
import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from collections import defaultdict, deque
from ipaddress import ip_address, ip_network

class DDoSProtection:
    """DDoS防护系统"""
    
    def __init__(self):
        self.traffic_baseline = {}
        self.blocklist = {}
        self.ratelimits = {}
        self.attack_history = []
        
        # DDoS检测阈值
        self.thresholds = {
            "requests_per_second": 1000,
            "requests_per_minute": 50000,
            "concurrent_connections": 5000,
            "bandwidth_mbps": 1000
        }
    
    async def protect(self, traffic_data: Dict) -> Dict:
        """
        DDoS防护检测和处理
        
        Args:
            traffic_data: 流量数据
            
        Returns:
            防护决策
        """
        decision = {
            "timestamp": datetime.now().isoformat(),
            "source_ip": traffic_data.get("source_ip"),
            "action": "allow",
            "risk_level": "low",
            "detections": [],
            "mitigations": []
        }
        
        # 1. 流量基线检测
        baseline_result = await self._baseline_detection(traffic_data)
        if baseline_result["is_anomalous"]:
            decision["detections"].append(baseline_result)
            decision["risk_level"] = baseline_result["risk_level"]
        
        # 2. 速率检测
        rate_result = await self._rate_detection(traffic_data)
        if rate_result["is_anomalous"]:
            decision["detections"].append(rate_result)
            decision["risk_level"] = "high"
        
        # 3. 协议异常检测
        protocol_result = await self._protocol_anomaly_detection(traffic_data)
        if protocol_result["is_anomalous"]:
            decision["detections"].append(protocol_result)
            decision["risk_level"] = "critical"
        
        # 4. 地理异常检测
        geo_result = await self._geo_anomaly_detection(traffic_data)
        if geo_result["is_anomalous"]:
            decision["detections"].append(geo_result)
            if decision["risk_level"] != "critical":
                decision["risk_level"] = "medium"
        
        # 根据风险级别采取行动
        if decision["risk_level"] == "critical":
            decision["action"] = "block"
            decision["mitigations"] = self._get_critical_mitigations(traffic_data)
        elif decision["risk_level"] == "high":
            decision["action"] = "challenge"  # 验证码挑战
            decision["mitigations"] = self._get_high_mitigations(traffic_data)
        elif decision["risk_level"] == "medium":
            decision["action"] = "rate_limit"
            decision["mitigations"] = self._get_medium_mitigations(traffic_data)
        
        return decision
    
    async def _baseline_detection(self, traffic_data: Dict) -> Dict:
        """基于基线的异常检测"""
        source_ip = traffic_data.get("source_ip")
        
        # 获取基线
        baseline = self.traffic_baseline.get(source_ip, {
            "avg_rps": 10,
            "avg_bpm": 500,
            "typical_hours": list(range(8, 20))
        })
        
        current_rps = traffic_data.get("requests_per_second", 0)
        current_time = datetime.now()
        
        # 检测是否在典型活动时间
        in_typical_hours = current_time.hour in baseline["typical_hours"]
        
        # 计算偏差
        rps_deviation = current_rps / baseline["avg_rps"] if baseline["avg_rps"] > 0 else 0
        
        is_anomalous = rps_deviation > 10 or (not in_typical_hours and rps_deviation > 3)
        
        return {
            "detection_type": "baseline",
            "is_anomalous": is_anomalous,
            "risk_level": "high" if rps_deviation > 20 else "medium",
            "current_value": current_rps,
            "baseline_value": baseline["avg_rps"],
            "deviation_factor": rps_deviation
        }
    
    async def _rate_detection(self, traffic_data: Dict) -> Dict:
        """速率检测"""
        source_ip = traffic_data.get("source_ip")
        
        rps = traffic_data.get("requests_per_second", 0)
        rpm = traffic_data.get("requests_per_minute", 0)
        concurrent = traffic_data.get("concurrent_connections", 0)
        
        is_anomalous = (
            rps > self.thresholds["requests_per_second"] or
            rpm > self.thresholds["requests_per_minute"] or
            concurrent > self.thresholds["concurrent_connections"]
        )
        
        exceeded_thresholds = []
        if rps > self.thresholds["requests_per_second"]:
            exceeded_thresholds.append(f"RPS: {rps} > {self.thresholds['requests_per_second']}")
        if rpm > self.thresholds["requests_per_minute"]:
            exceeded_thresholds.append(f"RPM: {rpm} > {self.thresholds['requests_per_minute']}")
        if concurrent > self.thresholds["concurrent_connections"]:
            exceeded_thresholds.append(f"Connections: {concurrent} > {self.thresholds['concurrent_connections']}")
        
        return {
            "detection_type": "rate",
            "is_anomalous": is_anomalous,
            "risk_level": "critical" if len(exceeded_thresholds) > 1 else "high",
            "exceeded_thresholds": exceeded_thresholds
        }
    
    async def _protocol_anomaly_detection(self, traffic_data: Dict) -> Dict:
        """协议异常检测"""
        protocol = traffic_data.get("protocol", "http")
        flags = traffic_data.get("tcp_flags", [])
        malformed_packets = traffic_data.get("malformed_packets", 0)
        
        anomalies = []
        
        # 检测SYN洪水
        if "SYN" in flags and "ACK" not in flags:
            syn_ratio = traffic_data.get("syn_ratio", 0)
            if syn_ratio > 0.9:
                anomalies.append("SYN flood detected")
        
        # 检测畸形数据包
        if malformed_packets > 0:
            anomalies.append(f"{malformed_packets} malformed packets")
        
        # 检测无效协议
        if traffic_data.get("invalid_http_methods"):
            anomalies.append("Invalid HTTP methods")
        
        return {
            "detection_type": "protocol",
            "is_anomalous": len(anomalies) > 0,
            "risk_level": "critical",
            "anomalies": anomalies
        }
    
    async def _geo_anomaly_detection(self, traffic_data: Dict) -> Dict:
        """地理异常检测"""
        source_country = traffic_data.get("source_country")
        target_country = traffic_data.get("target_country")
        
        # 正常情况：同国家或邻近国家
        normal_regions = ["US", "CA", "MX"]  # 北美
        
        is_anomalous = source_country not in normal_regions
        
        return {
            "detection_type": "geo",
            "is_anomalous": is_anomalous,
            "risk_level": "low",
            "source": source_country,
            "target": target_country
        }
    
    def _get_critical_mitigations(self, traffic_data: Dict) -> List[Dict]:
        """严重攻击缓解措施"""
        return [
            {
                "action": "immediate_block",
                "duration": 3600,
                "scope": "ip",
                "target": traffic_data.get("source_ip")
            },
            {
                "action": "notify_cdn_provider",
                "severity": "critical"
            },
            {
                "action": "enable_emergency_mode",
                "scope": "global"
            },
            {
                "action": "activate_blackhole_routing"
            }
        ]
    
    def _get_high_mitigations(self, traffic_data: Dict) -> List[Dict]:
        """高风险缓解措施"""
        return [
            {
                "action": "challenge",
                "type": "captcha",
                "duration": 300
            },
            {
                "action": "rate_limit",
                "limit": 100,
                "window": 60
            },
            {
                "action": "add_to_watchlist",
                "duration": 86400
            }
        ]
    
    def _get_medium_mitigations(self, traffic_data: Dict) -> List[Dict]:
        """中等风险缓解措施"""
        return [
            {
                "action": "rate_limit",
                "limit": 500,
                "window": 60
            },
            {
                "action": "log_suspicious",
                "level": "warning"
            }
        ]
    
    async def update_traffic_baseline(self, source_ip: str, traffic_stats: Dict):
        """更新流量基线"""
        if source_ip not in self.traffic_baseline:
            self.traffic_baseline[source_ip] = {}
        
        self.traffic_baseline[source_ip].update(traffic_stats)
    
    def get_protection_status(self) -> Dict:
        """获取防护状态"""
        return {
            "protection_enabled": True,
            "active_blocklist_size": len(self.blocklist),
            "attack_history_last_24h": len([
                a for a in self.attack_history
                if datetime.fromisoformat(a["timestamp"]) > datetime.now() - timedelta(hours=24)
            ]),
            "current_risk_level": "normal",
            "uptime": "99.99%"
        }


class WebAttackProtection:
    """Web攻击防护系统"""
    
    def __init__(self):
        self.attack_signatures = {}
        self.protection_rules = []
        self.attack_history = []
    
    async def protect_web_request(self, request: Dict) -> Dict:
        """
        Web攻击防护检测
        
        Args:
            request: HTTP请求数据
            
        Returns:
            防护决策
        """
        decision = {
            "request_id": request.get("id"),
            "timestamp": datetime.now().isoformat(),
            "action": "allow",
            "threats_detected": [],
            "risk_score": 0
        }
        
        # 1. SQL注入检测
        sql_result = self._detect_sql_injection(request)
        if sql_result["detected"]:
            decision["threats_detected"].append(sql_result)
            decision["risk_score"] += sql_result["confidence"]
        
        # 2. XSS检测
        xss_result = self._detect_xss(request)
        if xss_result["detected"]:
            decision["threats_detected"].append(xss_result)
            decision["risk_score"] += xss_result["confidence"]
        
        # 3. CSRF检测
        csrf_result = self._detect_csrf(request)
        if csrf_result["detected"]:
            decision["threats_detected"].append(csrf_result)
            decision["risk_score"] += csrf_result["confidence"]
        
        # 4. 路径遍历检测
        path_result = self._detect_path_traversal(request)
        if path_result["detected"]:
            decision["threats_detected"].append(path_result)
            decision["risk_score"] += path_result["confidence"]
        
        # 5. 命令注入检测
        cmd_result = self._detect_command_injection(request)
        if cmd_result["detected"]:
            decision["threats_detected"].append(cmd_result)
            decision["risk_score"] += cmd_result["confidence"]
        
        # 根据风险评分决定行动
        if decision["risk_score"] >= 0.8:
            decision["action"] = "block"
        elif decision["risk_score"] >= 0.5:
            decision["action"] = "sanitize"
        elif decision["risk_score"] >= 0.3:
            decision["action"] = "log_and_alert"
        
        return decision
    
    def _detect_sql_injection(self, request: Dict) -> Dict:
        """SQL注入检测"""
        sql_patterns = [
            r"(\bOR\b|\bAND\b).*=.*",
            r"('|(\\'))",
            r"(UNION\s+SELECT)",
            r"(DROP\s+TABLE)",
            r"(INSERT\s+INTO)",
            r"(UPDATE\s+.*SET)",
            r"(DELETE\s+FROM)",
            r"(EXEC\s*\()",
            r"(--|#|\/\*)"
        ]
        
        url = request.get("url", "")
        params = request.get("params", {})
        body = request.get("body", "")
        
        all_text = f"{url} {str(params)} {body}"
        
        detected = False
        matched_patterns = []
        
        import re
        for pattern in sql_patterns:
            if re.search(pattern, all_text, re.IGNORECASE):
                detected = True
                matched_patterns.append(pattern)
        
        return {
            "attack_type": "sql_injection",
            "detected": detected,
            "confidence": 0.9 if len(matched_patterns) > 2 else 0.6,
            "matched_patterns": matched_patterns
        }
    
    def _detect_xss(self, request: Dict) -> Dict:
        """XSS检测"""
        xss_patterns = [
            r"<script[^>]*>",
            r"javascript:",
            r"on\w+\s*=",
            r"<iframe[^>]*>",
            r"<embed[^>]*>",
            r"<object[^>]*>",
            r"eval\s*\(",
            r"document\.cookie",
            r"innerHTML\s*=",
            r"outerHTML\s*="
        ]
        
        url = request.get("url", "")
        headers = request.get("headers", {})
        body = request.get("body", "")
        
        all_text = f"{url} {str(headers)} {body}"
        
        detected = False
        matched_patterns = []
        
        import re
        for pattern in xss_patterns:
            if re.search(pattern, all_text, re.IGNORECASE):
                detected = True
                matched_patterns.append(pattern)
        
        return {
            "attack_type": "xss",
            "detected": detected,
            "confidence": 0.85 if len(matched_patterns) > 1 else 0.5,
            "matched_patterns": matched_patterns
        }
    
    def _detect_csrf(self, request: Dict) -> Dict:
        """CSRF检测"""
        # 检查CSRF Token
        token = request.get("headers", {}).get("X-CSRF-Token")
        cookie_token = request.get("cookies", {}).get("csrf_token")
        
        # 检查Referer
        referer = request.get("headers", {}).get("Referer")
        
        # 检查是否为敏感操作
        sensitive_methods = ["POST", "PUT", "DELETE", "PATCH"]
        is_sensitive = request.get("method") in sensitive_methods
        
        detected = False
        reason = None
        
        if is_sensitive:
            if not token or not cookie_token:
                detected = True
                reason = "Missing CSRF token"
            elif token != cookie_token:
                detected = True
                reason = "CSRF token mismatch"
            
            if referer and not referer.startswith(request.get("origin", "")):
                detected = True
                reason = f"Invalid Referer: {referer}"
        
        return {
            "attack_type": "csrf",
            "detected": detected,
            "confidence": 0.9 if reason else 0.3,
            "reason": reason
        }
    
    def _detect_path_traversal(self, request: Dict) -> Dict:
        """路径遍历检测"""
        path_traversal_patterns = [
            r"\.\.\/",
            r"\.\.%2f",
            r"%2e%2e%2f",
            r"%2e%2e/",
            r"etc/passwd",
            r"windows/system32",
            r"\.\.\\",
            r"%2e%2e\\"
        ]
        
        url = request.get("url", "")
        
        detected = False
        matched_patterns = []
        
        import re
        for pattern in path_traversal_patterns:
            if re.search(pattern, url, re.IGNORECASE):
                detected = True
                matched_patterns.append(pattern)
        
        return {
            "attack_type": "path_traversal",
            "detected": detected,
            "confidence": 0.85,
            "matched_patterns": matched_patterns
        }
    
    def _detect_command_injection(self, request: Dict) -> Dict:
        """命令注入检测"""
        cmd_patterns = [
            r"[;&|`$]",
            r"\$\(",
            r"`.*`",
            r"rm\s+-rf",
            r"wget\s+",
            r"curl\s+",
            r"nc\s+",
            r"ncat\s+",
            r"\|\s*sh",
            r"\|\s*bash"
        ]
        
        url = request.get("url", "")
        params = request.get("params", {})
        body = request.get("body", "")
        
        all_text = f"{url} {str(params)} {body}"
        
        detected = False
        matched_patterns = []
        
        import re
        for pattern in cmd_patterns:
            if re.search(pattern, all_text):
                detected = True
                matched_patterns.append(pattern)
        
        return {
            "attack_type": "command_injection",
            "detected": detected,
            "confidence": 0.9 if len(matched_patterns) > 1 else 0.6,
            "matched_patterns": matched_patterns
        }


class APIProtection:
    """API安全网关"""
    
    def __init__(self):
        self.api_keys = {}
        self.rate_limits = {}
        self.api_policies = {}
    
    async def protect_api_request(self, api_request: Dict) -> Dict:
        """
        API请求保护
        
        Args:
            api_request: API请求数据
            
        Returns:
            保护决策
        """
        decision = {
            "request_id": api_request.get("id"),
            "timestamp": datetime.now().isoformat(),
            "action": "allow",
            "checks_passed": [],
            "checks_failed": [],
            "rate_limit_remaining": None
        }
        
        # 1. 认证检查
        auth_result = await self._check_authentication(api_request)
        if auth_result["passed"]:
            decision["checks_passed"].append("authentication")
        else:
            decision["checks_failed"].append(auth_result)
            decision["action"] = "deny"
        
        # 2. 授权检查
        if decision["action"] == "allow":
            authz_result = await self._check_authorization(api_request)
            if not authz_result["passed"]:
                decision["checks_failed"].append(authz_result)
                decision["action"] = "deny"
            else:
                decision["checks_passed"].append("authorization")
        
        # 3. 速率限制检查
        if decision["action"] == "allow":
            rate_result = await self._check_rate_limit(api_request)
            if not rate_result["passed"]:
                decision["checks_failed"].append(rate_result)
                decision["action"] = "rate_limit"
            else:
                decision["checks_passed"].append("rate_limit")
                decision["rate_limit_remaining"] = rate_result.get("remaining")
        
        # 4. 输入验证
        if decision["action"] == "allow":
            input_result = await self._validate_input(api_request)
            if not input_result["passed"]:
                decision["checks_failed"].append(input_result)
                decision["action"] = "sanitize"
            else:
                decision["checks_passed"].append("input_validation")
        
        # 5. 策略检查
        if decision["action"] == "allow":
            policy_result = await self._check_policies(api_request)
            if not policy_result["passed"]:
                decision["checks_failed"].append(policy_result)
                if policy_result.get("action") == "deny":
                    decision["action"] = "deny"
        
        return decision
    
    async def _check_authentication(self, request: Dict) -> Dict:
        """认证检查"""
        api_key = request.get("headers", {}).get("X-API-Key")
        bearer_token = request.get("headers", {}).get("Authorization", "").replace("Bearer ", "")
        
        key_to_check = api_key or bearer_token
        
        if not key_to_check:
            return {
                "passed": False,
                "reason": "Missing API key or token",
                "error_code": "AUTH_001"
            }
        
        # 验证密钥
        if key_to_check in self.api_keys:
            key_info = self.api_keys[key_to_check]
            
            if key_info.get("revoked"):
                return {
                    "passed": False,
                    "reason": "API key has been revoked",
                    "error_code": "AUTH_002"
                }
            
            if key_info.get("expired"):
                return {
                    "passed": False,
                    "reason": "API key has expired",
                    "error_code": "AUTH_003"
                }
            
            return {
                "passed": True,
                "key_id": key_info.get("key_id"),
                "client": key_info.get("client_name")
            }
        
        return {
            "passed": False,
            "reason": "Invalid API key",
            "error_code": "AUTH_004"
        }
    
    async def _check_authorization(self, request: Dict) -> Dict:
        """授权检查"""
        # 获取客户端权限
        client = request.get("client")
        endpoint = request.get("endpoint")
        method = request.get("method")
        
        # 简化实现
        allowed_endpoints = [
            {"endpoint": "/api/v1/email/*", "methods": ["GET", "POST"]},
            {"endpoint": "/api/v1/attachment/*", "methods": ["GET", "POST", "DELETE"]}
        ]
        
        return {
            "passed": True,
            "permissions": ["read", "write"]
        }
    
    async def _check_rate_limit(self, request: Dict) -> Dict:
        """速率限制检查"""
        client_id = request.get("client", "anonymous")
        
        # 获取或创建速率限制记录
        if client_id not in self.rate_limits:
            self.rate_limits[client_id] = {
                "requests": deque(maxlen=1000),
                "limit": 1000,
                "window": 60
            }
        
        rate_info = self.rate_limits[client_id]
        current_time = time.time()
        
        # 清理过期记录
        while rate_info["requests"] and current_time - rate_info["requests"][0] > rate_info["window"]:
            rate_info["requests"].popleft()
        
        # 检查限制
        current_count = len(rate_info["requests"])
        remaining = rate_info["limit"] - current_count
        
        if current_count >= rate_info["limit"]:
            return {
                "passed": False,
                "reason": "Rate limit exceeded",
                "current": current_count,
                "limit": rate_info["limit"],
                "retry_after": rate_info["window"]
            }
        
        # 记录请求
        rate_info["requests"].append(current_time)
        
        return {
            "passed": True,
            "remaining": remaining,
            "reset_time": current_time + rate_info["window"]
        }
    
    async def _validate_input(self, request: Dict) -> Dict:
        """输入验证"""
        params = request.get("params", {})
        body = request.get("body", {})
        
        validation_errors = []
        
        # 检查必要参数
        required_fields = ["recipient", "subject"]
        for field in required_fields:
            if field not in params and field not in body:
                validation_errors.append(f"Missing required field: {field}")
        
        # 检查参数类型
        if "limit" in params:
            try:
                limit = int(params["limit"])
                if limit < 1 or limit > 1000:
                    validation_errors.append("Parameter 'limit' must be between 1 and 1000")
            except ValueError:
                validation_errors.append("Parameter 'limit' must be an integer")
        
        if validation_errors:
            return {
                "passed": False,
                "errors": validation_errors
            }
        
        return {"passed": True}
    
    async def _check_policies(self, request: Dict) -> Dict:
        """策略检查"""
        # 定义策略规则
        policies = [
            {
                "name": "allowed_ips",
                "check": lambda r: True,
                "action": "deny"
            },
            {
                "name": "time_restriction",
                "check": lambda r: datetime.now().hour in range(0, 24),
                "action": "deny"
            }
        ]
        
        for policy in policies:
            if not policy["check"](request):
                return {
                    "passed": False,
                    "policy": policy["name"],
                    "action": policy["action"],
                    "reason": f"Policy '{policy['name']}' violated"
                }
        
        return {"passed": True}
    
    def register_api_key(self, key_info: Dict) -> Dict:
        """注册API密钥"""
        key_id = f"key_{len(self.api_keys)}"
        
        self.api_keys[key_info["key"]] = {
            "key_id": key_id,
            "client_name": key_info.get("client_name"),
            "permissions": key_info.get("permissions", ["read"]),
            "rate_limit": key_info.get("rate_limit", 1000),
            "created_at": datetime.now().isoformat(),
            "expires_at": key_info.get("expires_at"),
            "revoked": False
        }
        
        return {
            "status": "registered",
            "key_id": key_id
        }
