"""
企业级智能邮件助手 - 简化API封装
Enterprise Mail Assistant - Simple API Wrapper

提供简化的调用方式，让Agent无需关注复杂的对象创建。
所有方法都支持直接使用字典参数。
"""

from typing import Dict, List, Any, Optional, Union
from datetime import datetime
from dataclasses import dataclass, field
import hashlib
import re

# 导入核心模块
from mail_functions import MailCore, Email, EmailAddress, Attachment, MailStatus, MailPriority
from security_defense import ThreatDetectionEngine, PhishingDetector, AttachmentScanner, ThreatLevel
from mail_queue_notification import MailQueue, NotificationSystem, QueuePriority


class SimpleMailAPI:
    """
    简化邮件API - 一站式邮件处理入口
    
    特点：
    - 所有方法支持字典参数，无需创建复杂对象
    - 自动处理对象转换
    - 统一错误处理
    - 链式调用支持
    
    使用示例：
    ```python
    api = SimpleMailAPI()
    
    # 发送邮件（简化的字典参数）
    result = api.send({
        'to': 'user@example.com',
        'subject': '测试邮件',
        'body': '这是一封测试邮件'
    })
    
    # 安全检查（自动转换）
    result = api.check_security({
        'from': 'sender@example.com',
        'subject': '紧急通知',
        'body': '请点击链接验证'
    })
    
    # 入队通知
    api.queue({
        'to': 'user@example.com',
        'subject': '通知',
        'body': '内容'
    }).notify('admin@example.com', '新邮件已入队')
    ```
    """
    
    def __init__(self):
        self._mail_core = MailCore()
        self._threat_engine = ThreatDetectionEngine()
        self._phishing_detector = PhishingDetector()
        self._attachment_scanner = AttachmentScanner()
        self._mail_queue = MailQueue()
        self._notification = NotificationSystem()
        self._last_email_id = None
        # 导入垃圾邮件检测器
        from security_defense import SpamDetector
        self._spam_detector = SpamDetector()
    
    # ==================== 简化的邮件操作 ====================
    
    def send(self, email_dict: Dict) -> Dict[str, Any]:
        """
        发送邮件（简化接口）
        
        参数：
            email_dict: 邮件信息字典，支持以下字段：
                - to: 收件人（字符串或列表）
                - cc: 抄送（可选）
                - subject: 主题
                - body: 正文
                - from_addr: 发件人（可选，默认 'noreply@system.local'）
                - attachments: 附件列表（可选）
        
        返回：
            {'success': True, 'email_id': 'xxx', 'sent_at': '...'}
        
        示例：
            api.send({
                'to': 'user@example.com',
                'subject': '测试邮件',
                'body': '这是测试内容'
            })
        """
        email = self._dict_to_email(email_dict)
        result = self._mail_core.send_email(email)
        self._last_email_id = email.id
        return result
    
    def receive(self, email_dict: Dict) -> Dict[str, Any]:
        """
        接收邮件（简化接口）
        
        参数：
            email_dict: 邮件信息字典，同 send()
        
        返回：
            {'success': True, 'email_id': 'xxx', 'received_at': '...'}
        
        示例：
            api.receive({
                'from': 'sender@example.com',
                'to': 'me@example.com',
                'subject': '来信',
                'body': '内容'
            })
        """
        email = self._dict_to_email(email_dict)
        email.status = MailStatus.RECEIVED if hasattr(MailStatus, 'RECEIVED') else MailStatus.DELIVERED
        
        self._mail_core.emails[email.id] = email
        self._last_email_id = email.id
        
        return {
            'success': True,
            'email_id': email.id,
            'received_at': datetime.now().isoformat()
        }
    
    def classify(self, email_dict: Dict) -> Dict[str, Any]:
        """
        分类邮件
        
        参数：
            email_dict: 邮件信息字典
        
        返回：
            {'category': '商务', 'confidence': 0.85, 'tags': [...]}
        """
        subject = email_dict.get('subject', '')
        sender = email_dict.get('from', email_dict.get('sender', ''))
        body = email_dict.get('body', '')
        
        # 基于关键词分类
        categories = {
            '会议': ['会议', '邀请', '日程', '安排', '预约'],
            '通知': ['通知', '公告', '提醒', '更新', '发布'],
            '商务': ['合作', '订单', '合同', '报价', '付款', '发票'],
            '人事': ['面试', '入职', '离职', '薪资', '考勤', '休假'],
            '技术': ['问题', 'bug', '修复', '更新', '版本', 'API'],
            '营销': ['优惠', '活动', '促销', '折扣', '新品'],
            '安全': ['验证', '密码', '登录', '异常', '风险', '账户']
        }
        
        text = f"{subject} {sender} {body}".lower()
        
        scores = {}
        for cat, keywords in categories.items():
            score = sum(1 for kw in keywords if kw in text)
            if score > 0:
                scores[cat] = score
        
        if scores:
            best = max(scores, key=scores.get)
            confidence = min(scores[best] / 3, 1.0)
        else:
            best = '其他'
            confidence = 0.3
        
        return {
            'category': best,
            'confidence': confidence,
            'tags': list(scores.keys())[:3]
        }
    
    # ==================== 简化的安全检查 ====================
    
    def check_security(self, email_dict: Dict) -> Dict[str, Any]:
        """
        邮件安全检查（一站式接口）
        
        参数：
            email_dict: 邮件信息字典
        
        返回：
            {
                'is_safe': True/False,
                'threat_level': 'low/medium/high/critical',
                'risk_score': 0-100,
                'threats': [...],
                'recommendations': '...'
            }
        
        示例：
            result = api.check_security({
                'from': 'admin@bank.xyz',
                'subject': '紧急验证',
                'body': '点击链接验证账户'
            })
            if not result['is_safe']:
                print(f"威胁等级: {result['threat_level']}")
        """
        # 1. 威胁检测
        threat_result = self._threat_engine.analyze_email(email_dict)
        
        # 2. 钓鱼检测
        is_phishing, phishing_conf, evidence = self._phishing_detector.detect(email_dict)
        
        # 3. 垃圾邮件检测
        is_spam, spam_conf, spam_evidence = self._spam_detector.detect(email_dict)
        
        # 4. 附件扫描
        attachment_threats = []
        if email_dict.get('attachments'):
            for att in email_dict.get('attachments', []):
                att_result = self._attachment_scanner.scan_attachment(att)
                if not att_result.is_safe:
                    attachment_threats.append({
                        'filename': att.get('filename', 'unknown'),
                        'threat': att_result.threat_type
                    })
        
        # 5. 综合判断
        is_safe = (
            threat_result.threat_level in [ThreatLevel.SAFE, ThreatLevel.LOW] 
            and not is_phishing 
            and not is_spam
            and len(attachment_threats) == 0
        )
        
        # 6. 生成建议
        if not is_safe:
            recommendations = []
            if threat_result.threat_level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL]:
                recommendations.append('建议拦截此邮件')
            if is_phishing:
                recommendations.append('检测到钓鱼特征，请勿点击链接')
            if is_spam:
                recommendations.append('检测到垃圾邮件特征，建议删除')
            if attachment_threats:
                recommendations.append(f'发现{len(attachment_threats)}个可疑附件')
            rec_text = '；'.join(recommendations) if recommendations else '需人工审核'
        else:
            rec_text = '邮件安全，可正常处理'
        
        return {
            'is_safe': is_safe,
            'threat_level': threat_result.threat_level.value,
            'risk_score': threat_result.risk_score,
            'is_phishing': is_phishing,
            'phishing_confidence': phishing_conf,
            'is_spam': is_spam,
            'spam_confidence': spam_conf,
            'threats': [{'type': t.threat_type, 'desc': t.description} for t in threat_result.threats[:5]],
            'attachment_threats': attachment_threats,
            'evidence': evidence[:5] if evidence else [],
            'spam_evidence': spam_evidence[:3] if spam_evidence else [],
            'recommendations': rec_text
        }
    
    def is_phishing(self, email_dict: Dict) -> tuple:
        """
        快速判断是否为钓鱼邮件
        
        返回：
            (is_phishing: bool, confidence: float, evidence: list)
        """
        return self._phishing_detector.detect(email_dict)
    
    def scan_attachment(self, attachment_dict: Dict) -> Dict[str, Any]:
        """
        扫描附件安全性
        
        参数：
            attachment_dict: {'filename': 'xxx', 'size': 12345}
        
        返回：
            {'is_safe': True/False, 'threat_type': '...', 'warnings': [...]}
        """
        result = self._attachment_scanner.scan_attachment(attachment_dict)
        return {
            'is_safe': result.is_safe,
            'threat_type': result.threat_type if not result.is_safe else None,
            'warnings': result.warnings if hasattr(result, 'warnings') else []
        }
    
    # ==================== 简化的队列操作 ====================
    
    def queue(self, email_dict: Dict, priority: str = 'normal') -> 'SimpleMailAPI':
        """
        将邮件加入队列（支持链式调用）
        
        参数：
            email_dict: 邮件信息
            priority: 优先级 ('high', 'normal', 'low')
        
        返回：
            self（支持链式调用）
        
        示例：
            api.queue(email).notify('admin@example.com', '新邮件')
        """
        email = self._dict_to_email(email_dict)
        
        priority_map = {
            'high': QueuePriority.HIGH,
            'normal': QueuePriority.NORMAL,
            'low': QueuePriority.LOW
        }
        
        # MailQueue.enqueue(email_id, action, data, priority)
        self._mail_queue.enqueue(
            email_id=email.id,
            action='process',
            data={'email': email_dict},
            priority=priority_map.get(priority, QueuePriority.NORMAL)
        )
        self._last_email_id = email.id
        return self
    
    def notify(self, to: str, message: str, subject: str = None, notification_type: str = 'info') -> Dict[str, Any]:
        """
        发送通知（链式调用）
        
        参数：
            to: 接收者ID/邮箱
            message: 通知消息
            subject: 通知标题
            notification_type: 通知类型 ('info', 'warning', 'alert', 'system')
        
        示例：
            api.queue(email).notify('admin@example.com', '新邮件已入队')
        """
        from mail_queue_notification import NotificationType
        
        type_map = {
            'info': NotificationType.SYSTEM,
            'warning': NotificationType.ALERT,
            'alert': NotificationType.ALERT,
            'system': NotificationType.SYSTEM,
            'new_email': NotificationType.NEW_EMAIL,
            'reminder': NotificationType.REMINDER
        }
        
        # NotificationSystem.send_notification(user_id, notification_type, title, message, ...)
        self._notification.send_notification(
            user_id=to,
            notification_type=type_map.get(notification_type, NotificationType.SYSTEM),
            title=subject or '系统通知',
            message=message
        )
        return {'success': True, 'notified': to}
    
    # ==================== 统一安全管道 ====================
    
    def security_pipeline(self, email_dict: Dict, auto_quarantine: bool = True) -> Dict[str, Any]:
        """
        统一安全处理管道
        
        自动执行：安全检查 → 分类 → 决策 → 处理
        
        参数：
            email_dict: 邮件信息
            auto_quarantine: 是否自动隔离高风险邮件
        
        返回：
            {
                'action': 'deliver' | 'quarantine' | 'block',
                'security_result': {...},
                'category': {...},
                'email_id': '...'
            }
        """
        # 1. 安全检查
        security = self.check_security(email_dict)
        
        # 2. 分类
        category = self.classify(email_dict)
        
        # 3. 决策
        if not security['is_safe']:
            if security['threat_level'] in ['high', 'critical']:
                action = 'block'
            else:
                action = 'quarantine'
        else:
            action = 'deliver'
        
        # 4. 执行
        email = self._dict_to_email(email_dict)
        email_id = email.id
        
        if action == 'deliver':
            self._mail_core.emails[email_id] = email
        elif action == 'quarantine' and auto_quarantine:
            self._mail_queue.quarantine_email(email_id, security['recommendations'])
        
        return {
            'action': action,
            'security_result': security,
            'category': category,
            'email_id': email_id,
            'message': {
                'deliver': '邮件已放行',
                'quarantine': '邮件已隔离',
                'block': '邮件已拦截'
            }[action]
        }
    
    # ==================== 辅助方法 ====================
    
    def _dict_to_email(self, email_dict: Dict) -> Email:
        """将字典转换为Email对象"""
        # 生成ID
        email_id = email_dict.get('id') or hashlib.md5(
            f"{email_dict.get('subject', '')}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:12]
        
        # 解析收件人
        to_list = email_dict.get('to', [])
        if isinstance(to_list, str):
            to_list = [to_list]
        to_addrs = [self._parse_addr(t) for t in to_list]
        
        # 解析抄送
        cc_list = email_dict.get('cc', [])
        if isinstance(cc_list, str):
            cc_list = [cc_list] if cc_list else []
        cc_addrs = [self._parse_addr(c) for c in cc_list] if cc_list else []
        
        # 解析发件人
        from_addr = self._parse_addr(email_dict.get('from', email_dict.get('from_addr', 'noreply@system.local')))
        
        # 解析附件
        attachments = []
        for att in email_dict.get('attachments', []):
            if isinstance(att, dict):
                attachments.append(Attachment(
                    filename=att.get('filename', 'unknown'),
                    content=att.get('content', b''),
                    size=att.get('size', 0)
                ))
        
        return Email(
            id=email_id,
            subject=email_dict.get('subject', ''),
            body=email_dict.get('body', ''),
            from_addr=from_addr,
            to_addrs=to_addrs,
            cc_addrs=cc_addrs,
            attachments=attachments,
            priority=MailPriority.NORMAL
        )
    
    def _parse_addr(self, addr: Union[str, Dict]) -> EmailAddress:
        """解析地址"""
        if isinstance(addr, EmailAddress):
            return addr
        if isinstance(addr, dict):
            return EmailAddress(address=addr.get('address', ''), name=addr.get('name', ''))
        if isinstance(addr, str):
            return EmailAddress.from_string(addr)
        return EmailAddress(address=str(addr))


# ==================== 便捷函数 ====================

def quick_send(to: str, subject: str, body: str, **kwargs) -> Dict:
    """
    快速发送邮件的便捷函数
    
    示例：
        from simple_api import quick_send
        quick_send('user@example.com', '测试', '内容')
    """
    api = SimpleMailAPI()
    return api.send({'to': to, 'subject': subject, 'body': body, **kwargs})


def quick_check(email_dict: Dict) -> Dict:
    """
    快速安全检查的便捷函数
    
    示例：
        from simple_api import quick_check
        result = quick_check({
            'from': 'sender@example.com',
            'subject': '紧急通知',
            'body': '点击链接验证'
        })
    """
    api = SimpleMailAPI()
    return api.check_security(email_dict)


def is_safe_email(email_dict: Dict) -> bool:
    """
    快速判断邮件是否安全
    
    示例：
        from simple_api import is_safe_email
        if is_safe_email(email):
            # 处理邮件
    """
    api = SimpleMailAPI()
    result = api.check_security(email_dict)
    return result['is_safe']


# ==================== 与守门员技能协作 ====================

class MailSecurityPipeline:
    """
    邮件安全处理管道 - 与邮件安全守门员协作
    
    提供统一的入口，整合邮件安全守门员和智能邮件助手的能力。
    
    使用示例：
    ```python
    pipeline = MailSecurityPipeline()
    
    # 处理邮件（自动安全检查 + 分类 + 处理）
    result = pipeline.process({
        'from': 'sender@example.com',
        'to': 'me@company.com',
        'subject': '邮件主题',
        'body': '邮件内容'
    })
    
    print(f"处理结果: {result['action']}")
    ```
    """
    
    def __init__(self):
        self.api = SimpleMailAPI()
        self._gatekeeper_enabled = True
        self._auto_notify = True
    
    def process(self, email_dict: Dict, config: Dict = None) -> Dict[str, Any]:
        """
        处理邮件的统一入口
        
        流程：
        1. 邮件安全守门员检查（安全边界判断）
        2. 威胁检测引擎分析
        3. 邮件分类
        4. 自动处理/通知
        
        参数：
            email_dict: 邮件信息
            config: 配置选项
                - auto_quarantine: 是否自动隔离
                - notify_admin: 管理员邮箱
                - gatekeeper_enabled: 是否启用守门员
        
        返回：
            {
                'action': 'deliver' | 'quarantine' | 'block' | 'needs_confirmation',
                'security': {...},
                'category': {...},
                'email_id': '...'
            }
        """
        config = config or {}
        
        # 执行安全管道
        result = self.api.security_pipeline(
            email_dict,
            auto_quarantine=config.get('auto_quarantine', True)
        )
        
        # 添加守门员判断（如果需要主人确认）
        if result['security_result']['risk_score'] > 70:
            result['action'] = 'needs_confirmation'
            result['message'] = '风险较高，需要主人确认'
        
        # 通知管理员
        if config.get('notify_admin') and self._auto_notify:
            if result['action'] in ['block', 'quarantine', 'needs_confirmation']:
                self.api.notify(
                    config['notify_admin'],
                    f"邮件处理通知: {result['action']} - {result['security_result']['threat_level']}"
                )
        
        return result
    
    def batch_process(self, emails: List[Dict], config: Dict = None) -> List[Dict]:
        """批量处理邮件"""
        return [self.process(email, config) for email in emails]
    
    def get_stats(self) -> Dict[str, Any]:
        """获取处理统计"""
        return {
            'total_emails': len(self.api._mail_core.emails),
            'queued': self.api._mail_queue.get_queue_length() if hasattr(self.api._mail_queue, 'get_queue_length') else 0
        }


# 使用说明
__all__ = [
    'SimpleMailAPI',
    'MailSecurityPipeline',
    'quick_send',
    'quick_check',
    'is_safe_email'
]
