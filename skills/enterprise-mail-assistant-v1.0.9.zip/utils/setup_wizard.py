#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置向导
帮助用户快速配置邮件系统
"""

import sys
import json
from datetime import datetime

class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_header():
    print(f"""
{Colors.CYAN}╔════════════════════════════════════════════════════════════╗
║                                                          ║
║    ⚙️  企业级智能邮件助手 - 配置向导                      ║
║                                                          ║
╚════════════════════════════════════════════════════════════╝{Colors.ENDC}
    """)

def ask_question(question, options=None, default=None):
    """询问问题"""
    print(f"\n{Colors.YELLOW}{question}{Colors.ENDC}")
    
    if options:
        for i, opt in enumerate(options, 1):
            print(f"   {i}. {opt}")
    
    if default:
        print(f"   (直接回车使用默认值: {default})")
    
    while True:
        try:
            answer = input(f"\n   请输入: ").strip()
            if not answer and default:
                return default
            if options:
                if answer.isdigit() and 1 <= int(answer) <= len(options):
                    return options[int(answer) - 1]
                print(f"   {Colors.RED}请输入有效的选项{Colors.ENDC}")
            else:
                return answer
        except (ValueError, EOFError):
            return default or ""

def create_config():
    """创建设置"""
    config = {
        "version": "5.0.1",
        "created_at": datetime.now().isoformat(),
        "mail": {},
        "classification": {},
        "security": {},
        "backup": {},
        "auto_reply": {}
    }
    
    print(f"\n{Colors.BOLD}📧 邮件账户设置{Colors.ENDC}")
    print(f"{Colors.BLUE}   (如不需要配置邮件账户，可以跳过){Colors.ENDC}")
    
    has_mail = ask_question("是否配置邮件账户?", ["是", "否"], "否")
    
    if has_mail == "是":
        config["mail"] = {
            "imap_server": ask_question("IMAP服务器地址:", None, "imap.example.com"),
            "imap_port": ask_question("IMAP端口:", None, "993"),
            "smtp_server": ask_question("SMTP服务器地址:", None, "smtp.example.com"),
            "smtp_port": ask_question("SMTP端口:", None, "465"),
            "username": ask_question("邮箱用户名:", None, "your@email.com"),
            # 密码应该从环境变量获取，不硬编码
            "password_env": "EMAIL_PASSWORD"
        }
    
    print(f"\n{Colors.BOLD}📂 分类规则设置{Colors.ENDC}")
    
    default_rules = ask_question("使用默认分类规则?", ["是", "否"], "是")
    if default_rules == "是":
        config["classification"] = {
            "auto_classify": True,
            "categories": ["工作", "会议", "个人", "推广", "垃圾"]
        }
    
    print(f"\n{Colors.BOLD}🔒 安全设置{Colors.ENDC}")
    
    security_level = ask_question(
        "安全检测级别:",
        ["严格", "标准", "宽松"],
        "标准"
    )
    
    config["security"] = {
        "level": security_level,
        "auto_scan": True,
        "block_phishing": True if security_level == "严格" else False,
        "warn_suspicious": True
    }
    
    print(f"\n{Colors.BOLD}💾 备份设置{Colors.ENDC}")
    
    auto_backup = ask_question("启用自动备份?", ["是", "否"], "是")
    if auto_backup == "是":
        config["backup"] = {
            "auto_backup": True,
            "backup_interval": ask_question(
                "备份频率:",
                ["每日", "每周", "每月"],
                "每日"
            ),
            "backup_path": "./backups"
        }
    
    print(f"\n{Colors.BOLD}📤 自动回复设置{Colors.ENDC}")
    
    auto_reply = ask_question("启用自动回复?", ["是", "否"], "否")
    if auto_reply == "是":
        config["auto_reply"] = {
            "enabled": True,
            "vacation_mode": True,
            "reply_delay_seconds": 60
        }
    
    return config

def save_config(config, filepath="config.json"):
    """保存配置"""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    print(f"\n   {Colors.GREEN}✅ 配置已保存到: {filepath}{Colors.ENDC}")

def main():
    print_header()
    
    print(f"\n{Colors.YELLOW}欢迎使用配置向导！{Colors.ENDC}")
    print(f"   这个向导将帮助您配置邮件助手的基本功能。")
    
    config = create_config()
    
    print(f"\n{Colors.CYAN}{'═'*50}{Colors.ENDC}")
    print(f"{Colors.BOLD}📋 配置摘要{Colors.ENDC}\n")
    
    print(f"   邮件账户: {'已配置' if config['mail'] else '未配置'}")
    print(f"   分类规则: {'自动' if config['classification'].get('auto_classify') else '手动'}")
    print(f"   安全级别: {config['security'].get('level', '未设置')}")
    print(f"   自动备份: {config['backup'].get('auto_backup', False)}")
    print(f"   自动回复: {config['auto_reply'].get('enabled', False)}")
    
    save = ask_question("\n是否保存配置?", ["是", "否"], "是")
    
    if save == "是":
        save_config(config)
        
        print(f"\n{Colors.GREEN}🎉 配置完成！{Colors.ENDC}")
        print(f"\n接下来您可以:")
        print(f"   1. 运行 python quick_start.py 体验功能")
        print(f"   2. 运行 python cli.py --help 查看命令行工具")
        print(f"   3. 查看 demos/ 目录下的详细演示")
    else:
        print(f"\n   {Colors.YELLOW}配置未保存{Colors.ENDC}")

if __name__ == "__main__":
    main()
