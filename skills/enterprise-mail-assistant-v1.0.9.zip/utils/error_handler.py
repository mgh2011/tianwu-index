"""
企业级智能邮件助手 - 友好错误处理模块
Enterprise Mail Assistant - User-Friendly Error Handler

解决评测反馈："错误提示不够友好，排查问题难度较高"
"""

import json
import traceback
from datetime import datetime
from typing import Dict, Any, Optional
from enum import Enum


class ErrorCode(Enum):
    """错误代码枚举"""
    # 配置错误 (E001-E010)
    CONFIG_NOT_FOUND = ("E001", "配置文件不存在", "运行 quick_start.py 初始化配置")
    CONFIG_INVALID_VALUE = ("E002", "配置值无效", "检查配置项取值范围")
    CONFIG_PARSE_ERROR = ("E003", "配置文件解析失败", "检查 YAML/JSON 格式是否正确")
    
    # 邮件处理错误 (E101-E110)
    MAIL_FORMAT_ERROR = ("E101", "邮件格式不支持", "使用 JSON/YAML/Text 格式")
    MAIL_PARSE_ERROR = ("E102", "邮件解析失败", "检查邮件数据结构是否完整")
    MAIL_EMPTY_ERROR = ("E103", "邮件内容为空", "提供有效的邮件内容")
    
    # 分类错误 (E201-E210)
    CLASSIFICATION_RULE_MISSING = ("E201", "分类规则缺失", "补充 categories 和 rules 配置")
    CLASSIFICATION_FAILED = ("E202", "分类处理失败", "检查分类规则和数据格式")
    
    # 安全检测错误 (E301-E310)
    SECURITY_THREAT_DB_EXPIRED = ("E301", "威胁库过期", "更新本地威胁数据库")
    SECURITY_SCAN_FAILED = ("E302", "安全扫描失败", "检查扫描配置和参数")
    
    # 备份恢复错误 (E401-E410)
    BACKUP_FILE_CORRUPTED = ("E401", "备份文件损坏", "重新创建备份")
    BACKUP_RESTORE_FAILED = ("E402", "恢复失败", "检查备份文件完整性")
    
    # 自动化错误 (E501-E510)
    AUTOMATION_TIMEOUT = ("E501", "脚本执行超时", "增加超时时间或分批处理")
    AUTOMATION_FAILED = ("E502", "自动化任务失败", "检查任务配置和参数")
    
    # 通用错误 (E901-E999)
    DEPENDENCY_MISSING = ("E901", "依赖缺失", "运行 install_dependencies.py")
    PERMISSION_DENIED = ("E902", "权限不足", "检查文件读写权限")
    VALIDATION_FAILED = ("E903", "数据验证失败", "检查数据格式和约束")
    UNKNOWN_ERROR = ("E999", "未知错误", "查看详细日志或联系支持")


class UserFriendlyError(Exception):
    """用户友好的错误类"""
    
    def __init__(
        self,
        error_code: ErrorCode,
        details: Optional[str] = None,
        suggestion: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ):
        self.error_code = error_code
        self.code, self.message, self.default_solution = error_code.value
        self.details = details or ""
        self.suggestion = suggestion or self.default_solution
        self.context = context or {}
        self.timestamp = datetime.now().isoformat()
        
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        """格式化错误消息"""
        msg = f"""
╔══════════════════════════════════════════════════════════════╗
║  ❌ 错误代码: {self.code}
║  📋 错误说明: {self.message}
╠══════════════════════════════════════════════════════════════╣"""
        
        if self.details:
            msg += f"\n║  🔍 详细信息: {self.details}"
        
        msg += f"""
║  ✅ 解决方案: {self.suggestion}
╚══════════════════════════════════════════════════════════════╝

💡 更多帮助:
   - 查看文档: TROUBLESHOOTING.md
   - 运行诊断: python cli.py --diagnose
   - 查看日志: logs/error_{datetime.now().strftime('%Y%m%d')}.log
"""
        return msg
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "error": True,
            "code": self.code,
            "message": self.message,
            "details": self.details,
            "suggestion": self.suggestion,
            "context": self.context,
            "timestamp": self.timestamp
        }
    
    def to_json(self) -> str:
        """转换为JSON格式"""
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)


def handle_error(
    error: Exception,
    context: Optional[Dict[str, Any]] = None,
    show_traceback: bool = False
) -> UserFriendlyError:
    """
    统一错误处理函数
    
    Args:
        error: 原始异常
        context: 错误上下文
        show_traceback: 是否显示堆栈跟踪
    
    Returns:
        UserFriendlyError: 用户友好的错误对象
    """
    # 如果已经是 UserFriendlyError，直接返回
    if isinstance(error, UserFriendlyError):
        return error
    
    # 根据异常类型映射到错误代码
    error_mapping = {
        FileNotFoundError: ErrorCode.CONFIG_NOT_FOUND,
        ValueError: ErrorCode.CONFIG_INVALID_VALUE,
        json.JSONDecodeError: ErrorCode.CONFIG_PARSE_ERROR,
        KeyError: ErrorCode.CLASSIFICATION_RULE_MISSING,
        TimeoutError: ErrorCode.AUTOMATION_TIMEOUT,
        PermissionError: ErrorCode.PERMISSION_DENIED,
    }
    
    error_code = error_mapping.get(type(error), ErrorCode.UNKNOWN_ERROR)
    
    # 提取详细错误信息
    details = str(error)
    
    # 创建友好错误
    friendly_error = UserFriendlyError(
        error_code=error_code,
        details=details,
        context=context
    )
    
    if show_traceback:
        print("\n" + "="*60)
        print("🐛 调试信息 (Debug Info)")
        print("="*60)
        traceback.print_exc()
        print("="*60 + "\n")
    
    return friendly_error


def safe_execute(func):
    """
    安全执行装饰器
    
    用法:
        @safe_execute
        def my_function():
            # 可能出错的代码
            pass
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            error = handle_error(e, context={
                "function": func.__name__,
                "args": str(args)[:100],
                "kwargs": str(kwargs)[:100]
            })
            print(error)
            return error.to_dict()
    return wrapper


# 使用示例
if __name__ == "__main__":
    print("="*60)
    print("错误处理示例演示")
    print("="*60)
    
    # 示例1: 配置文件不存在
    print("\n示例1: 配置文件不存在")
    try:
        raise FileNotFoundError("配置文件 ./config/settings.yaml 不存在")
    except Exception as e:
        error = handle_error(e)
        print(error)
    
    # 示例2: 分类规则缺失
    print("\n示例2: 分类规则缺失")
    try:
        raise KeyError("categories")
    except Exception as e:
        error = handle_error(e, context={"config_file": "settings.yaml"})
        print(error)
        print("\nJSON格式输出:")
        print(error.to_json())
    
    # 示例3: 脚本超时
    print("\n示例3: 脚本执行超时")
    try:
        raise TimeoutError("脚本执行超过300秒")
    except Exception as e:
        error = handle_error(e, suggestion="增加超时时间: python cli.py --timeout 600")
        print(error)
    
    print("\n" + "="*60)
    print("演示完成！所有错误都有清晰的说明和解决方案")
    print("="*60)
